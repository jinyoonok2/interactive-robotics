"""Small outcome-predictor experiment, with entire instances held out.

This trains a supervised classifier, not a robot policy. Fixed legacy-continuation
labels are retained; no handoff-probe labels are mixed into this corpus.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import sys

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F

from data.interaction_outcomes import InteractionOutcomeDataset
from models.interaction_success import InteractionSuccessHead

ROOT=Path(__file__).resolve().parents[2]


def dump(path,value):
    temporary=path.with_suffix(path.suffix+'.tmp')
    temporary.write_text(json.dumps(value,indent=2)+'\n');temporary.replace(path)


def instance_folds(records):
    groups=sorted({r['instance_group'] for r in records})
    if len(groups)<3:raise ValueError('Need at least three object instances for this pilot')
    folds=[]
    for group in groups:
        train=[i for i,r in enumerate(records) if r['instance_group']!=group]
        held=[i for i,r in enumerate(records) if r['instance_group']==group]
        if {records[i]['source_group'] for i in train}&{records[i]['source_group'] for i in held}:
            raise ValueError('Source trajectories cross instance folds')
        folds.append((group,train,held))
    return folds


def metrics(labels,probabilities):
    y=np.asarray(labels,dtype=float);p=np.asarray(probabilities,dtype=float)
    if y.shape!=p.shape or not len(y) or not np.isfinite(p).all():raise ValueError('Invalid predictions')
    p=np.clip(p,1e-7,1-1e-7);pred=p>=.5
    pos=y==1;neg=y==0
    sensitivity=float(pred[pos].mean()) if pos.any() else None
    specificity=float((~pred[neg]).mean()) if neg.any() else None
    auc=float(((p[pos,None]>p[None,neg])+.5*(p[pos,None]==p[None,neg])).mean()) if pos.any() and neg.any() else None
    return {'n':len(y),'success_labels':int(pos.sum()),'failure_labels':int(neg.sum()),
            'accuracy':float((pred==y).mean()),'balanced_accuracy':(sensitivity+specificity)/2 if pos.any() and neg.any() else None,
            'auroc':auc,'brier':float(np.mean((p-y)**2)),
            'binary_cross_entropy':float(np.mean(-y*np.log(p)-(1-y)*np.log(1-p))),
            'success_recall':sensitivity,'failure_recall':specificity}


def make_corpus(indices,output):
    records=[];sources=[];seen=set()
    for index in indices:
        index=Path(index).resolve();data=json.loads(index.read_text())
        summary=json.loads((index.parent/'summary.json').read_text())
        if data.get('validation_status')!='passed' or data.get('source_split')!='training only' or summary.get('status')!='completed' or not summary.get('eligible'):
            raise ValueError('Unvalidated source index: '+str(index))
        sources.append({'index':str(index),'sha256':hashlib.sha256(index.read_bytes()).hexdigest()})
        for row in data['records']:
            result=(index.parent/row['result_file']).resolve();observation=(index.parent/row['observation_file']).resolve()
            if str(result) in seen:raise ValueError('Duplicate outcome record')
            seen.add(str(result))
            records.append({**row,'result_file':str(result),'observation_file':str(observation),
                            'result_sha256':hashlib.sha256(result.read_bytes()).hexdigest(),
                            'observation_sha256':hashlib.sha256(observation.read_bytes()).hexdigest()})
    instance_folds(records)
    corpus={'source_split':'training only','validation_status':'passed','records':records,'sources':sources,
            'label_protocol':'Legacy fixed 5 cm lift / 1 s + 0.5 s hold, finger gain 0.01; physical outcome limits unchanged.',
            'limits':['Six source instances in three categories; no scissors coverage.',
                      'Pre-intervention full-scene observations; expert nominal target/time-to-close is prototype context.',
                      'Existing legacy labels are not relabeled after observing handoff probe outcomes.']}
    dump(output,corpus)
    return corpus


def extract_features(dataset,output):
    from models.backbone import FrozenDINOv2,FrozenT5
    hub=Path.home()/'.cache/torch/hub/facebookresearch_dinov2_main'
    checkpoint=Path.home()/'.cache/torch/hub/checkpoints/dinov2_vits14_reg4_pretrain.pth'
    if not hub.is_dir() or not checkpoint.is_file():raise FileNotFoundError('Local frozen visual backbone is required')
    native_load=torch.hub.load
    def offline_load(*args,**kwargs):
        if kwargs.get('source')!='local':raise RuntimeError('Online backbone fallback is disabled')
        return native_load(*args,**kwargs)
    torch.hub.load=offline_load
    try:visual=FrozenDINOv2(local_hub_dir=str(hub),local_ckpt=str(checkpoint)).eval()
    finally:torch.hub.load=native_load
    text=FrozenT5(model_name='google/flan-t5-base',device='cpu').eval()
    groups={};context={};rows=[]
    for i,record in enumerate(dataset.records):
        sample=dataset[i];x=sample['inputs'];group=record['source_group']
        if group not in groups:
            with torch.no_grad():
                rgb=F.normalize(visual(x['rgb']).mean(1),dim=-1).flatten()
                tokens,mask=text([x['skill_instruction']])
                language=F.normalize((tokens*mask[:,:,None]).sum(1)/mask.sum(1,keepdim=True),dim=-1)[0].cpu()
                cloud=x['pcd_camera_m']
                moments=torch.cat([cloud.mean(1),cloud.std(1),cloud.amin(1),cloud.amax(1)],dim=-1).flatten()/.5
                feature=torch.cat([rgb.cpu(),moments])
            groups[group]=(feature,language)
            context[group]=(x['rgb'].clone(),x['pcd_camera_m'].clone(),x['robot_state'].clone(),x['primitive_context'].clone(),x['skill_instruction'])
        else:
            previous=context[group]
            for original,current in zip(previous[:4],[x['rgb'],x['pcd_camera_m'],x['robot_state'],x['primitive_context']]):
                if not torch.equal(original,current):raise ValueError('Candidate-dependent observation/context within source')
            if previous[4]!=x['skill_instruction']:raise ValueError('Instruction changed within source')
        feature,language=groups[group]
        rows.append((feature,language,x['robot_state'],x['primitive_context'],x['candidate'],sample['labels']['success'],sample['labels']['criteria']))
    names=['observation','skill','robot','primitive','candidate','success','criteria']
    tensors={name:torch.stack([r[i] for r in rows]).float() for i,name in enumerate(names)}
    # Fixed physical-unit scaling, with no held-out-statistic fitting.
    tensors['robot']/=torch.tensor([.5,.5,.5,1.,1.,1.,1.,.04])
    tensors['primitive']/=torch.tensor([.5,.5,.5,np.pi,np.pi,np.pi,.04,1.])
    tensors['groups']=[r['instance_group'] for r in dataset.records]
    tensors['sources']=[r['source_group'] for r in dataset.records]
    tensors['backbones']={'vision':'DINOv2 ViT-S/14 registers, frozen patch mean per frame; RGB/255, 252 px',
                         'text':'Flan-T5-base, frozen masked token mean',
                         'pcd':'Fixed full-scene mean/std/min/max per frame; no GT part masks',
                         'visual_checkpoint_sha256':hashlib.sha256(checkpoint.read_bytes()).hexdigest(),
                         'text_revision':getattr(text.model.config,'_commit_hash',None)}
    torch.save(tensors,output)
    return tensors


def predict(model,tensors,indices,mode):
    values=[tensors[name][indices] for name in ['observation','skill','robot','primitive']]
    if mode=='candidate_only':values=[torch.zeros_like(v) for v in values]
    return model(*values,tensors['candidate'][indices,None,:])


def train(tensors,records,out,epochs,seeds):
    folds=instance_folds(records);predictions=[];curves=[]
    for held,training,testing in folds:
        y=tensors['success'][training]
        if y.min()==y.max():raise ValueError('A training fold has only one outcome class')
        prior=float((y.sum()+1)/(len(y)+2))
        for seed in seeds:
            for i in testing:
                predictions.append({'model':'train_prior','seed':seed,'record':i,'instance':held,'label':float(tensors['success'][i]),'probability':prior})
            for mode in ['candidate_only','context_candidate']:
                torch.manual_seed(seed)
                model=InteractionSuccessHead(tensors['observation'].shape[-1],tensors['skill'].shape[-1],hidden_dim=64)
                optimizer=torch.optim.AdamW(model.parameters(),lr=.001,weight_decay=.0001)
                model.train()
                for epoch in range(epochs+1):
                    result=predict(model,tensors,training,mode)
                    loss=F.binary_cross_entropy_with_logits(result['success_logits'][:,0],y)+.25*F.binary_cross_entropy_with_logits(result['criterion_logits'][:,0],tensors['criteria'][training])
                    if epoch in [0,1,5,10,25,50,100,150,200,epochs]:
                        curves.append({'model':mode,'seed':seed,'held_instance':held,'epoch':epoch,'training_loss':float(loss.detach())})
                    if epoch==epochs:break
                    optimizer.zero_grad();loss.backward();optimizer.step()
                model.eval()
                with torch.no_grad():p=torch.sigmoid(predict(model,tensors,testing,mode)['success_logits'][:,0]).numpy()
                for i,value in zip(testing,p):
                    predictions.append({'model':mode,'seed':seed,'record':i,'instance':held,'label':float(tensors['success'][i]),'probability':float(value)})
                checkpoint=out/'checkpoints'/f'{held.replace("/","_")}_{seed}_{mode}.pt'
                checkpoint.parent.mkdir(exist_ok=True)
                torch.save({'state_dict':model.state_dict(),'held_instance':held,'training_instances':sorted({records[i]['instance_group'] for i in training}),
                            'training_records':training,'held_records':testing,'seed':seed,'epochs':epochs,'mode':mode,
                            'observation_dim':tensors['observation'].shape[-1],'skill_dim':tensors['skill'].shape[-1]},checkpoint)
                print('[outcome-training]',held,seed,mode,'loss',float(loss.detach()),flush=True)
                dump(out/'progress.json',{'completed_models':len(list((out/'checkpoints').glob('*.pt'))),'planned_models':len(folds)*len(seeds)*2})
    return predictions,curves


def report(out,corpus,predictions,curves,seeds):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    sys.path.insert(0,str(ROOT/'part2action/docs/slide_history/scripts'))
    from export_slide_tables import render
    results={}
    for mode in ['train_prior','candidate_only','context_candidate']:
        per_seed=[]
        for seed in seeds:
            rows=[r for r in predictions if r['model']==mode and r['seed']==seed]
            stats=metrics([r['label'] for r in rows],[r['probability'] for r in rows]);stats['seed']=seed
            stats['per_instance']={g:metrics([r['label'] for r in rows if r['instance']==g],[r['probability'] for r in rows if r['instance']==g]) for g in sorted({r['instance'] for r in rows})}
            per_seed.append(stats)
        results[mode]={'per_seed':per_seed,'mean':{key:float(np.mean([r[key] for r in per_seed])) for key in ['accuracy','balanced_accuracy','auroc','brier','binary_cross_entropy']},
                       'training_seed_std':{key:float(np.std([r[key] for r in per_seed],ddof=1)) for key in ['accuracy','balanced_accuracy','auroc','brier']}}
    summary={'status':'completed','records':len(corpus['records']),'instances':len({r['instance_group'] for r in corpus['records']}),
             'sources':len(corpus['sources']),'success_labels':sum(r['label'] for r in predictions if r['model']=='train_prior' and r['seed']==seeds[0]),
             'protocol':'Leave one whole object instance out; 250 fixed full-batch updates; three training seeds; no held-out tuning or early stopping.',
             'model_scope':'Supervised candidate-outcome heads; no robot-policy training, rollout selection, or demonstrated robustness improvement.',
             'results':results,'limits':corpus['limits']+['Only 15 negative labels; dataset and instances are too small for broad generalization claims.',
                 'Candidate-only and full-context heads share architecture/loss/optimizer; only context inputs differ.',
                 'All predictions are out of fold, but this is a development pilot, not a final benchmark.']}
    dump(out/'summary.json',summary);dump(out/'predictions.json',predictions);dump(out/'learning_curves.json',curves)
    media=out/'media/2026-11-01';media.mkdir(parents=True,exist_ok=True)
    rows=[['Pilot predictor','AUROC','Balanced accuracy','Brier (lower)']]
    labels={'train_prior':'Train-prior constant','candidate_only':'Candidate only','context_candidate':'Observation + skill + state + candidate'}
    for mode,value in results.items():
        rows.append([labels[mode]]+[f'{value["mean"][k]:.3f}' for k in ['auroc','balanced_accuracy','brier']])
    render(rows,[.40,.20,.20,.20],media/'held_instance_results.png')
    fig,ax=plt.subplots(figsize=(8,4.5))
    for mode in ['candidate_only','context_candidate']:
        x=sorted({r['epoch'] for r in curves if r['model']==mode})
        vals=[np.array([r['training_loss'] for r in curves if r['model']==mode and r['epoch']==e]) for e in x]
        means=[v.mean() for v in vals];std=[v.std() for v in vals]
        ax.plot(x,means,label=labels[mode]);ax.fill_between(x,np.array(means)-std,np.array(means)+std,alpha=.12)
    ax.set(xlabel='Fixed training updates',ylabel='Training BCE + 0.25 criterion BCE',title='Pilot outcome-head optimization (6 instance folds, 3 seeds)')
    ax.legend();ax.grid(alpha=.2);fig.tight_layout();fig.savefig(media/'training_curves.png',dpi=180);plt.close(fig)
    (out/'index.html').write_text('<!doctype html><meta charset="utf-8"><title>Outcome predictor pilot</title><h1>Outcome predictor pilot</h1><p>Entire instances held out. This is classifier training, not a policy robustness result.</p><img width="1000" src="media/2026-11-01/held_instance_results.png"><img width="850" src="media/2026-11-01/training_curves.png"><p><a href="summary.json">Results and limitations</a> | <a href="predictions.json">Out-of-fold predictions</a> | <a href="corpus.json">Corpus provenance</a></p>')
    return summary


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--plan',type=Path,required=True);p.add_argument('--out-dir',type=Path,required=True)
    args=p.parse_args();plan=json.loads(args.plan.read_text())
    if not os.environ.get('SLURM_JOB_ID'):raise RuntimeError('Run backbone extraction and training in a Slurm allocation')
    for name,expected in plan['source_sha256'].items():
        if hashlib.sha256(Path(name).read_bytes()).hexdigest()!=expected:raise RuntimeError('Source changed: '+name)
    torch.set_num_threads(2);torch.set_num_interop_threads(1)
    args.out_dir.mkdir(exist_ok=False)
    corpus=make_corpus(plan['record_indices'],args.out_dir/'corpus.json')
    tensors=extract_features(InteractionOutcomeDataset(args.out_dir/'corpus.json'),args.out_dir/'frozen_features.pt')
    predictions,curves=train(tensors,corpus['records'],args.out_dir,plan['updates'],plan['seeds'])
    summary=report(args.out_dir,corpus,predictions,curves,plan['seeds'])
    print(json.dumps({k:summary[k] for k in ['status','records','instances','success_labels']}),flush=True)


if __name__=='__main__':main()
