"""Complete gain x duration cells using the same frozen grasp prefixes."""
import argparse
import json
from pathlib import Path

from diagnostics.lift_continuation import PROFILES
from probe_lift_handoff import main


if __name__=='__main__':
    parser=argparse.ArgumentParser(add_help=False)
    parser.add_argument('--plan',type=Path,required=True)
    args,_=parser.parse_known_args()
    definitions=json.loads(args.plan.read_text())['profile_definitions']
    allowed={'preserve_closure_gain','settle_steps','lift_steps'}
    for name,row in definitions.items():
        if set(row)!=allowed or row['settle_steps'] not in [0,10] or row['lift_steps']!=40 or row['preserve_closure_gain'] is not True:
            raise ValueError('Unexpected factorial profile: '+name)
    PROFILES.clear();PROFILES.update(definitions)
    main()
