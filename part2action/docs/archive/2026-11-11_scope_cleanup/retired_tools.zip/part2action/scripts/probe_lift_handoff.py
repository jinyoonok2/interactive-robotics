"""Compare fixed continuation changes on the SAME logged expert grasps."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path

from diagnostics.lift_continuation import PROFILES
from diagnostics.interaction_tolerances import conditions, grasp_window
from diagnostics.execution_trace import trace_arrays
from generate_logged_references import replay, REPLAY_LIMITS
from run_interaction_tolerance_pilot import dump


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--plan',type=Path,required=True)
    p.add_argument('--out-dir',type=Path,required=True)
    args=p.parse_args();plan=json.loads(args.plan.read_text())
    for name,expected in plan['source_sha256'].items():
        if hashlib.sha256(Path(name).read_bytes()).hexdigest()!=expected:raise RuntimeError('Source changed: '+name)
    args.out_dir.mkdir(exist_ok=False)
    rows=[]
    for source in plan['cases']:
        directory=Path(source);summary=json.loads((directory/'summary.json').read_text())
        with gzip.open(directory/'generated/execution.json.gz','rt') as f:reference=json.load(f)
        count=summary['generation']['grasp_event_count']
        actions,_,_=trace_arrays(reference['events'][:count])
        window=grasp_window(actions,[summary['case']['instruction']]*len(actions))
        for profile in PROFILES:
            condition=dict(conditions()[0],name='handoff_probe')
            out=args.out_dir/directory.name/profile
            out.parent.mkdir(exist_ok=True)
            row,_,_=replay(Path(plan['data_root']),summary['case'],summary['seed'],reference['events'],count,
                          condition,window,out,reference_initial=reference['initial'],continuation=profile)
            checks={**row['grasp_prefix_agreement'],'initial_state_max_difference':row['initial_state_max_difference']}
            if any(checks[k]>v for k,v in REPLAY_LIMITS.items()):
                raise RuntimeError('Probe changed the original grasp prefix')
            if profile=='legacy':
                baseline=summary['generation']
                differences=[abs(row['lift_m']-baseline['lift_m']),abs(row['hold_relative_position_drift_m']-baseline['hold_relative_position_drift_m'])]
                differences.extend(abs(row['hold'][k]-baseline['hold'][k]) for k in baseline['hold'])
                if max(differences)>1e-9:raise RuntimeError('Legacy continuation does not reproduce source outcome')
            rows.append({'source':source,'case':summary['case'],'profile':profile,
                         'success':row['stable_target_grasp_lift'],'lift_m':row['lift_m'],
                         'hold':row['hold'],'drift_m':row['hold_relative_position_drift_m'],
                         'continuation':row['continuation'],'grasp_prefix_agreement':checks})
            dump(args.out_dir/'summary.json',{'status':'in_progress','rows':rows,'planned_trials':len(plan['cases'])*len(PROFILES)})
            print('[handoff]',directory.name,profile,'success',row['stable_target_grasp_lift'],'lift',row['lift_m'],flush=True)
    dump(args.out_dir/'summary.json',{'status':'completed','rows':rows,'planned_trials':len(rows),
        'limits':['Diagnostic cases selected after observed failures; no category-level success estimate.',
                  'The same logged grasp precedes each continuation; only the predeclared continuation factors change.',
                  'Success thresholds unchanged. These are grasp/lift outcomes, not full-task results.']})


if __name__=='__main__':main()
