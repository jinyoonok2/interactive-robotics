"""Inventory full recorded trajectories, repeat them, and screen baseline eligibility."""
from __future__ import annotations
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

import h5py
import numpy as np

from diagnostics.full_trajectory_baseline import compare_repeats, eligibility, REPEAT_LIMITS

ROOT = Path(__file__).resolve().parents[2]
WORKER = ROOT/'part2action/scripts/replay_full_dataset_trajectory.py'
LAUNCHER = ROOT/'part2action/slurm/collect_full_trajectory_baselines.sbatch'


def dump(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary=path.with_suffix(path.suffix+'.tmp')
    temporary.write_text(json.dumps(value, indent=2)+'\n'); temporary.replace(path)


def prepare(args):
    args.out_dir.mkdir(parents=True, exist_ok=False)
    meta_path=args.data_root/'episodes_meta_train.json'
    meta=json.loads(meta_path.read_text()); cases=[]; skipped=[]
    for obj in ['bottle', 'mug', 'pliers', 'scissors']:
        lookup={str(e['ep_id']):(task,e) for task,rows in meta[obj]['train'].items() for e in rows}
        with h5py.File(args.data_root/'demos'/f'{obj}.hdf5') as handle:
            for key in sorted(handle['data'], key=lambda v:int(v.removeprefix('demo_'))):
                demo=handle['data'][key]
                try:
                    a=demo['actions'][:]
                    assert a.ndim==2 and a.shape[1]==7 and len(a)>0 and np.isfinite(a).all(), 'Invalid actions'
                    ep=demo['metadata/ep_id'][()].decode(); task,episode=lookup[ep]
                    assert str(episode['obj_id'])==demo['metadata/obj_id'][()].decode(), 'Object metadata mismatch'
                    assert np.allclose(episode['obj_pose'],demo['metadata/obj_pose'][()],rtol=0,atol=1e-12), 'Initial pose mismatch'
                    for obs in ['tcp_pose','joint_states','gripper_state']:
                        assert len(demo['obs'][obs])==len(a), 'Observation length mismatch: '+obs
                    assert len(demo['skill_instructions'])==len(a), 'Instruction length mismatch'
                    cases.append({'object':obj,'demo':key,'episode_id':ep,'object_id':str(episode['obj_id']),
                                  'task_type':task,'actions':len(a),
                                  'action_sha256':hashlib.sha256(a.tobytes()).hexdigest()})
                except (KeyError,ValueError,AssertionError) as error:
                    skipped.append({'object':obj,'demo':key,'reason':str(error)})
    pilot=[next(i for i,c in enumerate(cases) if c['object']==obj) for obj in ['bottle','mug','pliers','scissors']]
    pilot.append(next(i for i,c in enumerate(cases) if c['object']=='mug' and c['demo']=='demo_1'))
    files=[Path(__file__),WORKER,LAUNCHER,ROOT/'part2action/diagnostics/full_trajectory_baseline.py',
           ROOT/'part2action/diagnostics/execution_trace.py',
           ROOT/'PartInstruct/PartInstruct/PartGym/config/config_oracle.yaml',
           ROOT/'PartInstruct/PartInstruct/PartGym/env/bullet_env.py',
           ROOT/'PartInstruct/PartInstruct/PartGym/env/backend/bullet_sim.py',
           ROOT/'PartInstruct/PartInstruct/PartGym/env/backend/planner/panda_arm.py',
           ROOT/'PartInstruct/PartInstruct/PartGym/env/backend/planner/bullet_planner.py',
           ROOT/'PartInstruct/PartInstruct/PartGym/env/backend/utils/scene_utils.py',meta_path]
    plan={'data_root':str(args.data_root),'cases':cases,'skipped':skipped,'pilot_indices':pilot,
          'seed':42,'repeats':2,'cases_per_shard':8,'concurrency':4,'repeat_limits':REPEAT_LIMITS,
          'source_sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},
          'protocol':'Full stored actions once each, native defaults, full task context; no generated expert, added task or perturbation. '
                     'Two independent fresh-process executions at the same fixed seed per source. '
                     'Accept successful reproducible full executions; HDF5 path fidelity is not an eligibility criterion.',
          'scope':'All currently used four-object training demonstrations; not all 11 released categories.',
          'pilot_selection':'First source per category plus previously successful mug/demo_1 as a technical positive control; no category success estimate.',
          'auto_expand_after_technical_preflight':True,
          'no_variation_or_training_in_this_stage':True}
    dump(args.out_dir/'plan.json',plan)
    snapshots=args.out_dir/'source_snapshot';snapshots.mkdir()
    for p in files[:-1]:shutil.copy2(p,snapshots/(hashlib.sha256(str(p).encode()).hexdigest()[:10]+'_'+p.name))
    print(json.dumps({'sources':len(cases),'skipped':len(skipped),'pilot':pilot,'plan':str(args.out_dir/'plan.json')}))


def verify(plan):
    for name,expected in plan['source_sha256'].items():
        if hashlib.sha256(Path(name).read_bytes()).hexdigest()!=expected:raise RuntimeError('Source changed: '+name)


def run_case(root,plan,index):
    case=plan['cases'][index];directory=root/'cases'/f'{index:05d}'
    directory.mkdir(parents=True,exist_ok=False)
    started=time.monotonic();summaries=[]
    try:
        for repeat in range(2):
            destination=directory/f'repeat_{repeat}'
            with (directory/f'repeat_{repeat}.log').open('w') as log:
                subprocess.run([sys.executable,str(WORKER),'--data-root',plan['data_root'],
                    '--out-dir',str(destination),'--object',case['object'],'--demo',case['demo'],
                    '--seed',str(plan['seed']),'--no-media'],stdout=log,stderr=subprocess.STDOUT,
                    check=True,timeout=1200)
            manifest=json.loads((destination/'manifest.json').read_text())
            if manifest['action_sha256']!=case['action_sha256']:raise RuntimeError('Source actions changed')
            summaries.append(json.loads((destination/'summary.json').read_text()))
        with np.load(directory/'repeat_0/trajectories.npz') as first, np.load(directory/'repeat_1/trajectories.npz') as second:
            comparison=compare_repeats(first,second)
        row={'status':'completed','case':case,'case_index':index,'repeatability':comparison,
             **eligibility(summaries,comparison),'replays':summaries}
    except (subprocess.SubprocessError,RuntimeError,ValueError,OSError) as error:
        row={'status':'runtime_error','case':case,'case_index':index,'eligible':False,
             'error':type(error).__name__+': '+str(error),'replays':summaries,
             'interpretation':'Collection error, not a physical variation failure label.'}
    row['wall_s']=time.monotonic()-started;dump(directory/'result.json',row)
    print('[baseline]',index,case['object'],case['demo'],row['status'],'eligible',row['eligible'],flush=True)


def report(root,plan):
    rows=[json.loads(p.read_text()) for p in sorted((root/'cases').glob('*/result.json'))]
    counts={obj:{'planned':sum(c['object']==obj for c in plan['cases']),
                 'completed':sum(r['case']['object']==obj for r in rows),
                 'eligible':sum(r['case']['object']==obj and r['eligible'] for r in rows)}
            for obj in ['bottle','mug','pliers','scissors']}
    value={'planned':len(plan['cases']),'finished':len(rows),'eligible':sum(r['eligible'] for r in rows),
           'runtime_errors':sum(r['status']=='runtime_error' for r in rows),'by_object':counts,
           'protocol':plan['protocol'],'skipped':plan['skipped'],
           'eligible_case_indices':[r['case_index'] for r in rows if r['eligible']],
           'status':'completed' if len(rows)==len(plan['cases']) else 'in_progress'}
    dump(root/'summary.json',value)
    lines=['# Full-trajectory baseline screening','',plan['protocol'],'',
           f'Finished {len(rows)}/{len(plan["cases"])} sources; eligible {value["eligible"]}; runtime errors {value["runtime_errors"]}.','',
           'Baseline failures and runtime errors are excluded from the tolerance anchor pool. '
           'They are not negative perturbation examples. No perturbation/training jobs are submitted by this stage.','',
           '[Plan](plan.json) · [Summary](summary.json)','']
    (root/'README.md').write_text('\n'.join(lines))
    return rows,value


def submit(mode,root,dependency=None,array=None):
    env=os.environ.copy();env.update(MODE=mode,STUDY_DIR=str(root))
    command=['sbatch','--parsable']
    if dependency:command.append('--dependency=afterany:'+dependency)
    if array:command.append('--array='+array)
    command.append(str(LAUNCHER))
    result=subprocess.run(command,env=env,text=True,capture_output=True,check=True)
    job=result.stdout.strip().split(';')[0]
    if not job.isdigit():raise RuntimeError('Unexpected scheduler output: '+result.stdout)
    return job


def finish_pilot(root,plan):
    rows,summary=report(root,plan)
    expected=set(plan['pilot_indices'])
    gate=(set(r['case_index'] for r in rows)==expected and
          all(r['status']=='completed' and r['repeatability']['reproducible'] for r in rows) and
          any(r['eligible'] for r in rows))
    decision={'passed':gate,'technical_only':True,'all_categories_need_success':False,'submitted':False,
              'criteria':'All five pairs complete and reproduce their own state trajectories; at least one successful pair. '
                         'Full-dataset screening does not require every preflight source/category to succeed.'}
    if gate:
        target=root.parent/'full';target.mkdir(exist_ok=False)
        (target/'cases').mkdir()
        for index in plan['pilot_indices']:(target/'cases'/f'{index:05d}').symlink_to((root/'cases'/f'{index:05d}').resolve(),target_is_directory=True)
        full={**plan,'remaining_indices':[i for i in range(len(plan['cases'])) if i not in expected],
              'preflight_directory':str(root)}
        dump(target/'plan.json',full)
        shards=math.ceil(len(full['remaining_indices'])/plan['cases_per_shard'])
        job=submit('full',target,array=f'0-{shards-1}%{plan["concurrency"]}')
        reporter=submit('report',target,dependency=job)
        decision.update(submitted=True,full_job=job,report_job=reporter,shards=shards,
                        remaining_sources=len(full['remaining_indices']),directory=str(target))
        dump(target/'submissions.json',decision);report(target,full)
    dump(root/'expansion_decision.json',decision)
    print('[preflight-decision]',json.dumps(decision),flush=True)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--mode',choices=['prepare','pilot','finish','full','report'],required=True)
    p.add_argument('--out-dir',type=Path,required=True)
    p.add_argument('--data-root',type=Path)
    p.add_argument('--shard-index',type=int)
    args=p.parse_args()
    if args.mode=='prepare':prepare(args);return
    plan=json.loads((args.out_dir/'plan.json').read_text());verify(plan)
    if args.mode=='report':report(args.out_dir,plan);return
    if args.mode=='finish':finish_pilot(args.out_dir,plan);return
    if args.shard_index is None:p.error('--shard-index required')
    if args.mode=='pilot':indices=[plan['pilot_indices'][args.shard_index]]
    else:
        start=args.shard_index*plan['cases_per_shard']
        indices=plan['remaining_indices'][start:start+plan['cases_per_shard']]
    for index in indices:run_case(args.out_dir,plan,index)


if __name__=='__main__':main()
