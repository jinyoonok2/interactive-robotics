"""Compare explicit controller hypotheses on fresh CPU simulator scenes.

Calibration only: no perturbation labels, no relaxed replay limits, no policy.
The original pilot, snapshots and results remain unchanged.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
from unittest.mock import patch

import numpy as np
import run_interaction_tolerance_pilot as pilot
from diagnostics.interaction_tolerances import conditions
from diagnostics.replay_validation import PROFILES, gain_hypothesis, repeat_metrics


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--pilot-dir',type=Path,required=True)
    p.add_argument('--out-dir',type=Path,required=True)
    p.add_argument('--case-index',type=int,required=True)
    p.add_argument('--repeats',type=int,default=2)
    args=p.parse_args()
    out=args.out_dir;out.mkdir(parents=True,exist_ok=False)
    manifest=json.loads((args.pilot_dir/'manifest.json').read_text())
    case=manifest['cases'][args.case_index]
    record={'case':case,'case_index':args.case_index,'profiles':{},'status':'running',
        'restoration':'independent fresh native scene for every repeat/profile, identical construction seed',
        'eligibility_thresholds_unchanged':pilot.THRESHOLDS,
        'limits':['Exploratory controller calibration; not independent validation or perturbation outcomes.',
                  '15 cm approach threshold is an inferred hypothesis, not recorded controller metadata.',
                  'Fresh scene comparison tests the whole reconstruction path; it does not isolate a specific Bullet cache.'],
        'source_sha256':{str(q):hashlib.sha256(q.read_bytes()).hexdigest() for q in [
            Path(__file__),Path(pilot.__file__),Path(pilot.ROOT/'part2action/diagnostics/replay_validation.py')]}}
    pilot.dump(out/'probe.json',record)
    for profile in PROFILES:
        group={'trials':[],'repeatability':[]};first=None;first_finger=None
        directory=out/profile;directory.mkdir()
        for repeat in range(args.repeats):
            scene=pilot.Scene.__new__(pilot.Scene)
            try:
                scene.__init__(Path(manifest['data_root']),case,manifest['seed']+args.case_index)
                def schedule(actions,window):return gain_hypothesis(actions,window,profile)
                with patch.object(pilot,'controller_gains',schedule):
                    row,tcp=pilot.replay(scene,case,conditions()[0],directory/f'repeat_{repeat}')
                group['trials'].append(row)
                with np.load(directory/f'repeat_{repeat}.npz') as data:
                    finger=data['fingers'].copy()
                if first is None:first=tcp;first_finger=finger
                else:group['repeatability'].append(repeat_metrics(first,tcp,first_finger,finger))
                record['profiles'][profile]=group;pilot.dump(out/'probe.json',record)
                print('[probe]',case['object'],case['demo'],profile,repeat,
                      json.dumps({'tracking':row['tracking'],'fidelity':row['replay_fidelity_pass'],
                                  'native_grasp':row['native_grasp_predicate_equivalent'],
                                  'stable_lift':row['stable_target_grasp_lift'],'repeatability':group['repeatability']}),flush=True)
            finally:scene.close()
    record['status']='completed';pilot.dump(out/'probe.json',record)


if __name__=='__main__':main()
