"""Validate two alternative native grasp proposals, without controller tuning."""
import argparse
import functools
import json
import os
from pathlib import Path

import generate_logged_references as generator
from diagnostics.grasp_proposals import ranked_indices


if __name__=='__main__':
    parser=argparse.ArgumentParser(add_help=False)
    parser.add_argument('--plan',type=Path,required=True)
    parser.add_argument('--out-dir',type=Path,required=True)
    parser.add_argument('--case-index',type=int,required=True)
    args,_=parser.parse_known_args();plan=json.loads(args.plan.read_text())
    rank=int(os.environ['PROPOSAL_RANK'])
    if {'case_index':args.case_index,'proposal_rank':rank} not in plan['proposal_trials']:
        raise ValueError('Unplanned grasp proposal')
    if not plan.get('native_task_context') or not plan.get('disable_wall_timeout'):
        raise ValueError('Original task context with explicit CPU iteration-budget policy required')
    _,planner=generator.native_classes()
    from PartInstruct.PartGym.env.backend.utils.transform import pose_distance
    native_pose=planner.pose_tcp;native_target=planner.target_grasp
    @functools.wraps(native_pose)
    def pose(self,*values,**kwargs):
        kwargs['timeout']=None
        return native_pose(self,*values,**kwargs)
    @functools.wraps(native_target)
    def target(self,target_pose,grasps,scores,**kwargs):
        _,_,distance_scale=self.env.obj.get_bbox()
        distances=[pose_distance(g.pose,target_pose,orientation_weight=0.) for g in grasps]
        ranking=ranked_indices(scores,distances,distance_scale,kwargs.get('thred',.5),kwargs.get('score_weight',.5))
        bank={'selected_native_rank_zero_based':rank,'selected_available':rank<len(ranking),
              'native_ranking':ranking,'proposal_poses_xyzw_xyz':[g.pose.to_list().tolist() for g in grasps],
              'native_vgn_scores':[float(s) for s in scores],
              'scope':'Same native candidate bank and score; select one alternative proposal, not a new gain or threshold.'}
        generator.dump(args.out_dir/'cases'/f'{args.case_index:05d}'/'proposal_bank.json',bank)
        if rank>=len(ranking):return native_target(self,target_pose,[],[],**kwargs)
        chosen=ranking[rank][0]
        return native_target(self,target_pose,[grasps[chosen]],[scores[chosen]],**kwargs)
    planner.pose_tcp=pose;planner.target_grasp=target
    generator.main()
    directory=args.out_dir/'cases'/f'{args.case_index:05d}'
    result=json.loads((directory/'summary.json').read_text())
    generated=result.get('generation',{})
    eligible=bool(result.get('eligible') and generated.get('planner_reported_success') and generated.get('native_grasp_predicate_equivalent'))
    generator.dump(directory/'proposal_validation.json',{
        'eligible':eligible,
        'native_rank_zero_based':rank,'base_reference_checks':result.get('reference_checks'),
        'require_native_grasp_and_stable_lift_and_exact_replay':True,
        'limits':'Training-source rejection sampling. No per-case controller changes or automatic dataset expansion.'})
    index=directory/'records.json'
    if index.exists():
        records=json.loads(index.read_text())
        records['native_reference_admissible']=eligible
        if not eligible:records['validation_status']='rejected_native_reference'
        generator.dump(index,records)
