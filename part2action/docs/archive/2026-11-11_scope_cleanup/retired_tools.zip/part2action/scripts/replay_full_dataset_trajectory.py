"""Replay every stored action once with native PartGym defaults; no added tasks."""
from __future__ import annotations

import argparse
import copy
import csv
import hashlib
import inspect
import json
import random
import sys
import time
from pathlib import Path
from types import MethodType

import h5py
import numpy as np
from scipy.spatial.transform import Rotation

ROOT = Path(__file__).resolve().parents[2]


def decode(value):
    return value.decode() if isinstance(value, bytes) else str(value)


def dump(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data-root', type=Path, required=True)
    parser.add_argument('--out-dir', type=Path, required=True)
    parser.add_argument('--object', default='mug')
    parser.add_argument('--demo', default='demo_1')
    parser.add_argument('--seed', type=int, default=42)
    parser.add_argument('--no-media', action='store_true', help='Collect full states without RGB rendering or report images')
    args = parser.parse_args()
    out = args.out_dir
    out.mkdir(parents=True, exist_ok=False)
    started = time.monotonic()
    random.seed(args.seed)
    np.random.seed(args.seed)
    source = args.data_root / 'demos' / (args.object + '.hdf5')
    with h5py.File(source, 'r') as handle:
        demo = handle['data'][args.demo]
        actions = demo['actions'][:]
        keys = ['tcp_pose', 'joint_states', 'gripper_state']
        if not args.no_media: keys.append('agentview_rgb')
        recorded = {name: demo['obs'][name][:] for name in keys}
        instructions = [decode(v) for v in demo['skill_instructions'][:]]
        episode_id = decode(demo['metadata/ep_id'][()])
        object_id = decode(demo['metadata/obj_id'][()])
        hdf_pose = demo['metadata/obj_pose'][()].tolist()
        hdf_scale = float(demo['metadata/obj_scale'][()])
    assert actions.ndim == 2 and actions.shape[1] == 7 and np.isfinite(actions).all()
    assert all(len(v) == len(actions) for v in recorded.values())
    assert len(instructions) == len(actions)
    meta_path = args.data_root / 'episodes_meta_train.json'
    metadata = json.loads(meta_path.read_text())
    matches = [(task, episode) for task, episodes in metadata[args.object]['train'].items()
               for episode in episodes if str(episode['ep_id']) == episode_id]
    assert len(matches) == 1
    task, episode = matches[0]
    assert str(episode['obj_id']) == object_id
    assert np.allclose(episode['obj_pose'], hdf_pose, rtol=0, atol=1e-12)
    assert episode['obj_scale'] == hdf_scale
    manifest = {'status': 'initializing', 'source': str(source), 'demo': args.demo,
                'object': args.object, 'object_id': object_id, 'episode_id': episode_id,
                'task_type': task, 'episode': episode, 'seed': args.seed,
                'action_count': len(actions), 'action_sha256': hashlib.sha256(actions.tobytes()).hexdigest(),
                'media_enabled': not args.no_media,
                'recorded_skill_transitions': [{'index': i, 'instruction': instruction}
                    for i, instruction in enumerate(instructions)
                    if i == 0 or instruction != instructions[i-1]],
                'protocol': 'All stored actions, original order, once each via env.step(action). '
                            'Native defaults; full task context; continue to final stored action even if done. '
                            'No planner, inferred gain schedule, perturbation, extra lift, or appended hold.',
                'limitations': ['Native current defaults are not claimed to recover original per-frame controller settings.',
                               'One source demonstration; no dataset-wide success claim.',
                               'Compare recorded observation[t] against post-action state[t]; retain before states too.']}
    dump(out / 'manifest.json', manifest)

    sys.path.insert(0, str(ROOT / 'PartInstruct'))
    import open3d as o3d
    import torch
    from omegaconf import OmegaConf
    from PartInstruct.PartGym.env.bullet_env import BulletEnv
    from diagnostics.execution_trace import ExecutionTrace, physical_state, plain
    o3d.utility.random.seed(args.seed)
    torch.manual_seed(args.seed)

    class ReplayEnv(BulletEnv):
        def _get_observation(self):
            return {'tcp_pose': self.robot.get_tcp_pose().to_list(),
                    'joint_states': np.asarray(self.robot.get_joint_states()),
                    'gripper_state': np.array([self.robot.get_gripper_state()])}

    config_path = ROOT / 'PartInstruct/PartInstruct/PartGym/config/config_oracle.yaml'
    config = OmegaConf.load(config_path)
    config.data_root = str(args.data_root)
    config.meta_path = 'episodes_meta_train.json'
    config.device = 'cpu'
    config.shape_meta.obs = {k: v for k, v in config.shape_meta.obs.items()
                             if k in {'tcp_pose', 'joint_states', 'gripper_state'}}
    env = ReplayEnv(config=config, gui=False, evaluation=True, skill_mode=False,
                    obj_class=args.object, split='train', task_type=task, record=False)

    def select(self):
        self.obj_id = str(episode['obj_id'])
        self.ep_id = episode['ep_id']
        self.chain_params = copy.deepcopy(episode['chain_params'])
        self.task_instruction = episode['task_instruction']
        self.skill_instructions = list(episode['skill_instructions'])
        self.obj_init_position = list(hdf_pose[4:])
        self.obj_init_orientation = list(hdf_pose[:4])
        self.obj_scale = hdf_scale

    trace = None
    frames = []
    try:
        env.sample_chain_params = MethodType(select, env)
        env.seed(args.seed)
        env.reset()
        assert str(env.ep_id) == episode_id and str(env.obj_id) == object_id
        trace = ExecutionTrace(env)
        dump(out / 'initial_state.json', plain(trace.initial))
        manifest.update(status='running', native_step_signature=str(inspect.signature(BulletEnv.step)),
                        native_apply_signature=str(trace.apply_signature),
                        control_hz=env.control_hz, simulation_hz=env.sim_hz,
                        physics_steps_per_action=env.world.n_steps_per_control,
                        source_sha256={str(p): hashlib.sha256(p.read_bytes()).hexdigest()
                            for p in [Path(__file__), config_path, Path(inspect.getfile(BulletEnv)),
                                      Path(inspect.getfile(type(env.robot))), Path(inspect.getfile(type(env.world))),
                                      ROOT / 'part2action/diagnostics/execution_trace.py']})
        # Record the effective motor gains too: native positional-argument wiring is untouched.
        dump(out / 'config_resolved.json', OmegaConf.to_container(config, resolve=True))
        dump(out / 'manifest.json', manifest)
        view = env.world.p.computeViewMatrixFromYawPitchRoll(
            cameraTargetPosition=list(config.cam_static_target), distance=config.cam_static_dist,
            yaw=config.cam_static_yaw, pitch=config.cam_static_pitch, roll=0,
            upAxisIndex=config.up_axis_index)
        projection = env.world.p.computeProjectionMatrixFOV(fov=60, aspect=1,
                                                          nearVal=config.cam_near, farVal=config.cam_far)
        if not args.no_media:
            import imageio.v2 as imageio
            from PIL import Image, ImageDraw
        before, after, rows = [], [], []
        initial_sim_time = env.world.sim_time
        for index, action in enumerate(actions):
            before.append(physical_state(env))
            event_start = len(trace.events)
            # Intentionally no kwargs, no action transform, no done-based early break.
            _, _, done, info = env.step(action.copy())
            trace.finish_action()
            state = physical_state(env)
            command_events = [e for e in trace.events[event_start:] if e['kind'] == 'action']
            assert len(command_events) == 1
            command_events[0]['after_env_step'] = state
            after.append(state)
            error = float(np.linalg.norm(np.asarray(state['tcp_xyzw_xyz'][4:]) - recorded['tcp_pose'][index, 4:]))
            angle = float(np.rad2deg((Rotation.from_quat(recorded['tcp_pose'][index, :4]).inv() *
                                     Rotation.from_quat(state['tcp_xyzw_xyz'][:4])).magnitude()))
            rows.append({'index': index, 'instruction': instructions[index],
                         'sim_time_s': env.world.sim_time-initial_sim_time,
                         'native_success': bool(done), 'completion_rate': float(info['Completion Rate']),
                         'tcp_error_mm': error * 1000, 'tcp_rotation_error_deg': angle,
                         'finger_error_mm': abs(state['finger_m'] - float(recorded['gripper_state'][index, 0])) * 1000})
            if not args.no_media:
                rendered = env.world.p.getCameraImage(width=300, height=300, viewMatrix=view,
                              projectionMatrix=projection, renderer=env.world.p.ER_TINY_RENDERER)
                rgb = np.asarray(rendered[2], dtype=np.uint8).reshape(300, 300, 4)[:, :, :3]
                canvas = Image.new('RGB', (600, 355), '#172b3d')
                canvas.paste(Image.fromarray(recorded['agentview_rgb'][index]), (0, 45))
                canvas.paste(Image.fromarray(rgb), (300, 45))
                draw = ImageDraw.Draw(canvas)
                draw.text((8, 4), f'Recorded dataset | frame {index}/{len(actions)-1}', fill='white')
                draw.text((308, 4), f'Full action replay | TCP error {error*1000:.1f} mm', fill='white')
                draw.text((8, 23), instructions[index], fill='white')
                frames.append(np.asarray(canvas))
            if index % 20 == 0 or index == len(actions)-1:
                dump(out / 'progress.json', {'executed': index+1, 'total': len(actions), 'last': rows[-1]})
                print('[full-replay]', json.dumps(rows[-1]), flush=True)

        applied = np.asarray([event['action'] for event in trace.events if event['kind'] == 'action'])
        assert np.array_equal(applied, actions), 'Applied commands differ from full source sequence'
        # Native predicate_touching itself calls world.step(). Keep that native
        # behavior; assert full command coverage, not an invented fixed total.
        nominal_steps = len(actions) * env.world.n_steps_per_control
        assert trace.physics_steps >= nominal_steps
        dump(out / 'execution.json', plain({'initial': trace.initial, 'events': trace.events}))
        np.savez_compressed(out / 'trajectories.npz', actions=actions, applied_actions=applied,
            recorded_tcp=recorded['tcp_pose'], recorded_joints=recorded['joint_states'],
            recorded_fingers=recorded['gripper_state'],
            before_tcp=np.asarray([v['tcp_xyzw_xyz'] for v in before]),
            replay_tcp=np.asarray([v['tcp_xyzw_xyz'] for v in after]),
            replay_joints=np.asarray([v['robot_q'][:7] for v in after]),
            replay_fingers=np.asarray([v['finger_m'] for v in after]),
            object_xyz=np.asarray([v['object_xyz'] for v in after]),
            object_xyzw=np.asarray([v['object_xyzw'] for v in after]),
            object_joints=np.asarray([v['object_joints'] for v in after]),
            native_success=np.asarray([r['native_success'] for r in rows]))
        with (out / 'per_frame.csv').open('w') as handle:
            writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
            writer.writeheader(); writer.writerows(rows)
        if not args.no_media:
            imageio.mimsave(out / 'recorded_vs_full_replay.gif', frames, duration=1/env.control_hz, loop=0)
            Image.fromarray(frames[0]).save(out / 'first_frame.png')
            Image.fromarray(frames[-1]).save(out / 'last_frame.png')
        errors = np.asarray([r['tcp_error_mm'] for r in rows])
        success_indices = [r['index'] for r in rows if r['native_success']]
        joint_error = np.asarray([v['robot_q'][:7] for v in after]) - recorded['joint_states']
        result = {'status': 'completed', 'object': args.object, 'demo': args.demo,
                  'episode_id': episode_id, 'task_instruction': episode['task_instruction'],
                  'source_action_count': len(actions), 'executed_action_count': len(applied),
                  'all_actions_identical_and_in_order': True, 'physics_steps': trace.physics_steps,
                  'nominal_action_physics_steps': nominal_steps,
                  'native_internal_additional_physics_steps': trace.physics_steps-nominal_steps,
                  'native_task_success_any': bool(success_indices),
                  'native_task_success_final': rows[-1]['native_success'],
                  'first_success_index': success_indices[0] if success_indices else None,
                  'final_completion_rate': rows[-1]['completion_rate'],
                  'tcp_position_rmse_mm': float(np.sqrt(np.mean(errors**2))),
                  'tcp_position_max_mm': float(errors.max()),
                  'first_tcp_error_over_10mm_index': next((r['index'] for r in rows if r['tcp_error_mm'] > 10), None),
                  'tcp_rotation_p95_deg': float(np.percentile([r['tcp_rotation_error_deg'] for r in rows], 95)),
                  'finger_rmse_mm': float(np.sqrt(np.mean(np.asarray([r['finger_error_mm'] for r in rows])**2))),
                  'arm_joint_rmse_rad': float(np.sqrt(np.mean(joint_error**2))),
                  'wall_s': time.monotonic()-started, 'limitations': manifest['limitations'],
                  'protocol': manifest['protocol']}
        dump(out / 'summary.json', result)
        if args.no_media:
            manifest['status'] = 'completed'; dump(out / 'manifest.json', manifest)
            print('[completed]', json.dumps(result), flush=True)
            return
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        fig, axes = plt.subplots(3, 1, figsize=(10, 8), sharex=True)
        for dimension, label in enumerate(['X', 'Y', 'Z']):
            axes[0].plot(recorded['tcp_pose'][:, 4+dimension], label=f'Recorded {label}')
            axes[0].plot([v['tcp_xyzw_xyz'][4+dimension] for v in after], '--', label=f'Replay {label}')
        axes[0].set_ylabel('TCP position (m)'); axes[0].legend(ncol=3, fontsize=8)
        axes[1].plot(errors); axes[1].set_ylabel('TCP error (mm)')
        axes[2].plot(recorded['gripper_state'][:, 0]*1000, label='Recorded')
        axes[2].plot(np.asarray([v['finger_m'] for v in after])*1000, '--', label='Replay')
        axes[2].set(ylabel='Finger opening (mm)', xlabel='Original dataset action index'); axes[2].legend()
        for ax in axes:
            ax.grid(alpha=.2)
            for transition in manifest['recorded_skill_transitions'][1:]: ax.axvline(transition['index'], color='gray', alpha=.4)
        fig.suptitle(f'{args.object}/{args.demo}: every stored action, native defaults, no added task')
        fig.tight_layout(); fig.savefig(out / 'trajectory_comparison.png', dpi=160); plt.close(fig)
        (out / 'README.md').write_text(
            '# Full recorded-action replay\n\n' + episode['task_instruction'] + '\n\n' + manifest['protocol'] +
            '\n\nExecuted **' + str(len(applied)) + '/' + str(len(actions)) + '** unchanged actions. '
            'Native task success (any/final): **' + str(result['native_task_success_any']) + '/' +
            str(result['native_task_success_final']) + '**.\n\n'
            '![Recorded vs replay](recorded_vs_full_replay.gif)\n\n'
            '![Trajectory comparison](trajectory_comparison.png)\n\n'
            '[Per-frame data](per_frame.csv) · [Summary](summary.json) · [Protocol](manifest.json)\n\n' +
            '\n'.join('- ' + value for value in manifest['limitations']) + '\n')
        manifest['status'] = 'completed'; dump(out / 'manifest.json', manifest)
        print('[completed]', json.dumps(result), flush=True)
    except BaseException as error:
        dump(out / 'error.json', {'type': type(error).__name__, 'message': str(error)})
        raise
    finally:
        if trace is not None: trace.close()
        env.close()


if __name__ == '__main__':
    main()
