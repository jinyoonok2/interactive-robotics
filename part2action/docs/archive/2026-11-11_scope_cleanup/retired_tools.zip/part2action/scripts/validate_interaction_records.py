"""Check pre-intervention records and paired observation-on/off identity replay."""
import argparse
import json
from pathlib import Path
import numpy as np


def validate(captured, control):
    manifest=json.loads((captured/'manifest.json').read_text())
    index=json.loads((captured/'records.json').read_text())
    summary=json.loads((captured/'summary.json').read_text())
    if summary['status']!='completed' or summary['eligible_cases']!=1:
        raise ValueError('Captured collection did not pass its reference gate')
    if len(index['records'])!=9:raise ValueError('Expected three references plus six candidate trials')
    outcomes=[];max_difference=0.
    for record in index['records']:
        row=json.loads((captured/record['result_file']).read_text());outcomes.append(row['stable_target_grasp_lift'])
        with np.load(captured/record['observation_file'],allow_pickle=False) as obs:
            assert obs['rgb'].shape==(2,3,300,300) and obs['rgb'].dtype==np.uint8
            assert obs['pcd_camera_m'].shape==(2,1024,3) and np.isfinite(obs['pcd_camera_m']).all()
            assert obs['rgb'].std()>1 and np.all(obs['pcd_camera_m'][...,2]>0)
            assert list(obs['frame'])==[max(0,row['decision_frame']-1),row['decision_frame']]
            assert not any('mask' in key or 'contact' in key or 'object_id' in key for key in obs.files)
            arrays={key:obs[key].copy() for key in ['rgb','tcp_pose_xyzw_xyz','finger_position_m']}
        # Every candidate observes the identical pre-intervention prefix.
        if record==index['records'][0]:first=arrays
        for key in arrays:np.testing.assert_array_equal(arrays[key],first[key])
    if not any(outcomes) or all(outcomes):raise ValueError('The collection check requires both outcome classes')
    captured_case=next(captured.glob('case_*'));control_case=next(control.glob('case_*'))
    for repeat in range(3):
        with np.load(captured_case/f'baseline_{repeat}.npz') as a,np.load(control_case/f'baseline_{repeat}.npz') as b:
            for key in ['tcp','fingers','actions']:
                difference=float(np.max(np.abs(a[key]-b[key])));max_difference=max(max_difference,difference)
                np.testing.assert_allclose(a[key],b[key],atol=1e-9,rtol=0)
    result={'status':'passed','records':len(outcomes),'successful_records':sum(outcomes),
            'failed_records':len(outcomes)-sum(outcomes),'capture_on_off_max_difference':max_difference,
            'pre_intervention_observations_equal':True,
            'limits':['One object instance; insufficient for held-out learning or generalization.',
                      'TinyRenderer and deterministic full-scene sampling are an explicit prototype sensor protocol.']}
    from PIL import Image
    Image.fromarray(first['rgb'][-1].transpose(1,2,0)).save(captured/'decision_observation_preview.png')
    (captured/'record_validation.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--captured',type=Path,required=True);p.add_argument('--control',type=Path,required=True)
    args=p.parse_args();validate(args.captured,args.control)
