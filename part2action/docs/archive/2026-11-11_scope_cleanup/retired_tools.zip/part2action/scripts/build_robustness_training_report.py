"""Compatibility launcher for the current November 2 slide-history deck."""
from pathlib import Path
import runpy

if __name__ == '__main__':
    root = Path(__file__).resolve().parents[2]
    runpy.run_path(str(root / 'part2action/docs/slide_history/scripts/build_20261102_research_update.py'), run_name='__main__')
