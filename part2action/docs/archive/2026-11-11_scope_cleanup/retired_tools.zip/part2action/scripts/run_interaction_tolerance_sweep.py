"""Queue/run a finite sequence of single-variable grasp perturbation levels.

Reuses the reference-gated collector unchanged. A process/reference failure
halts the sequence; a physical perturbation failure is an outcome, not a job
failure. Run all planned levels to expose possible nonmonotonic outcomes.
"""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parents[2]
PYTHON = '/p/part2action/envs/partgym_rollout/bin/python'


def dump(path, value):
    temp=path.with_suffix('.tmp')
    temp.write_text(json.dumps(value,indent=2)+'\n');temp.replace(path)


def levels(scales, cases):
    if not scales or any(type(s) is not int or s <= 0 for s in scales) or sorted(set(scales)) != scales:
        raise ValueError('Scales must be positive, unique integers in increasing order')
    result=[]
    for scale in scales:
        offset=2*scale
        # Keep a real closure onset inside the stored grasp segment in both
        # directions; no no-close trajectory may become a false failure label.
        if any(offset >= min(c['window']['close'], c['window']['end']-c['window']['close']) for c in cases):
            raise ValueError('Timing offset would remove the open/close onset from a source segment')
        result.append({'name':f'level_{scale:02d}', 'translation_m':scale*.01,
                       'rotation_deg':scale*10., 'close_offset_steps':offset})
    return result


def usable_run(path):
    manifest=json.loads((path/'manifest.json').read_text())
    summary=json.loads((path/'summary.json').read_text())
    results=json.loads((path/'results.json').read_text())
    if summary['status'] != 'completed' or not results or not all(r.get('eligible') and not r.get('error') for r in results):
        raise ValueError(f'Run incomplete or reference invalid: {path}')
    expected=len(results)*(len(manifest['conditions'])-1)*manifest['repeats']
    if summary['perturbation_trials'] != expected:
        raise ValueError(f'Incomplete perturbation count: {path}')
    return manifest,summary


def magnitude(condition, hz=20.):
    if any(condition['translation_m']):
        return max(abs(x) for x in condition['translation_m'])*100,'cm'
    if any(condition['rotation_deg']):
        return max(abs(x) for x in condition['rotation_deg']),'deg'
    return abs(condition['close_offset_steps'])/hz,'s'


def boundary_rows(observations):
    """Sampled failures only; never claim a continuous or monotone boundary."""
    groups={}
    for row in observations:
        if not row['trials']: continue
        groups.setdefault(row['condition'],[]).append(row)
    output=[]
    for name,rows in sorted(groups.items()):
        rows=sorted(rows,key=lambda r:r['magnitude'])
        bad=[r for r in rows if r['trials'] and r['successes'] < r['trials']]
        first=bad[0] if bad else None
        earlier=[r for r in rows if first and r['magnitude'] < first['magnitude'] and r['trials'] and r['successes']==r['trials']]
        recovery=any(first and r['magnitude']>first['magnitude'] and r['trials'] and r['successes']==r['trials'] for r in rows)
        output.append({'condition':name,'unit':rows[0]['unit'],
            'last_sampled_all_success_below_first_failure':earlier[-1]['magnitude'] if earlier else None,
            'first_sampled_failure':first['magnitude'] if first else None,
            'success_at_larger_tested_offset_after_failure':bool(recovery),
            'largest_tested_magnitude':rows[-1]['magnitude']})
    return output


def report(plan, status):
    out=Path(plan['out_dir']); observed=[]; columns=[]
    paths=[Path(p) for p in plan['prior_runs']]+[out/level['name'] for level in plan['levels']]
    for path in paths:
        if not (path/'summary.json').exists(): continue
        manifest=json.loads((path/'manifest.json').read_text())
        summary=json.loads((path/'summary.json').read_text())
        if summary['status'] != 'completed': continue
        values=[]
        for condition in manifest['conditions'][1:]:
            counts=summary['conditions'][condition['name']]
            amount,unit=magnitude(condition,manifest['control_hz_assumption'])
            row={'run':str(path),'condition':condition['name'],'magnitude':amount,'unit':unit,**counts}
            observed.append(row);values.append(row)
        columns.append(values)
    boundaries=boundary_rows(observed)
    dump(out/'sweep_summary.json',{'status':status,'planned_levels':plan['levels'],
        'completed_levels':sum((out/level['name']/'summary.json').exists() and json.loads((out/level['name']/'summary.json').read_text())['status']=='completed' for level in plan['levels']),
        'observations':observed,'sampled_boundaries':boundaries,
        'limits':['One source grasp; exact repeats are not independent scenes.',
                  'Offsets change one variable at a time; no joint interactions tested.',
                  'First sampled failure does not establish monotonicity or a continuous boundary.',
                  'Controller-conditioned expert replay, not learned-policy robustness.']})
    for filename,rows in [('outcomes.csv',observed),('sampled_boundaries.csv',boundaries)]:
        if rows:
            with (out/filename).open('w',newline='') as f:
                writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    if columns:
        sys.path.insert(0,str(ROOT/'part2action/docs/slide_history/scripts'))
        from export_slide_tables import render
        header=['Direction']
        for column in columns:
            by_unit={r['unit']:r['magnitude'] for r in column}
            header.append(f'{by_unit["cm"]:g} cm / {by_unit["deg"]:g} deg / {by_unit["s"]:g} s')
        table=[header]
        for name in sorted({r['condition'] for r in observed}):
            table.append([name.replace('translation_m','Position').replace('rotation_deg','Wrist').replace('_',' ')]+
                [next((f'{r["successes"]}/{r["trials"]}' for r in col if r['condition']==name),'--') for col in columns])
        media=out/'media'/plan['media_date'];media.mkdir(parents=True,exist_ok=True)
        render(table,[.28]+[.72/len(columns)]*len(columns),media/'sweep_outcomes.png')
        image=f'media/{plan["media_date"]}/sweep_outcomes.png'
        (out/'index.html').write_text(f'<!doctype html><title>Grasp offset sweep</title><h1>Single-variable grasp offset sweep</h1><p>Status: {status}</p><img width="1300" src="{image}"><p>Use this image: <a href="{image}">sweep_outcomes.png</a></p><p>Each column lists three independent magnitudes; each trial changes only one variable.</p><p>Counts are fixed-scene repeats, not independent success probabilities. First sampled failure does not certify a continuous boundary.</p><p><a href="outcomes.csv">Outcomes CSV</a> | <a href="sampled_boundaries.csv">Sampled failures CSV</a> | <a href="sweep_summary.json">Summary</a></p>')


def run(plan_path):
    plan=json.loads(plan_path.read_text());out=Path(plan['out_dir'])
    for name,expected in plan['source_sha256'].items():
        if hashlib.sha256((ROOT/name).read_bytes()).hexdigest()!=expected:
            raise RuntimeError('Source changed after submission: '+name)
    source=Path(plan['case_manifest'])
    if hashlib.sha256(source.read_bytes()).hexdigest()!=plan['case_manifest_sha256']:
        raise RuntimeError('Source case manifest changed')
    # Dependency success alone does not establish that reference replay passed.
    original=json.loads(source.read_text())
    for path in plan['prior_runs']:
        previous,_=usable_run(Path(path))
        for key in ['cases','seed','fidelity_thresholds','controller','continuation','state_restoration','control_hz_assumption']:
            if previous[key]!=original[key]:
                raise ValueError(f'Prior run differs in {key}: {path}')
    report(plan,'running')
    try:
        for level in plan['levels']:
            command=[PYTHON,str(ROOT/'part2action/scripts/run_interaction_tolerance_pilot.py'),
                '--out-dir',str(out/level['name']),'--cases-manifest',str(source),'--fresh-scenes',
                '--seed',str(plan['seed']),'--repeats','3',
                '--translation-m',str(level['translation_m']),'--rotation-deg',str(level['rotation_deg']),
                '--close-offset-steps',str(level['close_offset_steps'])]
            print('[sweep] start',level['name'],flush=True)
            with (out/f'{level["name"]}.log').open('x') as log:
                subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True)
            usable_run(out/level['name']);report(plan,'running')
            print('[sweep] completed',level['name'],flush=True)
        report(plan,'completed')
    except Exception as exc:
        report(plan,'failed')
        dump(out/'error.json',{'error':repr(exc)})
        raise


def submit(args):
    previous=args.previous_run.resolve(strict=True)
    manifest_path=previous/'manifest.json'
    manifest=json.loads(manifest_path.read_text())
    if manifest['split']!='training only' or manifest['state_restoration']!='fresh native scene for every trial':
        raise ValueError('Require the fixed training-only fresh-scene reference protocol')
    if len(manifest['cases']) != 1:
        raise ValueError('This first boundary sweep is scoped to one validated source case')
    planned=levels(args.scales,manifest['cases'])
    prior=[str(p.resolve(strict=True)) for p in args.prior_run]+[str(previous)]
    out=args.out_dir.resolve()
    if out.exists():raise FileExistsError('Choose a fresh sweep directory')
    plan={'out_dir':str(out),'media_date':datetime.now(ZoneInfo('America/New_York')).strftime('%Y-%m-%d'),
          'created_at_utc':datetime.now(timezone.utc).isoformat(),'case_manifest':str(manifest_path),
          'case_manifest_sha256':hashlib.sha256(manifest_path.read_bytes()).hexdigest(),
          'seed':manifest['seed'],'cases':manifest['cases'],'levels':planned,'prior_runs':prior,
          'planned_reference_trials':3*len(planned),'planned_perturbation_trials':42*len(planned),
          'stop_rule':'Complete all finite levels even if physical perturbations fail; stop on runtime errors or invalid identity references.',
          'source_sha256':{},'jobs':[]}
    names=list(manifest['source_sha256'])+[
        'part2action/scripts/run_interaction_tolerance_sweep.py',
        'part2action/slurm/interaction_tolerance_sweep.sbatch',
        'part2action/docs/slide_history/scripts/export_slide_tables.py',
        'part2action/docs/slide_history/scripts/media_bundle.py']
    for name in names:
        plan['source_sha256'][name]=hashlib.sha256((ROOT/name).read_bytes()).hexdigest()
    for name,expected in manifest['source_sha256'].items():
        if plan['source_sha256'][name]!=expected:
            raise RuntimeError('Collector/controller changed since the previous level: '+name)
    if args.dry_run:
        print(json.dumps(plan,indent=2));return
    out.mkdir(parents=True)
    for name in names:
        target=out/'source_snapshot'/name;target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(ROOT/name,target)
    path=out/'sweep_plan.json';dump(path,plan)
    command=['sbatch','--parsable','--no-requeue','--export=ALL,SWEEP_PLAN='+str(path)]
    if args.dependency:command.append('--dependency=afterok:'+args.dependency)
    command.append('part2action/slurm/interaction_tolerance_sweep.sbatch')
    job=subprocess.check_output(command,cwd=ROOT,text=True).strip().split(';')[0]
    plan['jobs']=[{'job_id':job,'command':command}];dump(path,plan)
    from register_result import register
    register('diagnostics',out)
    print(json.dumps({'job_id':job,'levels':planned,'planned_perturbation_trials':42*len(planned),'out_dir':str(out)},indent=2))


def main():
    parser=argparse.ArgumentParser(description=__doc__);sub=parser.add_subparsers(dest='command',required=True)
    p=sub.add_parser('submit');p.add_argument('--previous-run',type=Path,required=True)
    p.add_argument('--prior-run',type=Path,action='append',default=[])
    p.add_argument('--out-dir',type=Path,required=True)
    p.add_argument('--scales',type=int,nargs='+',default=[3,4,6,8])
    p.add_argument('--dependency');p.add_argument('--dry-run',action='store_true')
    p=sub.add_parser('run');p.add_argument('--plan',type=Path,required=True)
    args=parser.parse_args()
    if args.command=='submit':submit(args)
    else:run(args.plan)


if __name__=='__main__':main()
