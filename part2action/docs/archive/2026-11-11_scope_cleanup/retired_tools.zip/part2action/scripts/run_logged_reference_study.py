"""Bounded pilot and conditional training-source expansion for logged experts."""
from __future__ import annotations

import argparse
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

from generate_logged_references import ROOT, summarize
from run_interaction_tolerance_pilot import dump


def locked_summary(directory, plan):
    with (directory/'.summary.lock').open('a') as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
        return summarize(directory, plan)


def run_indices(plan_path, directory, indices):
    for index in indices:
        result = directory/'cases'/f'{index:05d}'/'summary.json'
        if result.exists():
            raise FileExistsError('Refusing to overwrite or silently reuse a case: '+str(result))
        print('[fresh-expert] starting source', index, flush=True)
        started = time.monotonic()
        subprocess.run([sys.executable, str(ROOT/'part2action/scripts/generate_logged_references.py'),
                        '--plan', str(plan_path), '--out-dir', str(directory), '--case-index', str(index)],
                       check=True, timeout=5400)
        row = json.loads(result.read_text())
        row['collection_wall_s'] = time.monotonic()-started
        dump(result, row)
        locked_summary(directory, json.loads(plan_path.read_text()))


def launch_expansion(plan, directory, summary):
    """Only validated pilot output can submit the separately logged full stage."""
    decision = {'pilot_gate': summary['expansion_gate'], 'submitted': False}
    destination = directory.parent/'expanded'
    if not summary['expansion_gate']['passed']:
        decision['reason'] = 'Pilot did not meet predefined expansion requirements'
        dump(directory/'expansion_decision.json', decision)
        return
    rows = [json.loads(p.read_text()) for p in directory.glob('cases/*/summary.json')]
    bytes_written = sum(p.stat().st_size for p in directory.rglob('*') if p.is_file())
    # An operational storage bound, not a change to physical success criteria.
    projected = int(2*bytes_written/max(1,len(rows))*len(plan['cases']))
    available = shutil.disk_usage(directory).free
    decision.update(projected_bytes_with_2x_margin=projected, available_bytes=available,
                    source_cases=len(plan['cases']), concurrency=4, cases_per_shard=12)
    if projected + 20*1024**3 > available:
        decision['reason'] = 'Insufficient free storage for measured pilot-based projection'
        dump(directory/'expansion_decision.json', decision)
        return
    destination.mkdir(exist_ok=False)
    full = {**plan, 'stage': 'expanded', 'pilot_directory': str(directory),
            'auto_expand': False, 'cases_per_shard': 12}
    full_path = destination/'plan.json'
    dump(full_path, full)
    # Reuse completed pilot records through explicit links rather than collect
    # the same sources twice or overwrite successful/failed original attempts.
    case_root = destination/'cases'
    case_root.mkdir()
    for path in sorted((directory/'cases').iterdir()):
        if (path/'summary.json').exists():
            (case_root/path.name).symlink_to(path.resolve(), target_is_directory=True)
    missing = [i for i in range(len(plan['cases'])) if not (case_root/f'{i:05d}').exists()]
    full['remaining_indices'] = missing
    dump(full_path, full)
    shards = math.ceil(len(missing)/full['cases_per_shard'])
    if not shards:
        decision.update(reason='All supported sources already collected', submitted=True, jobs=[])
    else:
        env = os.environ.copy()
        env.update(PLAN=str(full_path), OUT_DIR=str(destination), MODE='shard')
        result = subprocess.run(['sbatch', '--parsable', '--time=24:00:00',
            f'--array=0-{shards-1}%4', str(ROOT/'part2action/slurm/generate_logged_references.sbatch')],
            env=env, text=True, capture_output=True, check=True)
        job = result.stdout.strip().split(';')[0]
        if not job.isdigit():
            raise RuntimeError('Unexpected Slurm submission response: '+result.stdout)
        decision.update(submitted=True, jobs=[job], shards=shards, remaining_sources=len(missing))
        env['MODE'] = 'report'
        report = subprocess.run(['sbatch', '--parsable', f'--dependency=afterany:{job}', '--time=00:20:00',
            str(ROOT/'part2action/slurm/generate_logged_references.sbatch')],
            env=env, text=True, capture_output=True, check=True)
        decision['report_job'] = report.stdout.strip().split(';')[0]
    dump(directory/'expansion_decision.json', decision)
    dump(destination/'submissions.json', decision)
    print('[expansion]', json.dumps(decision), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--out-dir', type=Path, required=True)
    parser.add_argument('--mode', choices=['pilot', 'shard', 'report'], default='pilot')
    parser.add_argument('--shard-index', type=int)
    args = parser.parse_args()
    plan = json.loads(args.plan.read_text())
    for name, expected in plan['source_sha256'].items():
        if hashlib.sha256(Path(name).read_bytes()).hexdigest() != expected:
            raise RuntimeError('Study source changed: '+name)
    if args.mode == 'report':
        locked_summary(args.out_dir, plan)
        return
    if args.mode == 'shard':
        if args.shard_index is None:
            parser.error('Shard mode requires --shard-index')
        start = args.shard_index*plan['cases_per_shard']
        indices = plan['remaining_indices'][start:start+plan['cases_per_shard']]
        run_indices(args.plan, args.out_dir, indices)
        return
    run_indices(args.plan, args.out_dir, plan['pilot_indices'])
    summary = locked_summary(args.out_dir, plan)
    if plan.get('auto_expand'):
        launch_expansion(plan, args.out_dir, summary)


if __name__ == '__main__':
    main()
