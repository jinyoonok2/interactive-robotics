"""Original task context, native iteration limits, explicit CPU logging allowance.

Only the wall-clock timeout in pose_tcp is disabled. Native gains, physical
thresholds, maximum iterations and the separately defined lift test are retained.
This is an audited execution variant, not a claim of identical runtime guards.
"""
import argparse
import functools
import json
from pathlib import Path

import generate_logged_references as generator


if __name__=='__main__':
    parser=argparse.ArgumentParser(add_help=False)
    parser.add_argument('--plan',type=Path,required=True)
    parser.add_argument('--out-dir',type=Path,required=True)
    parser.add_argument('--case-index',type=int,required=True)
    args,_=parser.parse_known_args()
    plan=json.loads(args.plan.read_text())
    if not plan.get('native_task_context') or not plan.get('disable_wall_timeout'):
        raise ValueError('Explicit task-context/runtime-guard audit plan is required')
    _,planner=generator.native_classes()
    native_pose=planner.pose_tcp
    @functools.wraps(native_pose)
    def instrumented_pose(self,*values,**kwargs):
        kwargs['timeout']=None
        return native_pose(self,*values,**kwargs)
    planner.pose_tcp=instrumented_pose
    generator.main()
    path=args.out_dir/'cases'/f'{args.case_index:05d}'/'runtime_guard.json'
    generator.dump(path,{'native_task_context':True,'pose_tcp_wall_timeout':None,
        'native_iteration_limits_unchanged':True,'physical_criteria_unchanged':True,
        'reason':'Separate CPU/instrumentation overhead from physical controller outcomes.'})
