"""Read-only analysis of replay failures and optional fresh-scene CPU probes."""
from __future__ import annotations
import argparse
import csv
import html
import json
from collections import Counter
from pathlib import Path
import sys

import h5py
import numpy as np
from diagnostics.replay_validation import repeat_metrics

ROOT=Path(__file__).resolve().parents[2]


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--pilot-dir',type=Path,required=True)
    p.add_argument('--out-dir',type=Path,required=True)
    p.add_argument('--probe-dir',type=Path)
    args=p.parse_args();out=args.out_dir;out.mkdir(parents=True,exist_ok=True)
    rows=json.loads((args.pilot_dir/'results.json').read_text())
    manifest=json.loads((args.pilot_dir/'manifest.json').read_text())
    thresholds=manifest['fidelity_thresholds'];failures=Counter();records=[]
    plotted=[]
    for index,row in enumerate(rows):
        case=row['case'];base=row['baseline'];directory=args.pilot_dir/f'case_{index:03d}_{case["object"]}_{case["demo"]}'
        traces=[np.load(directory/f'baseline_{i}.npz') for i in range(len(base))]
        repeats=[repeat_metrics(traces[0]['tcp'],t['tcp'],traces[0]['fingers'],t['fingers']) for t in traces[1:]]
        failed=[k for k,value in thresholds.items() if any(b['tracking'][k]>value for b in base)]
        failures.update(failed)
        with h5py.File(Path(manifest['data_root'])/'demos'/f'{case["object"]}.hdf5','r') as h:
            d=h['data'][case['demo']];tcp=d['obs/tcp_pose'][:case['window']['end']];finger=d['obs/gripper_state'][:len(tcp)].reshape(-1)
        close=case['window']['close'];error=traces[0]['fingers']-finger
        record={'case_index':index,'object':case['object'],'demo':case['demo'],'part':case['part'],
            'failed_fidelity_metrics':failed,'fidelity_passes':sum(b['replay_fidelity_pass'] for b in base),
            'native_grasp_passes':sum(b['native_grasp_predicate_equivalent'] for b in base),
            'lift_passes':sum(b['stable_target_grasp_lift'] for b in base),
            'original_mixed_component_repeat_max':row['restored_repeat_max_tcp_difference'],
            'repeat_xyz_max_mm':1000*max(x['xyz_max_m'] for x in repeats),
            'repeat_orientation_max_deg':max(x['orientation_max_deg'] for x in repeats),
            'repeat_finger_max_mm':1000*max(x['finger_max_m'] for x in repeats),
            'first_divergence_frames':[x['first_xyz_divergence_frame'] for x in repeats],
            'approach_finger_rmse_mm':1000*float(np.sqrt(np.mean(error[:close]**2))),
            'closure_finger_rmse_mm':1000*float(np.sqrt(np.mean(error[close:]**2))),
            'tcp_p95_mm':1000*base[0]['tracking']['tcp_p95_m'],
            'finger_rmse_mm':1000*base[0]['tracking']['finger_rmse_m'],
            'closure_tcp_error_mm':1000*base[0]['tracking']['closure_tcp_error_m']}
        records.append(record)
        if index in [0,8,10,15]:plotted.append((index,case,trace_copy(traces[0]),tcp,finger))
        for t in traces:t.close()
    summary={'cases':len(rows),'reference_trials':sum(len(r['baseline']) for r in rows),
        'original_eligible_cases':sum(r['eligible'] for r in rows),
        'failure_counts_any_repeat':dict(failures),
        'all_repeats_fidelity_pass':sum(r['fidelity_passes']==3 for r in records),
        'all_repeats_native_grasp_pass':sum(r['native_grasp_passes']==3 for r in records),
        'all_repeats_lift_pass':sum(r['lift_passes']==3 for r in records),
        'all_repeats_fidelity_grasp_lift_pass_before_repeatability':sum(r['fidelity_passes']==r['native_grasp_passes']==r['lift_passes']==3 for r in records),
        'records':records,'probes':[],
        'limits':['Failure counts overlap and are not additive.',
                  'Repeated restores are reproducibility checks, not independent random-seed estimates.',
                  'Controller probes are exploratory; the 15 cm threshold is an inferred calibration hypothesis.',
                  'No eligibility threshold, source dataset, old pilot output or learned policy is changed by this report.']}
    if args.probe_dir:
        for p in sorted(args.probe_dir.glob('case_*/probe.json')):
            d=json.loads(p.read_text());summary['probes'].append(d)
    (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    with (out/'failure_breakdown.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(records[0]));writer.writeheader();writer.writerows(records)
    media=out/'media/2026-10-31';media.mkdir(parents=True,exist_ok=True)
    sys.path.insert(0,str(ROOT/'part2action/docs/slide_history/scripts'))
    from export_slide_tables import render
    cells=[['Case','Fidelity /3','Grasp /3','Lift /3','Repeat XYZ mm','Finger RMSE mm']]
    for r in records:cells.append([r['object']+' '+r['demo'],str(r['fidelity_passes']),str(r['native_grasp_passes']),str(r['lift_passes']),f'{r["repeat_xyz_max_mm"]:.3f}',f'{r["finger_rmse_mm"]:.2f}'])
    render(cells,[.24,.14,.14,.14,.17,.17],media/'replay_failure_table.png')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,axes=plt.subplots(4,2,figsize=(12,12),layout='constrained')
    for row,(index,case,trace,tcp,finger) in enumerate(plotted):
        x=np.arange(len(finger));close=case['window']['close']
        error=1000*np.linalg.norm(trace['tcp'][:,4:]-tcp[:,4:],axis=1)
        axes[row,0].plot(x,error,label='Original replay')
        axes[row,0].axhline(20,color='gray',linestyle=':',label='p95 limit (applies to trajectory)')
        axes[row,1].plot(x,1000*finger,label='Recorded expert')
        axes[row,1].plot(x,1000*trace['fingers'],label='Original replay')
        if args.probe_dir:
            q=args.probe_dir/f'case_{index:03d}/closure_001_pregrasp015/repeat_0.npz'
            if q.exists():
                with np.load(q) as changed:
                    axes[row,0].plot(x,1000*np.linalg.norm(changed['tcp'][:,4:]-tcp[:,4:],axis=1),label='Controller hypothesis')
                    axes[row,1].plot(x,1000*changed['fingers'],label='Controller hypothesis')
        for ax in axes[row]:
            ax.axvline(close,color='black',linestyle='--',alpha=.5);ax.set_xlabel('Stored action frame');ax.grid(alpha=.2);ax.legend(fontsize=8)
        axes[row,0].set_title(case['object']+' '+case['demo']);axes[row,0].set_ylabel('TCP position error (mm)')
        axes[row,1].set_ylabel('Per-finger opening (mm)')
    fig.suptitle('Replay reconstruction audit: timing, controller gains and closure',fontsize=14)
    fig.savefig(media/'replay_phase_errors.png',dpi=180);plt.close(fig)
    probe_table=[['Case / profile','TCP p95 mm','Finger RMSE mm','Fidelity','Lift']]
    for d in summary['probes']:
        for name,g in d['profiles'].items():
            t=g['trials'][0]
            probe_table.append([d['case']['object']+' '+name.replace('_',' '),f'{t["tracking"]["tcp_p95_m"]*1000:.3f}',f'{t["tracking"]["finger_rmse_m"]*1000:.3f}',str(sum(t['replay_fidelity_pass'] for t in g['trials']))+'/'+str(len(g['trials'])),str(sum(t['stable_target_grasp_lift'] for t in g['trials']))+'/'+str(len(g['trials']))])
    if len(probe_table)>1:render(probe_table,[.40,.17,.17,.13,.13],media/'controller_probe_table.png')
    paragraphs=[f'Original pilot: {len(rows)} cases, {summary["reference_trials"]} reference replays, zero eligible cases.',
        f'Across all repeats: {summary["all_repeats_fidelity_pass"]} cases pass fidelity, {summary["all_repeats_native_grasp_pass"]} pass native grasp, {summary["all_repeats_lift_pass"]} pass the added lift test.',
        'A replay-reconstruction error guessed the strong gripper settling phase from the segment end. Native generation can finish the grasp before that phase. The probes test continuous 0.01 gripper gain separately.',
        'A 15 cm pregrasp threshold is tested as a calibration hypothesis for the approach acceleration discrepancy. It is not known release metadata.',
        'The old maximum combined quaternion components and metres. This report separates XYZ millimetres and rotation degrees; some snapshot repeats genuinely diverge after physical contact. Fresh-scene probes check reproducibility without claiming which internal simulator state caused it.']
    text='<!doctype html><meta charset="utf-8"><title>Replay investigation</title><h1>Interaction replay investigation</h1>'+''.join('<p>'+html.escape(x)+'</p>' for x in paragraphs)
    for name in ['replay_phase_errors.png','replay_failure_table.png']+(['controller_probe_table.png'] if len(probe_table)>1 else []):
        text+=f'<p><img width="1100" src="media/2026-10-31/{name}"><br>Use this image: <a href="media/2026-10-31/{name}">{name}</a></p>'
    text+='<p><a href="summary.json">Structured summary</a> | <a href="failure_breakdown.csv">Per-case CSV</a></p>'
    (out/'index.html').write_text(text)
    print(json.dumps({k:v for k,v in summary.items() if k not in ['records','probes']},indent=2))


def trace_copy(trace):return {key:trace[key].copy() for key in ['tcp','fingers','actions']}


if __name__=='__main__':main()
