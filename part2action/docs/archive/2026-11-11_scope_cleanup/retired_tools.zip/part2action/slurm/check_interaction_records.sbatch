#!/usr/bin/env bash
#SBATCH --partition=cpu
#SBATCH --cpus-per-task=4
#SBATCH --mem=12G
#SBATCH --time=01:00:00
#SBATCH --no-requeue
#SBATCH --job-name=p2a-record-check
#SBATCH --output=part2action/logs/slurm/%x-%j.out
#SBATCH --error=part2action/logs/slurm/%x-%j.err
set -euo pipefail
ROOT=/u/xna8aw/workspace/research_projects/interactive-robotics
OUT_DIR="${OUT_DIR:?Fresh instrumentation study directory}"
export PYTHONPATH="$ROOT/part2action:$ROOT/part2action/scripts"
export PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1
export OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=2
export CUDA_VISIBLE_DEVICES="" PARTGYM_FPS_DEVICE=cpu HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
export MPLCONFIGDIR=/tmp/p2a_mpl_cache
cd "$ROOT"
PYTHON=/p/part2action/envs/partgym_rollout/bin/python
export OUT_DIR
"$PYTHON" - <<'PY'
import hashlib,json,os
from pathlib import Path
ledger=json.loads((Path(os.environ['OUT_DIR'])/'submissions.json').read_text())
for name,expected in ledger['source_sha256'].items():
    if hashlib.sha256(Path(name).read_bytes()).hexdigest()!=expected:raise RuntimeError('Source changed: '+name)
PY
ARGS=(--cases-manifest /p/part2action/results/diagnostics/interaction_tolerance_fresh_reference_20261031/manifest.json
  --case-indices 8 --fresh-scenes --repeats 3 --translation-m .03 --rotation-deg 30 --close-offset-steps 6
  --condition-names translation_m_x_plus rotation_deg_x_plus)
"$PYTHON" part2action/scripts/run_interaction_tolerance_pilot.py "${ARGS[@]}" --baseline-only --out-dir "$OUT_DIR/control"
"$PYTHON" part2action/scripts/run_interaction_tolerance_pilot.py "${ARGS[@]}" --capture-observations --out-dir "$OUT_DIR/captured"
"$PYTHON" part2action/scripts/validate_interaction_records.py --captured "$OUT_DIR/captured" --control "$OUT_DIR/control"
