#!/usr/bin/env bash
#SBATCH --partition=cpu
#SBATCH --cpus-per-task=4
#SBATCH --mem=12G
#SBATCH --time=04:00:00
#SBATCH --no-requeue
#SBATCH --job-name=p2a-tolerance-pilot
#SBATCH --output=part2action/logs/slurm/%x-%j.out
#SBATCH --error=part2action/logs/slurm/%x-%j.err
set -euo pipefail
ROOT=/u/xna8aw/workspace/research_projects/interactive-robotics
OUT_DIR="${OUT_DIR:?Set fresh output directory}"
export PYTHONNOUSERSITE=1 PYTHONUNBUFFERED=1 OMP_NUM_THREADS=2
export OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=2 PARTGYM_FPS_DEVICE=cpu
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 CUDA_VISIBLE_DEVICES=""
export PYTHONPATH="$ROOT/part2action:$ROOT/part2action/scripts"
cd "$ROOT"
export MANIFEST="${MANIFEST:?Set submission ledger with source fingerprints}"
/p/part2action/envs/part2action_train/bin/python - <<'CHECK'
import hashlib, json, os
from pathlib import Path
record=json.loads(Path(os.environ['MANIFEST']).read_text())
for path, expected in record['source_sha256'].items():
    if hashlib.sha256(Path(path).read_bytes()).hexdigest()!=expected:
        raise RuntimeError('Pilot source changed after submission: '+path)
CHECK
# Full reference/perturbation pilot: 20 initial-grasp demos, three restored
# repeats, and 14 perturbations per reference-valid case; at most 900 trials.
# No renderer, learned model, or GPU is used.
ARGS=(--out-dir "$OUT_DIR" --per-object "${PER_OBJECT:-5}" --repeats "${REPEATS:-3}")
ARGS+=(--translation-m "${TRANSLATION_M:-0.01}" --rotation-deg "${ROTATION_DEG:-10}" --close-offset-steps "${CLOSE_OFFSET_STEPS:-2}")
if [[ "${BASELINE_ONLY:-0}" == "1" ]]; then
  ARGS+=(--baseline-only)
fi
if [[ "${CAPTURE_OBSERVATIONS:-0}" == "1" ]]; then
  ARGS+=(--capture-observations)
fi
if [[ -n "${CONDITION_NAMES:-}" ]]; then
  read -r -a SELECTED_CONDITIONS <<< "$CONDITION_NAMES"
  ARGS+=(--condition-names "${SELECTED_CONDITIONS[@]}")
fi
if [[ "${FRESH_SCENES:-0}" == "1" ]]; then
  ARGS+=(--fresh-scenes)
fi
if [[ -n "${CASES_MANIFEST:-}" ]]; then
  ARGS+=(--cases-manifest "$CASES_MANIFEST")
fi
if [[ -n "${CASE_INDICES:-}" ]]; then
  read -r -a SELECTED_INDICES <<< "$CASE_INDICES"
  ARGS+=(--case-indices "${SELECTED_INDICES[@]}")
fi
if [[ "${SMOKE_ONLY:-0}" == "1" ]]; then
  ARGS+=(--objects bottle --baseline-only)
fi
/p/part2action/envs/partgym_rollout/bin/python part2action/scripts/run_interaction_tolerance_pilot.py "${ARGS[@]}"
