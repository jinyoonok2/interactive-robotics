#!/usr/bin/env bash
#SBATCH --partition=cpu
#SBATCH --cpus-per-task=4
#SBATCH --mem=12G
#SBATCH --time=04:00:00
#SBATCH --no-requeue
#SBATCH --job-name=p2a-mug-sweep
#SBATCH --output=part2action/logs/slurm/%x-%j.out
#SBATCH --error=part2action/logs/slurm/%x-%j.err
set -euo pipefail
ROOT=/u/xna8aw/workspace/research_projects/interactive-robotics
export PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1
export OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=2
export PARTGYM_FPS_DEVICE=cpu CUDA_VISIBLE_DEVICES=""
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 MPLCONFIGDIR=/tmp/p2a_mpl_cache
export PYTHONPATH="$ROOT/part2action:$ROOT/part2action/scripts"
cd "$ROOT"
/p/part2action/envs/partgym_rollout/bin/python part2action/scripts/run_interaction_tolerance_sweep.py run --plan "${SWEEP_PLAN:?Set immutable sweep plan}"
