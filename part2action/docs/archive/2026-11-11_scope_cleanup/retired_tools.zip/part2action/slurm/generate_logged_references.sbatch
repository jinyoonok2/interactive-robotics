#!/usr/bin/env bash
#SBATCH --partition=cpu
#SBATCH --cpus-per-task=4
#SBATCH --mem=16G
#SBATCH --time=02:00:00
#SBATCH --no-requeue
#SBATCH --job-name=p2a-logged-expert
#SBATCH --output=part2action/logs/slurm/%x-%j.out
#SBATCH --error=part2action/logs/slurm/%x-%j.err
set -euo pipefail
ROOT=/u/xna8aw/workspace/research_projects/interactive-robotics
export PYTHONPATH="$ROOT/part2action:$ROOT/part2action/scripts:$ROOT/PartInstruct"
export PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1
export OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=2
export CUDA_VISIBLE_DEVICES="" PARTGYM_FPS_DEVICE=cpu HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
export MPLCONFIGDIR=/tmp/p2a_mpl_cache
cd "$ROOT"
PYTHON=/p/part2action/envs/partgym_rollout/bin/python
ARGS=(--plan "${PLAN:?Immutable study plan}" --out-dir "${OUT_DIR:?Fresh study directory}")
if [[ "${MODE:-case}" == study ]]; then
  "$PYTHON" part2action/scripts/run_logged_reference_study.py --plan "$PLAN" --out-dir "$OUT_DIR"
elif [[ "${MODE:-case}" == shard ]]; then
  "$PYTHON" part2action/scripts/run_logged_reference_study.py --plan "$PLAN" --out-dir "$OUT_DIR" --mode shard --shard-index "${SLURM_ARRAY_TASK_ID:?}"
elif [[ "${MODE:-case}" == report ]]; then
  "$PYTHON" part2action/scripts/run_logged_reference_study.py --plan "$PLAN" --out-dir "$OUT_DIR" --mode report
else
  ARGS+=(--case-index "${CASE_INDEX:-${SLURM_ARRAY_TASK_ID:?Case index or array task required}}")
  if [[ "${REQUIRE_ELIGIBLE:-0}" == 1 ]]; then ARGS+=(--require-eligible); fi
  "$PYTHON" part2action/scripts/generate_logged_references.py "${ARGS[@]}"
fi
