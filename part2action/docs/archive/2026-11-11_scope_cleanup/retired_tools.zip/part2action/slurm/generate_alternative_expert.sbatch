#!/usr/bin/env bash
#SBATCH --partition=cpu
#SBATCH --cpus-per-task=4
#SBATCH --mem=16G
#SBATCH --time=02:00:00
#SBATCH --no-requeue
#SBATCH --job-name=p2a-expert-proposals
#SBATCH --output=part2action/logs/slurm/%x-%A_%a.out
#SBATCH --error=part2action/logs/slurm/%x-%A_%a.err
set -euo pipefail
ROOT=/u/xna8aw/workspace/research_projects/interactive-robotics
export PYTHONPATH="$ROOT/part2action:$ROOT/part2action/scripts:$ROOT/PartInstruct"
export PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1
export OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=2
export CUDA_VISIBLE_DEVICES="" PARTGYM_FPS_DEVICE=cpu HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
cd "$ROOT"
PYTHON=/p/part2action/envs/partgym_rollout/bin/python
read -r CASE_INDEX PROPOSAL_RANK < <("$PYTHON" -c 'import json,os; r=json.load(open(os.environ["PLAN"]))["proposal_trials"][int(os.environ["SLURM_ARRAY_TASK_ID"])]; print(r["case_index"],r["proposal_rank"])')
export PROPOSAL_RANK
"$PYTHON" part2action/scripts/generate_alternative_expert.py \
 --plan "${PLAN:?}" --out-dir "${OUT_DIR:?}/rank_${PROPOSAL_RANK}" --case-index "$CASE_INDEX"
