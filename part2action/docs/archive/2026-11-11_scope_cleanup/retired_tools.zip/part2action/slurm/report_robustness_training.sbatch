#!/usr/bin/env bash
#SBATCH --partition=cpu
#SBATCH --cpus-per-task=2
#SBATCH --mem=4G
#SBATCH --time=00:20:00
#SBATCH --no-requeue
#SBATCH --job-name=p2a-robustness-report
#SBATCH --output=part2action/logs/slurm/%x-%j.out
#SBATCH --error=part2action/logs/slurm/%x-%j.err
set -euo pipefail
ROOT=/u/xna8aw/workspace/research_projects/interactive-robotics
export PYTHONPATH="$ROOT/part2action:$ROOT/part2action/scripts"
export PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1
export OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=2
export MPLCONFIGDIR=/tmp/p2a_report_mpl
cd "$ROOT"
/p/part2action/envs/part2action_train/bin/python part2action/scripts/build_robustness_training_report.py \
 --study results/diagnostics/logged_expert_references_20261101_recovery2 \
 --training results/diagnostics/interaction_outcome_training_20261101 \
 --probes results/diagnostics/lift_handoff_probe_20261101 results/diagnostics/lift_handoff_factorial_20261101 \
 --out-dir part2action/docs/slide_history/media/2026-11-02/robustness_pilot \
 --slides part2action/docs/slide_history/2026-11-02_robustness_training_update.md
