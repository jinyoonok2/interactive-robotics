#!/usr/bin/env bash
#SBATCH --partition=cpu
#SBATCH --cpus-per-task=4
#SBATCH --mem=16G
#SBATCH --time=04:00:00
#SBATCH --no-requeue
#SBATCH --job-name=p2a-full-baselines
#SBATCH --output=part2action/logs/slurm/%x-%A_%a.out
#SBATCH --error=part2action/logs/slurm/%x-%A_%a.err
set -euo pipefail
ROOT=/u/xna8aw/workspace/research_projects/interactive-robotics
export PYTHONPATH="$ROOT/part2action:$ROOT/part2action/scripts:$ROOT/PartInstruct"
export PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1
export OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=2
export CUDA_VISIBLE_DEVICES="" PARTGYM_FPS_DEVICE=cpu HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
export MPLCONFIGDIR=/tmp/p2a_full_baselines_mpl
cd "$ROOT"
ARGS=(--mode "${MODE:?}" --out-dir "${STUDY_DIR:?}")
if [[ "$MODE" == pilot || "$MODE" == full ]]; then ARGS+=(--shard-index "${SLURM_ARRAY_TASK_ID:?}"); fi
/p/part2action/envs/partgym_rollout/bin/python part2action/scripts/collect_full_trajectory_baselines.py "${ARGS[@]}"
