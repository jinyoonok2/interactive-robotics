#!/usr/bin/env bash
#SBATCH --partition=cpu
#SBATCH --cpus-per-task=4
#SBATCH --mem=12G
#SBATCH --time=01:00:00
#SBATCH --no-requeue
#SBATCH --job-name=p2a-replay-probe
#SBATCH --output=part2action/logs/slurm/%x-%j.out
#SBATCH --error=part2action/logs/slurm/%x-%j.err
set -euo pipefail
ROOT=/u/xna8aw/workspace/research_projects/interactive-robotics
export PYTHONNOUSERSITE=1 PYTHONUNBUFFERED=1 OMP_NUM_THREADS=2
export OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=2 PARTGYM_FPS_DEVICE=cpu
export CUDA_VISIBLE_DEVICES="" HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
export PYTHONPATH="$ROOT/part2action:$ROOT/part2action/scripts"
cd "$ROOT"
/p/part2action/envs/part2action_train/bin/python - <<'PY'
import hashlib,json,os
from pathlib import Path
r=json.loads(Path(os.environ['MANIFEST']).read_text())
for name,expected in r['source_sha256'].items():
    if hashlib.sha256(Path(name).read_bytes()).hexdigest()!=expected:
        raise RuntimeError('Probe source changed after submission: '+name)
PY
/p/part2action/envs/partgym_rollout/bin/python part2action/scripts/probe_interaction_replay.py \
 --pilot-dir "${PILOT_DIR:?}" --case-index "${CASE_INDEX:?}" --out-dir "${OUT_DIR:?}" --repeats 2
