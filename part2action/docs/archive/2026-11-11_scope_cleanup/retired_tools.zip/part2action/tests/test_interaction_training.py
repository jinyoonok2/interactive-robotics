import numpy as np

from train_interaction_pilot import metrics,instance_folds


def test_instance_folds_keep_all_repeats_and_sources_together():
    rows=[{'instance_group':g,'source_group':g+'/demo_'+str(d)} for g in ['mug/1','mug/2','bottle/3'] for d in range(2) for _ in range(3)]
    folds=instance_folds(rows)
    assert len(folds)==3
    for group,training,held in folds:
        assert len(held)==6 and all(rows[i]['instance_group']==group for i in held)
        assert not {rows[i]['source_group'] for i in held}&{rows[i]['source_group'] for i in training}


def test_metrics_handle_ties_imbalance_and_single_class_folds():
    r=metrics([0,0,1,1],[.1,.2,.8,.9])
    assert r['auroc']==1 and r['balanced_accuracy']==1 and r['brier']<.03
    tied=metrics([0,0,1,1],[.5]*4)
    assert tied['auroc']==.5 and tied['balanced_accuracy']==.5
    positive=metrics([1,1],[.8,.9])
    assert positive['auroc'] is None and positive['balanced_accuracy'] is None
    assert positive['failure_recall'] is None
