from run_interaction_tolerance_sweep import levels, boundary_rows


def test_finite_levels_keep_closure_event_inside_grasp_segment():
    case={'window':{'close':76,'end':100}}
    plan=levels([3,4,6,8],[case])
    assert len(plan)==4 and plan[-1]['close_offset_steps']==16
    assert plan[-1]['translation_m']==.08 and plan[-1]['rotation_deg']==80.
    for scales in [[],[3,3],[4,3],[0],[12]]:
        try:levels(scales,[case])
        except ValueError:pass
        else:raise AssertionError(scales)


def test_sampled_failures_do_not_assume_monotonicity_or_count_empty_runs_as_failures():
    rows=[{'condition':'x','magnitude':i,'unit':'cm','trials':n,'successes':s}
          for i,n,s in [(1,3,3),(2,3,3),(3,3,0),(4,3,3),(6,0,0)]]
    result=boundary_rows(rows)[0]
    assert result['first_sampled_failure']==3
    assert result['last_sampled_all_success_below_first_failure']==2
    assert result['success_at_larger_tested_offset_after_failure']
    assert result['largest_tested_magnitude']==4
    good=boundary_rows(rows[:2])[0]
    assert good['first_sampled_failure'] is None
