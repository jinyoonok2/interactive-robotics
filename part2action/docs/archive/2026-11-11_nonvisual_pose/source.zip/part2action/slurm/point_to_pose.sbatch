#!/usr/bin/env bash
#SBATCH --partition=cpu
#SBATCH --cpus-per-task=2
#SBATCH --mem=12G
#SBATCH --time=00:30:00
#SBATCH --no-requeue
#SBATCH --job-name=p2a-point-to-pose
set -euo pipefail
ROOT=/u/xna8aw/workspace/research_projects/interactive-robotics
export PYTHONPATH="$ROOT/part2action:$ROOT/part2action/scripts:$ROOT/PartInstruct"
export PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1
export OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=2
export CUDA_VISIBLE_DEVICES="" PARTGYM_FPS_DEVICE=cpu HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
export MPLCONFIGDIR="${TMPDIR:-/tmp}/p2a_point_pose_${SLURM_JOB_ID}"
cd "$ROOT"
ARGS=(--mode "${MODE:?}" --out-dir "${POSE_STUDY:?}")
if [[ "$MODE" == collect || "$MODE" == evaluate ]]; then ARGS+=(--index "${SLURM_ARRAY_TASK_ID:?}"); fi
if [[ "$MODE" == train ]]; then
  /p/part2action/envs/part2action_train/bin/python part2action/scripts/run_point_to_pose.py "${ARGS[@]}"
else
  /p/part2action/envs/partgym_rollout/bin/python part2action/scripts/run_point_to_pose.py "${ARGS[@]}"
fi
