"""Train and intervene on an actual neural goal-pose actor, with matched control.

Bounded state-only feasibility experiment: whole-instance split, real successful
replay states/commands, no analytic bridge, no copying a goal into the output.
"""
from __future__ import annotations

import argparse
import csv
import gzip
import hashlib
import json
from pathlib import Path
import random
import time

import numpy as np
from scipy.spatial.transform import Rotation

from diagnostics.pose_guided_approach import approach_window, pose_error
from models.pose_guided_actor import PoseGuidedActor, actor_features, action_targets
from run_pose_guided_approach import ROOT, contacts, dump, render_frame, sha

CONDITIONS = ('recorded_control', 'pose_correct', 'pose_zero_relative', 'pose_shift_x', 'no_pose_control')
BASELINES = Path('/p/part2action/results/diagnostics/full_trajectory_baselines_20261102/full')


def prepare(args):
    import h5py
    source_plan = json.loads((BASELINES / 'plan.json').read_text())
    accepted = json.loads((BASELINES / 'summary.json').read_text())['eligible_case_indices']
    meta = json.loads((args.data_root / 'episodes_meta_train.json').read_text())
    lookup = {str(e['ep_id']): e for rows in meta['mug']['train'].values() for e in rows}
    groups = {}
    for i in accepted:
        case = source_plan['cases'][i]
        if case['object'] == 'mug' and case['task_type'] == '3':
            groups.setdefault(case['object_id'], []).append((i, case))
    rng = random.Random(20261105)
    instances = sorted(groups)
    rng.shuffle(instances)
    if len(instances) < 12:
        raise ValueError('Insufficient independent mug instances')
    split_ids = {'test': instances[:4], 'development': instances[4:8], 'train': instances[8:]}
    args.out_dir.mkdir(parents=True, exist_ok=False)
    (args.out_dir / 'cases').mkdir()
    cases, excluded, x, y, split_indices, source_indices = [], [], [], [], {}, []
    with h5py.File(args.data_root / 'demos/mug.hdf5') as handle:
        for split in ['train', 'development', 'test']:
            split_indices[split] = []
            for instance in split_ids[split]:
                candidates = sorted(groups[instance], key=lambda c: c[0])
                rng.shuffle(candidates)
                wanted = 4 if split == 'train' else 2 if split == 'development' else 1
                taken = 0
                for index, source in candidates:
                    try:
                        demo = handle['data'][source['demo']]
                        commands = demo['actions'][:]
                        texts = [s.decode() if isinstance(s, bytes) else str(s) for s in demo['skill_instructions'][:]]
                        window = approach_window(commands, texts)
                        if len(commands) > 200 or window['close'] < 10 or window['end'] > 160:
                            raise ValueError('Outside predeclared bounded action/closure budget')
                        ref = (BASELINES / 'cases' / f'{index:05d}' / 'repeat_0').resolve()
                        result = json.loads((ref.parent / 'result.json').read_text())
                        if not result['eligible']:
                            raise ValueError('Source is not an eligible successful repeated replay')
                        with np.load(ref / 'trajectories.npz') as z:
                            tcp = z['before_tcp'].copy()
                            fingers_after = z['replay_fingers'].copy()
                            reference_tcp = z['replay_tcp'].copy()
                            reference_object = z['object_xyz'].copy()
                            if not np.array_equal(commands, z['actions']):
                                raise ValueError('Stored command identity mismatch')
                        goal = tcp[window['close']].copy()
                        indices = np.arange(1, window['end'])
                        features = actor_features(tcp[indices], fingers_after[indices - 1], goal,
                                                  indices, window['close'], window['end'])
                        targets = action_targets(tcp[indices], commands[indices])
                        case_id = len(cases)
                        case_path = args.out_dir / 'cases' / f'{case_id:03d}.npz'
                        np.savez_compressed(case_path, source_actions=commands, before_tcp=tcp,
                            fingers_after=fingers_after, goal=goal, reference_tcp=reference_tcp,
                            reference_object=reference_object)
                        episode = lookup[source['episode_id']]
                        case = {**source, 'split': split, 'source_index': index,
                                'episode': episode, 'part': episode['chain_params'][0]['params'].get('part_grasp', ''),
                                'window': window, 'reference': str(ref), 'case_file': str(case_path),
                                'case_sha256': sha(case_path), 'goal_xyzw_xyz': goal.tolist()}
                        cases.append(case)
                        first = len(y)
                        x.extend(features)
                        y.extend(targets)
                        source_indices.extend([case_id] * len(indices))
                        split_indices[split].extend(range(first, len(y)))
                        taken += 1
                        if taken == wanted:
                            break
                    except (KeyError, ValueError, OSError) as error:
                        excluded.append({'source_index': index, 'demo': source['demo'], 'reason': str(error)})
                if taken == 0:
                    raise ValueError(f'No eligible source for preselected {split} instance {instance}')
    np.savez_compressed(args.out_dir / 'dataset.npz', features=np.asarray(x, dtype=np.float32),
                        targets=np.asarray(y, dtype=np.float32), source_indices=np.asarray(source_indices))
    evaluation = [next(i for i, c in enumerate(cases) if c['split'] == 'train')]
    evaluation += [i for i, c in enumerate(cases) if c['split'] == 'test']
    trials = [{'case_index': i, 'condition': condition} for i in evaluation for condition in CONDITIONS]
    sources = [Path(__file__), ROOT / 'part2action/models/pose_guided_actor.py',
               ROOT / 'part2action/scripts/run_pose_guided_approach.py',
               ROOT / 'part2action/diagnostics/pose_guided_approach.py',
               ROOT / 'part2action/scripts/generate_logged_references.py',
               ROOT / 'part2action/scripts/run_interaction_tolerance_pilot.py',
               ROOT / 'part2action/diagnostics/execution_trace.py',
               ROOT / 'part2action/diagnostics/evaluation_scenarios.py',
               ROOT / 'part2action/slurm/learned_pose_actor.sbatch',
               ROOT / 'PartInstruct/PartInstruct/PartGym/config/config_oracle.yaml',
               ROOT / 'PartInstruct/PartInstruct/PartGym/env/bullet_env.py',
               ROOT / 'PartInstruct/PartInstruct/PartGym/env/backend/planner/panda_arm.py',
               ROOT / 'PartInstruct/PartInstruct/PartGym/env/backend/planner/bullet_planner.py',
               ROOT / 'PartInstruct/PartInstruct/PartGym/env/backend/bullet_sim.py']
    plan = {'study': 'learned_goal_pose_actor', 'data_root': str(args.data_root),
            'source_split': 'Accepted mug task-3 training replays only; task-3 is grasp then move.',
            'instance_split': split_ids, 'cases': cases, 'excluded': excluded,
            'sample_indices': split_indices, 'samples': len(y), 'dataset_sha256': sha(args.out_dir / 'dataset.npz'),
            'evaluation_case_indices': evaluation, 'trials': trials,
            'seed': 42, 'hidden': 128, 'updates': 4000, 'batch_size': 256,
            'learning_rate': .003, 'source_sha256': {str(p): sha(p) for p in sources},
            'limits': ['State-only neural low-level prototype, not the full visual Part2Action model.',
                       'Supplied measured goal pose and source-event timing are privileged diagnostic inputs.',
                       'Contact localization and point-to-pose prediction are not trained in this experiment.',
                       'One training seed; four held-out instances and one training-source calibration rollout.',
                       'Original native full-task continuation is replayed after the learned initial grasp.',
                       'No analytic bridge or supplied-goal arithmetic is used to decode neural actions.'],
            'selection': 'Instances shuffled with seed 20261105 before model training. '
                         'First 4 test, next 4 development, remaining train; 4/2/1 eligible demos per instance.',
            'protocol': 'Replay only source action 0; then predict all seven commands from actual measured '
                        'state, supplied pose and fixed source clock until the first skill ends. '
                        'Reobserve each step. Continue the original full task unchanged afterward.',
            'no_auto_expansion': True}
    dump(args.out_dir / 'plan.json', plan)
    snapshots = args.out_dir / 'source_snapshot'
    snapshots.mkdir()
    for i, p in enumerate(sources):
        (snapshots / (f'{i:02d}_' + p.name)).write_bytes(p.read_bytes())
    print(json.dumps({'cases': len(cases), 'samples': len(y), 'split_cases': {
        s: sum(c['split'] == s for c in cases) for s in split_ids}, 'rollouts': len(trials)}, indent=2))


def load_data(root):
    import torch
    with np.load(root / 'dataset.npz') as z:
        return torch.from_numpy(z['features']), torch.from_numpy(z['targets'])


def loss_function(prediction, target):
    import torch.nn.functional as F
    return (F.smooth_l1_loss(prediction[:, :3], target[:, :3], beta=.1)
            + .5 * F.smooth_l1_loss(prediction[:, 3:6], target[:, 3:6], beta=.1)
            + .1 * F.binary_cross_entropy_with_logits(prediction[:, 6], target[:, 6]))


def offline_metrics(model, features, targets):
    import torch
    with torch.no_grad():
        output = model(features)
        distance = .1 * torch.linalg.vector_norm(output[:, :3] - targets[:, :3], dim=-1) * 1000
        pred_rot = Rotation.from_rotvec(output[:, 3:6].cpu().numpy() * np.pi)
        target_rot = Rotation.from_rotvec(targets[:, 3:6].cpu().numpy() * np.pi)
        angle = np.rad2deg((target_rot.inv() * pred_rot).magnitude())
        return {'samples': len(targets), 'loss': float(loss_function(output, targets)),
                'position_mean_mm': float(distance.mean()), 'position_p95_mm': float(torch.quantile(distance, .95)),
                'rotation_mean_deg': float(angle.mean()),
                'opening_accuracy': float(((output[:, 6] >= 0) == (targets[:, 6] >= .5)).float().mean())}


def train(args, plan):
    import torch
    torch.set_num_threads(2)
    x, y = load_data(args.out_dir)
    ix = {name: torch.tensor(indices) for name, indices in plan['sample_indices'].items()}
    models, rows, result = {}, [], {}
    started = time.monotonic()
    for mode in ['with_pose', 'without_pose']:
        torch.manual_seed(plan['seed'])
        np.random.seed(plan['seed'])
        model = PoseGuidedActor(pose_enabled=mode == 'with_pose', hidden=plan['hidden'])
        optimizer = torch.optim.AdamW(model.parameters(), lr=plan['learning_rate'], weight_decay=1e-5)
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, plan['updates'], eta_min=3e-5)
        generator = torch.Generator().manual_seed(plan['seed'])
        best = float('inf')
        for update in range(plan['updates'] + 1):
            if update % 200 == 0:
                model.eval()
                development = offline_metrics(model, x[ix['development']], y[ix['development']])
                rows.append({'mode': mode, 'update': update,
                             'train_loss': offline_metrics(model, x[ix['train']], y[ix['train']])['loss'],
                             **{'development_' + k: v for k, v in development.items()}})
                if development['loss'] < best:
                    best = development['loss']
                    torch.save({'state_dict': model.state_dict(), 'mode': mode, 'hidden': plan['hidden'],
                                'pose_enabled': model.pose_enabled, 'update': update,
                                'seed': plan['seed'], 'development_metrics': development,
                                'instance_split': plan['instance_split'], 'dataset_sha256': plan['dataset_sha256']},
                               args.out_dir / (mode + '.pt'))
                dump(args.out_dir / 'training_progress.json', {'mode': mode, 'update': update,
                                                              'updates': plan['updates'], 'wall_s': time.monotonic() - started})
                print('[learned-pose]', mode, update, development, flush=True)
            if update == plan['updates']:
                break
            model.train()
            sampled = ix['train'][torch.randint(len(ix['train']), (plan['batch_size'],), generator=generator)]
            optimizer.zero_grad(set_to_none=True)
            loss = loss_function(model(x[sampled]), y[sampled])
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.)
            optimizer.step()
            scheduler.step()
        checkpoint = torch.load(args.out_dir / (mode + '.pt'), map_location='cpu', weights_only=False)
        model.load_state_dict(checkpoint['state_dict'])
        model.eval()
        models[mode] = model
        result[mode] = {'selected_update': checkpoint['update'], 'checkpoint_sha256': sha(args.out_dir / (mode + '.pt')),
                        'train': offline_metrics(model, x[ix['train']], y[ix['train']]),
                        'development': offline_metrics(model, x[ix['development']], y[ix['development']]),
                        'test': offline_metrics(model, x[ix['test']], y[ix['test']])}
    held = x[ix['test']]
    shifted = held.clone(); shifted[:, 12] += .5  # +5 cm / fixed 0.1 m input scale
    zero = held.clone(); zero[:, 12:] = 0
    with torch.no_grad():
        original = models['with_pose'](held)
        moved = models['with_pose'](shifted)
        removed = models['with_pose'](zero)
        delta_mm = (moved[:, :3] - original[:, :3]) * 100
        zero_mm = torch.linalg.vector_norm((removed[:, :3] - original[:, :3]) * 100, dim=-1)
        control_delta = float((models['without_pose'](shifted) - models['without_pose'](held)).abs().max())
    result['same_observation_intervention'] = {
        'input_shift_world_x_mm': 50., 'samples': len(held),
        'mean_action_shift_xyz_mm': delta_mm.mean(0).tolist(),
        'median_action_shift_norm_mm': float(torch.linalg.vector_norm(delta_mm, dim=-1).median()),
        'median_zero_relative_action_change_mm': float(zero_mm.median()),
        'without_pose_max_prediction_change': control_delta,
        'note': 'Teacher-forced fixed states and clocks. Goal enters only neural input; no goal addition in output decoder.'}
    result.update(status='completed', wall_s=time.monotonic() - started, limits=plan['limits'])
    dump(args.out_dir / 'training_summary.json', result)
    with (args.out_dir / 'training_history.csv').open('w') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)


def evaluate(args, plan):
    import torch
    from diagnostics.execution_trace import ExecutionTrace, physical_state, plain
    from generate_logged_references import make_env, native_grasp
    import imageio.v2 as imageio
    trial = plan['trials'][args.trial_index]
    case = plan['cases'][trial['case_index']]
    condition = trial['condition']
    output = args.out_dir / 'rollouts' / f'{args.trial_index:03d}_{case["demo"]}_{condition}'
    output.mkdir(parents=True, exist_ok=False)
    started = time.monotonic()
    env, trace = None, None
    try:
        with np.load(case['case_file']) as z:
            actions = z['source_actions'].copy()
            goal = z['goal'].copy()
            reference_tcp = z['reference_tcp'].copy()
        checkpoint_sha = None
        model = None
        if condition != 'recorded_control':
            mode = 'without_pose' if condition == 'no_pose_control' else 'with_pose'
            checkpoint_path = args.out_dir / (mode + '.pt')
            training = json.loads((args.out_dir / 'training_summary.json').read_text())
            checkpoint_sha = sha(checkpoint_path)
            if checkpoint_sha != training[mode]['checkpoint_sha256']:
                raise RuntimeError('Trained checkpoint changed')
            checkpoint = torch.load(checkpoint_path, map_location='cpu', weights_only=False)
            model = PoseGuidedActor(checkpoint['pose_enabled'], checkpoint['hidden'])
            model.load_state_dict(checkpoint['state_dict']); model.eval()
        env = make_env(Path(plan['data_root']), case, plan['seed'], native_task_context=True)
        trace = ExecutionTrace(env)
        dump(output / 'initial_state.json', plain(trace.initial))
        w = case['window']
        config = env.config
        view = env.world.p.computeViewMatrixFromYawPitchRoll(cameraTargetPosition=list(config.cam_static_target),
                    distance=config.cam_static_dist, yaw=config.cam_static_yaw, pitch=config.cam_static_pitch, roll=0,
                    upAxisIndex=config.up_axis_index)
        projection = env.world.p.computeProjectionMatrixFOV(fov=60, aspect=1, nearVal=config.cam_near, farVal=config.cam_far)
        rows, states, frames = [], [], []
        boundary = None
        for i, original in enumerate(actions):
            state = physical_state(env)
            supplied = goal.copy()
            if condition == 'pose_shift_x':
                supplied[4] += .05
            elif condition == 'pose_zero_relative':
                supplied = np.asarray(state['tcp_xyzw_xyz'])
            learned = model is not None and 1 <= i < w['end']
            if i == 1:
                dump(output / 'approach_start_state.json', state)
            action = model.predict(state['tcp_xyzw_xyz'], state['finger_m'], supplied, i, w['close'], w['end']) if learned else original.copy()
            trace.phase = 'neural_actor' if learned else 'recorded_control' if condition == 'recorded_control' else 'original_prefix_or_continuation'
            _, _, done, info = env.step(action.copy())
            trace.finish_action()
            after = physical_state(env); states.append(after)
            contact = contacts(env)
            error = pose_error(after['tcp_xyzw_xyz'], goal)
            rows.append({'index': i, 'neural_action': learned, 'native_task_success': bool(done),
                         'completion_rate': float(info['Completion Rate']),
                         'reference_goal_error_mm': error['position_mm'], 'reference_goal_rotation_deg': error['rotation_deg'],
                         'command_opening_m': float(action[6]), 'measured_opening_m': after['finger_m'],
                         'left_contact': contact['left'], 'right_contact': contact['right']})
            if i == w['end'] - 1:
                steps = trace.physics_steps
                grasp = native_grasp(env)
                if trace.physics_steps != steps:
                    raise RuntimeError('Boundary predicate advanced physics')
                boundary = {'native_part_grasp': grasp, 'contacts': contact,
                            'reference_goal_error': error, 'state': after}
            if i >= 1 and (i % 2 == 0 or i in [w['close'] - 1, w['end'] - 1, len(actions) - 1]):
                frames.append(render_frame(env, view, projection,
                    f'NEURAL {condition} | {case["demo"]} | {case["split"]} | {i}\n'
                    f'Original-goal error {error["position_mm"]:.1f} mm | task {bool(done)}'))
            if i % 25 == 0:
                dump(output / 'progress.json', {'index': i, 'total': len(actions), **trial})
        actual = np.asarray([e['action'] for e in trace.events if e['kind'] == 'action'])
        if not np.array_equal(actual[w['end']:], actions[w['end']:]) or not np.array_equal(actual[0], actions[0]):
            raise RuntimeError('Original prefix/continuation changed')
        tcp = np.asarray([s['tcp_xyzw_xyz'] for s in states])
        if condition == 'recorded_control':
            replay_error = float(np.linalg.norm(tcp[:, 4:] - reference_tcp[:, 4:], axis=1).max())
            if replay_error > .001 or not any(r['native_task_success'] for r in rows):
                raise RuntimeError('The previously successful recorded control no longer reproduces')
        np.savez_compressed(output / 'trajectories.npz', source_actions=actions, applied_actions=actual, tcp=tcp,
                            fingers=np.asarray([s['finger_m'] for s in states]),
                            object_xyz=np.asarray([s['object_xyz'] for s in states]), goal=goal)
        with gzip.open(output / 'execution.json.gz', 'wt') as handle:
            json.dump(plain({'initial': trace.initial, 'events': trace.events}), handle)
        with (output / 'per_step.csv').open('w') as handle:
            writer = csv.DictWriter(handle, fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
        imageio.mimsave(output / 'execution.gif', frames, duration=.1, loop=0)
        result = {'status': 'completed', **trial, 'case': case, 'checkpoint_sha256': checkpoint_sha,
                  'neural_actions': sum(r['neural_action'] for r in rows), 'boundary': boundary,
                  'native_full_task_success': any(r['native_task_success'] for r in rows),
                  'native_full_task_success_final': bool(rows[-1]['native_task_success']),
                  'first_closing_command': next((r['index'] for r in rows if r['command_opening_m'] <= .02), None),
                  'wall_s': time.monotonic() - started}
        dump(output / 'summary.json', result)
        print('[neural-rollout]', condition, case['demo'], result['native_full_task_success'], flush=True)
    except BaseException as error:
        dump(output / 'summary.json', {'status': 'runtime_error', **trial, 'error': repr(error)})
        raise
    finally:
        if trace is not None: trace.close()
        if env is not None: env.close()


def report(args, plan):
    training = json.loads((args.out_dir / 'training_summary.json').read_text())
    records = [(p.parent, json.loads(p.read_text())) for p in sorted((args.out_dir / 'rollouts').glob('*/summary.json'))]
    valid = [(p, v) for p, v in records if v['status'] == 'completed']
    counts = []
    for split in ['train', 'test']:
        for condition in CONDITIONS:
            group = [v for _, v in valid if v['case']['split'] == split and v['condition'] == condition]
            counts.append({'split': split, 'condition': condition, 'completed': len(group),
                           'native_full_task_successes': sum(v['native_full_task_success'] for v in group),
                           'native_part_grasp': sum(v['boundary']['native_part_grasp'] for v in group),
                           'mean_final_grasp_pose_error_mm': float(np.mean([v['boundary']['reference_goal_error']['position_mm'] for v in group])) if group else None})
    summary = {'status': 'completed' if len(records) == len(plan['trials']) else 'in_progress',
               'finished': len(records), 'planned': len(plan['trials']),
               'runtime_errors': len(records) - len(valid), 'rollout_counts': counts,
               'training': training, 'limits': plan['limits']}
    dump(args.out_dir / 'summary.json', summary)
    lines = ['# Learned goal-pose actor: first controlled experiment', '',
             '**An actual trained neural network predicts commands here. No analytic bridge or goal-copy output is used.**', '',
             plan['protocol'], '', '## Offline held-instance command prediction', '',
             '| Trained network | Held position error, mean | Held rotation error, mean | Opening accuracy |',
             '| --- | ---: | ---: | ---: |']
    for mode in ['with_pose', 'without_pose']:
        m = training[mode]['test']
        lines.append(f'| {mode} | {m["position_mean_mm"]:.2f} mm | {m["rotation_mean_deg"]:.2f} deg | {m["opening_accuracy"]:.1%} |')
    sensitivity = training['same_observation_intervention']
    lines += ['', '## Same-observation target intervention', '',
              f'A +50 mm world-X target shift changed the learned pose-conditioned XYZ commands by '
              f'{sensitivity["mean_action_shift_xyz_mm"]} mm on average. '
              f'The no-pose network maximum prediction difference was {sensitivity["without_pose_max_prediction_change"]}.', '',
              'These are fixed-observation command responses, not simulator task-success scores.', '',
              '## Actual closed-loop execution', '',
              f'Finished {len(records)}/{len(plan["trials"])}; runtime errors {summary["runtime_errors"]}.', '',
              '| Split | Condition | Completed | Original task succeeds | Native part grasp |',
              '| --- | --- | ---: | ---: | ---: |']
    for row in counts:
        lines.append(f'| {row["split"]} | {row["condition"]} | {row["completed"]} | {row["native_full_task_successes"]} | {row["native_part_grasp"]} |')
    lines += ['', '## Scope', ''] + ['- ' + note for note in plan['limits']]
    lines += ['', '[Plan](plan.json) · [Summary](summary.json) · [Training history](training_history.csv)', '', '## Executions', '']
    for path, value in valid:
        relative = path.relative_to(args.out_dir)
        lines.append(f'- {value["case"]["split"]} / {value["case"]["demo"]} / {value["condition"]}: '
                     f'[video]({relative}/execution.gif), [measurements]({relative}/summary.json)')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    with (args.out_dir / 'training_history.csv').open() as handle:
        history = list(csv.DictReader(handle))
    fig, ax = plt.subplots(figsize=(7, 4))
    for mode in ['with_pose', 'without_pose']:
        rows = [v for v in history if v['mode'] == mode]
        ax.plot([int(v['update']) for v in rows], [float(v['development_position_mean_mm']) for v in rows], label=mode)
    ax.set(xlabel='Optimizer updates', ylabel='Development command-position error (mm)', title='Learned neural actor — whole instances held out')
    ax.legend();fig.tight_layout();fig.savefig(args.out_dir / 'training_curve.png', dpi=160);plt.close(fig)
    lines += ['', '![Learning curves](training_curve.png)', '']
    (args.out_dir / 'README.md').write_text('\n'.join(lines))
    print(json.dumps(summary, indent=2))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mode', choices=['prepare', 'train', 'evaluate', 'report'], required=True)
    parser.add_argument('--out-dir', type=Path, required=True)
    parser.add_argument('--data-root', type=Path, default=Path('/p/part2action/data/PartInstruct'))
    parser.add_argument('--trial-index', type=int)
    args = parser.parse_args()
    if args.mode == 'prepare':
        prepare(args);return
    plan = json.loads((args.out_dir / 'plan.json').read_text())
    for name, expected in plan['source_sha256'].items():
        if sha(name) != expected:raise RuntimeError('Source changed: ' + name)
    if sha(args.out_dir / 'dataset.npz') != plan['dataset_sha256']:
        raise RuntimeError('Dataset changed')
    if args.mode == 'train':train(args, plan)
    elif args.mode == 'evaluate':
        case = plan['cases'][plan['trials'][args.trial_index]['case_index']]
        if sha(case['case_file']) != case['case_sha256']:raise RuntimeError('Case changed')
        evaluate(args, plan)
    else:report(args, plan)


if __name__ == '__main__':main()
