"""Recompute logged simulator commands from frozen neural weights and inputs."""
from __future__ import annotations

import argparse
import gzip
import json
from pathlib import Path

import numpy as np
from scipy.spatial.transform import Rotation
import torch

from models.pose_guided_actor import PoseGuidedActor
from run_pose_guided_approach import dump, sha


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out-dir', type=Path, required=True)
    args = parser.parse_args()
    torch.set_num_threads(1)
    root = args.out_dir
    plan = json.loads((root / 'plan.json').read_text())
    training = json.loads((root / 'training_summary.json').read_text())
    models = {}
    for mode in ['with_pose', 'without_pose']:
        path = root / (mode + '.pt')
        if sha(path) != training[mode]['checkpoint_sha256']:
            raise RuntimeError('Checkpoint changed: ' + mode)
        checkpoint = torch.load(path, map_location='cpu', weights_only=False)
        model = PoseGuidedActor(checkpoint['pose_enabled'], checkpoint['hidden'])
        model.load_state_dict(checkpoint['state_dict']);model.eval()
        models[mode] = model
    rows = []
    starts = {}
    for summary_path in sorted((root / 'rollouts').glob('*/summary.json')):
        summary = json.loads(summary_path.read_text())
        if summary['status'] != 'completed':
            raise RuntimeError('Cannot audit failed rollout: ' + str(summary_path))
        case, condition = summary['case'], summary['condition']
        directory = summary_path.parent
        with gzip.open(directory / 'execution.json.gz', 'rt') as handle:
            events = [event for event in json.load(handle)['events'] if event['kind'] == 'action']
        with np.load(case['case_file']) as z:
            source = z['source_actions'].copy()
            goal = z['goal'].copy()
        actual = np.asarray([e['action'] for e in events])
        end = case['window']['end']
        assert np.array_equal(actual[0], source[0])
        assert np.array_equal(actual[end:], source[end:])
        start = np.asarray(events[1]['before']['tcp_xyzw_xyz'] + events[1]['before']['robot_q']
                           + events[1]['before']['object_xyz'] + events[1]['before']['object_xyzw'])
        if summary['case_index'] in starts:
            np.testing.assert_allclose(start, starts[summary['case_index']], rtol=0, atol=1e-10)
        starts[summary['case_index']] = start
        position, rotation, finger = [], [], []
        if condition == 'recorded_control':
            assert np.array_equal(actual, source)
        else:
            model = models['without_pose' if condition == 'no_pose_control' else 'with_pose']
            for i in range(1, end):
                state = events[i]['before']
                supplied = goal.copy()
                if condition == 'pose_shift_x': supplied[4] += .05
                elif condition == 'pose_zero_relative': supplied = np.asarray(state['tcp_xyzw_xyz'])
                predicted = model.predict(state['tcp_xyzw_xyz'], state['finger_m'], supplied,
                                          i, case['window']['close'], end)
                position.append(float(np.linalg.norm(predicted[:3] - actual[i, :3])))
                rotation.append(float(np.rad2deg((Rotation.from_euler('xyz', predicted[3:6]).inv()
                                                 * Rotation.from_euler('xyz', actual[i, 3:6])).magnitude())))
                finger.append(abs(float(predicted[6] - actual[i, 6])))
            assert max(position) <= 1e-5
            assert max(rotation) <= .001
            assert max(finger) == 0
        rows.append({'case_index': summary['case_index'], 'condition': condition,
                     'recomputed_neural_commands': len(position),
                     'max_position_difference_m': max(position, default=0),
                     'max_rotation_difference_deg': max(rotation, default=0),
                     'max_opening_difference_m': max(finger, default=0)})
    if len(rows) != len(plan['trials']):
        raise RuntimeError('Not all planned rollouts are available')
    value = {'status': 'passed', 'rollouts': len(rows),
             'recomputed_neural_commands': sum(r['recomputed_neural_commands'] for r in rows),
             'common_initial_approach_state_atol': 1e-10,
             'all_recorded_controls_equal_source': True,
             'all_prefix_and_continuation_commands_equal_source': True,
             'neural_commands_recomputed_from_frozen_weights_and_logged_actual_pre_action_states': True,
             'audit_source_sha256': sha(Path(__file__)), 'rows': rows}
    dump(root / 'neural_command_audit.json', value)
    print(json.dumps({k: v for k, v in value.items() if k != 'rows'}, indent=2))


if __name__ == '__main__': main()
