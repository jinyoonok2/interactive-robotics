"""Prepare, execute and report a bounded oracle-pose/controller diagnostic.

This temporary prototype uses analytic pose holds/bridges, not a learned actor.
It preserves the successful full-task source prefix and continuation and measures
the approach/grasp boundary separately from eventual full-task success.
"""
from __future__ import annotations

import argparse
import csv
import gzip
import hashlib
import json
import time
from pathlib import Path

import numpy as np
from scipy.spatial.transform import Rotation

from diagnostics.pose_guided_approach import CONDITIONS, approach_window, guided_commands, pose_error

ROOT = Path(__file__).resolve().parents[2]
DEFAULT_REFERENCE = ROOT / 'results/diagnostics/full_dataset_trajectory_replay_20261102/mug_demo_1'


def dump(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(data, indent=2) + '\n')
    tmp.replace(path)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def prepare(args):
    import h5py
    ref = args.reference.resolve()
    manifest = json.loads((ref / 'manifest.json').read_text())
    summary = json.loads((ref / 'summary.json').read_text())
    if not summary['native_task_success_any']:
        raise ValueError('Reference is not a successful full-task replay')
    source = args.data_root / 'demos' / (manifest['object'] + '.hdf5')
    with h5py.File(source) as handle:
        demo = handle['data'][manifest['demo']]
        actions = demo['actions'][:]
        instructions = [v.decode() if isinstance(v, bytes) else str(v)
                        for v in demo['skill_instructions'][:]]
    if hashlib.sha256(actions.tobytes()).hexdigest() != manifest['action_sha256']:
        raise ValueError('Reference and dataset actions differ')
    window = approach_window(actions, instructions)
    with np.load(ref / 'trajectories.npz') as data:
        if not np.array_equal(data['actions'], actions):
            raise ValueError('Reference NPZ actions differ')
        before_tcp = data['before_tcp'].copy()
        ref_tcp = data['replay_tcp'].copy()
        ref_object = data['object_xyz'].copy()
        ref_joints = data['replay_joints'].copy()
        ref_fingers = data['replay_fingers'].copy()
    # The target is measured BEFORE closure, not an action command mistaken for
    # a measured state. The commanded-target variant explicitly tests that gap.
    measured_target = before_tcp[window['close']]
    case = {'object': manifest['object'], 'demo': manifest['demo'],
            'object_id': manifest['object_id'], 'episode_id': manifest['episode_id'],
            'task_type': manifest['task_type'], 'episode': manifest['episode'],
            'part': manifest['episode']['chain_params'][0]['params'].get('part_grasp', '')}
    files = [Path(__file__), ROOT / 'part2action/diagnostics/pose_guided_approach.py',
             ROOT / 'part2action/scripts/generate_logged_references.py',
             ROOT / 'part2action/scripts/run_interaction_tolerance_pilot.py',
             ROOT / 'part2action/diagnostics/execution_trace.py',
             ROOT / 'part2action/diagnostics/evaluation_scenarios.py',
             ROOT / 'part2action/slurm/pose_guided_approach.sbatch',
             ROOT / 'PartInstruct/PartInstruct/PartGym/config/config_oracle.yaml',
             ROOT / 'PartInstruct/PartInstruct/PartGym/env/bullet_env.py',
             ROOT / 'PartInstruct/PartInstruct/PartGym/env/backend/planner/panda_arm.py',
             ROOT / 'PartInstruct/PartInstruct/PartGym/env/backend/planner/bullet_planner.py',
             ROOT / 'PartInstruct/PartInstruct/PartGym/env/backend/bullet_sim.py']
    args.out_dir.mkdir(parents=True, exist_ok=False)
    np.savez_compressed(args.out_dir / 'reference_inputs.npz', actions=actions, before_tcp=before_tcp,
                        reference_tcp=ref_tcp, reference_object=ref_object,
                        reference_joints=ref_joints, reference_fingers=ref_fingers)
    plan = {
        'status': 'prepared', 'study': 'oracle_pose_approach_controller_pilot',
        'data_root': str(args.data_root), 'reference': str(ref), 'case': case,
        'seed': 42, 'repeats': 2, 'window': window,
        'target_xyzw_xyz': measured_target.tolist(),
        'source_action_sha256': manifest['action_sha256'],
        'source_sha256': {str(p): sha(p) for p in files},
        'input_sha256': sha(args.out_dir / 'reference_inputs.npz'),
        'trials': [{'condition': condition, 'repeat': repeat} for condition in CONDITIONS for repeat in range(2)],
        'protocol': 'Fresh process/scene per trial at seed 42. Replay original prefix; replace only '
                    'pregrasp-to-grasp arm poses with an explicit oracle-pose hold/bridge; retain '
                    'all source gripper commands, native controller gains/cadence, action count '
                    'and original full-task continuation. Continue all source actions.',
        'limits': {'prefix_position_m': .001, 'prefix_rotation_deg': 1.,
                   'repeat_position_m': .001, 'repeat_rotation_deg': 1.,
                   'pose_reach_position_mm': 5., 'pose_reach_rotation_deg': 5.},
        'interpretation': 'Analytic pose-guided/controller feasibility diagnostic. No learned '
                          'pose head, diffusion decoder, contact predictor or evaluator is trained/tested.',
        'scope': 'One known-successful training source; its target is the mug right region, not a handle label.',
        'no_auto_expansion': True,
    }
    dump(args.out_dir / 'plan.json', plan)
    snapshots = args.out_dir / 'source_snapshot'
    snapshots.mkdir()
    for i, path in enumerate(files):
        (snapshots / (f'{i:02d}_' + path.name)).write_bytes(path.read_bytes())
    print(json.dumps({'plan': str(args.out_dir / 'plan.json'), 'trials': len(plan['trials']),
                      'window': window, 'target': plan['target_xyzw_xyz']}, indent=2))


def contacts(env):
    p = env.world.p
    left, right = env.robot.LEFTFINGERIDX, env.robot.RIGHTFINGERIDX
    rows = [{'robot_link': int(c[3]), 'object_link': int(c[4]),
             'position_on_object': list(c[6]), 'distance_m': float(c[8]),
             'normal_force_n': float(c[9])}
            for c in p.getContactPoints(bodyA=env.robot.panda, bodyB=env.obj.uid)
            if int(c[3]) in (left, right)]
    return {'left': any(c['robot_link'] == left for c in rows),
            'right': any(c['robot_link'] == right for c in rows), 'points': rows}


def render_frame(env, view, projection, title):
    from PIL import Image, ImageDraw
    rgba = env.world.p.getCameraImage(width=360, height=360, viewMatrix=view,
                projectionMatrix=projection, renderer=env.world.p.ER_TINY_RENDERER)[2]
    canvas = Image.new('RGB', (560, 400), '#152b3b')
    canvas.paste(Image.fromarray(np.asarray(rgba, dtype=np.uint8).reshape(360, 360, 4)[:, :, :3]), (100, 40))
    ImageDraw.Draw(canvas).text((8, 8), title, fill='white')
    return np.asarray(canvas)


def worker(args, plan):
    from diagnostics.execution_trace import ExecutionTrace, physical_state, plain
    from generate_logged_references import make_env, native_grasp
    import imageio.v2 as imageio
    trial = plan['trials'][args.trial_index]
    output = args.out_dir / 'trials' / f'{args.trial_index:02d}_{trial["condition"]}_r{trial["repeat"]}'
    output.mkdir(parents=True, exist_ok=False)
    started = time.monotonic()
    env, trace = None, None
    try:
        with np.load(args.out_dir / 'reference_inputs.npz') as data:
            inputs = {key: data[key].copy() for key in data.files}
        actions = inputs['actions']
        w = plan['window']
        env = make_env(Path(plan['data_root']), plan['case'], plan['seed'], native_task_context=True)
        trace = ExecutionTrace(env)
        dump(output / 'initial_state.json', plain(trace.initial))
        config = env.config
        view = env.world.p.computeViewMatrixFromYawPitchRoll(
            cameraTargetPosition=list(config.cam_static_target), distance=config.cam_static_dist,
            yaw=config.cam_static_yaw, pitch=config.cam_static_pitch, roll=0,
            upAxisIndex=config.up_axis_index)
        projection = env.world.p.computeProjectionMatrixFOV(fov=60, aspect=1, nearVal=config.cam_near, farVal=config.cam_far)
        commands, target = None, np.asarray(plan['target_xyzw_xyz'])
        states, rows, frames = [], [], []
        boundary = None
        for index in range(len(actions)):
            if index == w['start']:
                start_state = physical_state(env)
                dump(output / 'approach_start_state.json', start_state)
                commands, target = guided_commands(actions, w, start_state['tcp_xyzw_xyz'],
                                                   plan['target_xyzw_xyz'], trial['condition'])
                dump(output / 'target.json', {'target_xyzw_xyz': target.tolist(),
                    'reference_measured_target_xyzw_xyz': plan['target_xyzw_xyz'],
                    'source': 'successful command' if trial['condition'] == 'commanded_pose_hold'
                              else 'successful replay measured preclosure TCP pose',
                    'deliberate_world_x_shift_m': .05 if trial['condition'] == 'shifted_pose_bridge' else 0.})
            action = actions[index] if commands is None else commands[index]
            trace.phase = ('prefix' if index < w['start'] else 'approach' if index < w['close']
                           else 'closure' if index < w['end'] else 'original_task_continuation')
            _, _, done, info = env.step(action.copy())
            trace.finish_action()
            state = physical_state(env)
            states.append(state)
            contact = contacts(env)
            error = pose_error(state['tcp_xyzw_xyz'], target)
            original_error = pose_error(state['tcp_xyzw_xyz'], plan['target_xyzw_xyz'])
            row = {'index': index, 'phase': trace.phase, 'native_task_success': bool(done),
                   'completion_rate': float(info['Completion Rate']),
                   'target_position_error_mm': error['position_mm'], 'target_rotation_error_deg': error['rotation_deg'],
                   'reference_target_position_error_mm': original_error['position_mm'],
                   'finger_opening_m': state['finger_m'], 'command_opening_m': float(action[6]),
                   'left_finger_contact': contact['left'], 'right_finger_contact': contact['right']}
            rows.append(row)
            if index == w['end'] - 1:
                steps = trace.physics_steps
                native_part = native_grasp(env)
                if trace.physics_steps != steps:
                    raise RuntimeError('Grasp diagnostic unexpectedly advanced physics')
                boundary = {'index': index, 'native_part_grasp': native_part,
                            'part': plan['case']['part'], 'contacts': contact,
                            'supplied_pose_error': error, 'reference_pose_error': original_error,
                            'reached_supplied_pose': error['position_mm'] <= plan['limits']['pose_reach_position_mm']
                                 and error['rotation_deg'] <= plan['limits']['pose_reach_rotation_deg'],
                            'state': state,
                            'native_predicate_note': 'Native grasp predicate accepts either finger; '
                                                     'raw left/right physics contacts are reported separately.'}
                dump(output / 'grasp_boundary.json', boundary)
            if index >= w['start'] - 1 or index == 0:
                frames.append(render_frame(env, view, projection,
                    f'{trial["condition"]} | step {index} | {trace.phase}\n'
                    f'Target error {error["position_mm"]:.1f} mm | task success {bool(done)}'))
            if index % 20 == 0:
                dump(output / 'progress.json', {'index': index, 'total': len(actions), **trial})
        actual = np.asarray([e['action'] for e in trace.events if e['kind'] == 'action'])
        if commands is None or not np.array_equal(actual, commands):
            raise RuntimeError('Applied action log does not match planned commands')
        tcp = np.asarray([s['tcp_xyzw_xyz'] for s in states])
        objects = np.asarray([s['object_xyz'] for s in states])
        prefix = slice(0, w['start'])
        prefix_position = float(np.linalg.norm(tcp[prefix, 4:] - inputs['reference_tcp'][prefix, 4:], axis=1).max())
        prefix_angle = float(np.rad2deg((Rotation.from_quat(tcp[prefix, :4]).inv()
                          * Rotation.from_quat(inputs['reference_tcp'][prefix, :4])).magnitude()).max())
        prefix_object = float(np.linalg.norm(objects[prefix] - inputs['reference_object'][prefix], axis=1).max())
        prefix_valid = prefix_position <= plan['limits']['prefix_position_m'] and prefix_angle <= plan['limits']['prefix_rotation_deg'] and prefix_object <= plan['limits']['prefix_position_m']
        if not prefix_valid:
            raise RuntimeError('Common prefix failed reproducibility screen')
        np.savez_compressed(output / 'trajectories.npz', source_actions=actions, applied_actions=actual,
                            tcp=tcp, object_xyz=objects,
                            fingers=np.asarray([s['finger_m'] for s in states]),
                            native_task_success=np.asarray([r['native_task_success'] for r in rows]))
        with gzip.open(output / 'execution.json.gz', 'wt') as handle:
            json.dump(plain({'initial': trace.initial, 'events': trace.events}), handle)
        with (output / 'per_step.csv').open('w') as handle:
            writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
        imageio.mimsave(output / 'execution.gif', frames, duration=1 / env.control_hz, loop=0)
        success = [r['index'] for r in rows if r['native_task_success']]
        result = {'status': 'completed', **trial, 'seed': plan['seed'], 'case': plan['case'],
                  'action_count': len(actual), 'physics_steps': trace.physics_steps,
                  'native_controller_defaults': True, 'gripper_schedule_unchanged': bool(np.array_equal(actual[:, 6], actions[:, 6])),
                  'prefix': {'verified': prefix_valid, 'position_max_m': prefix_position,
                             'rotation_max_deg': prefix_angle, 'object_position_max_m': prefix_object},
                  'before_closure': rows[w['close'] - 1], 'grasp_boundary': boundary,
                  'native_full_task_success_any': bool(success), 'first_full_task_success_index': success[0] if success else None,
                  'native_full_task_success_final': bool(rows[-1]['native_task_success']),
                  'interpretation': plan['interpretation'], 'wall_s': time.monotonic() - started}
        dump(output / 'summary.json', result)
        print('[pose-pilot]', json.dumps({k: result[k] for k in ['condition', 'repeat', 'native_full_task_success_any', 'wall_s']}), flush=True)
    except BaseException as error:
        dump(output / 'summary.json', {'status': 'runtime_error', **trial, 'error': repr(error),
                                      'wall_s': time.monotonic() - started})
        raise
    finally:
        if trace is not None:
            trace.close()
        if env is not None:
            env.close()


def report(args, plan):
    rows = [(p.parent, json.loads(p.read_text())) for p in sorted((args.out_dir / 'trials').glob('*/summary.json'))]
    completed = [(p, v) for p, v in rows if v['status'] == 'completed']
    groups = []
    for condition in CONDITIONS:
        group = [(p, v) for p, v in completed if v['condition'] == condition]
        repeat = None
        if len(group) == 2:
            with np.load(group[0][0] / 'trajectories.npz') as a, np.load(group[1][0] / 'trajectories.npz') as b:
                pos = float(np.linalg.norm(a['tcp'][:, 4:] - b['tcp'][:, 4:], axis=1).max())
                rot = float(np.rad2deg((Rotation.from_quat(a['tcp'][:, :4]).inv()
                                       * Rotation.from_quat(b['tcp'][:, :4])).magnitude()).max())
                obj = float(np.linalg.norm(a['object_xyz'] - b['object_xyz'], axis=1).max())
                repeat = {'max_tcp_m': pos, 'max_rotation_deg': rot, 'max_object_m': obj,
                          'passed': pos <= plan['limits']['repeat_position_m']
                            and rot <= plan['limits']['repeat_rotation_deg'] and obj <= plan['limits']['repeat_position_m']}
        groups.append({'condition': condition, 'completed': len(group),
            'reached_pose': sum(v['grasp_boundary']['reached_supplied_pose'] for _, v in group),
            'native_part_grasp': sum(v['grasp_boundary']['native_part_grasp'] for _, v in group),
            'bilateral_finger_contact': sum(v['grasp_boundary']['contacts']['left'] and v['grasp_boundary']['contacts']['right'] for _, v in group),
            'full_task_success': sum(v['native_full_task_success_any'] for _, v in group),
            'closure_position_error_mm': [v['grasp_boundary']['supplied_pose_error']['position_mm'] for _, v in group],
            'repeatability': repeat})
    complete = len(rows) == len(plan['trials'])
    summary = {'status': 'completed' if complete else 'in_progress', 'finished': len(rows),
               'planned': len(plan['trials']), 'runtime_errors': len(rows) - len(completed),
               'groups': groups, 'protocol': plan['protocol'], 'interpretation': plan['interpretation'],
               'scope': plan['scope'], 'no_auto_expansion': True}
    dump(args.out_dir / 'summary.json', summary)
    lines = ['# Oracle-pose approach pilot', '', plan['interpretation'], '', plan['scope'], '',
             f'Finished {len(rows)}/{len(plan["trials"])} trials; runtime errors {summary["runtime_errors"]}.', '',
             'Native original-task scoring is retained. Grasp-boundary measurements precede the unchanged full-task continuation; later success can include recovery during that continuation.', '',
             '| Condition | Finished | Pose reached at closure end | Native target-part grasp | Both fingers contact | Original task succeeds |',
             '| --- | ---: | ---: | ---: | ---: | ---: |']
    for g in groups:
        n = g['completed']
        lines.append(f'| {g["condition"]} | {n}/2 | {g["reached_pose"]}/{n} | {g["native_part_grasp"]}/{n} | {g["bilateral_finger_contact"]}/{n} | {g["full_task_success"]}/{n} |')
    lines += ['', 'The recorded-replay pose error uses the measured preclosure reference pose as a diagnostic; it does not command that pose.', '',
              'Pose reach uses predefined 5 mm / 5 degree tolerances at the end of the recorded closure window. Native grasp accepts either finger; bilateral physics contact is a separate measurement, not a new task-success rule.', '',
              '[Plan](plan.json) · [Machine-readable summary](summary.json)', '', '## Executions', '']
    for path, value in completed:
        relative = path.relative_to(args.out_dir)
        lines.append(f'- {value["condition"]}, repeat {value["repeat"]}: [video]({relative}/execution.gif), [measurements]({relative}/summary.json), [per-step records]({relative}/per_step.csv)')
    if completed:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        fig, axes = plt.subplots(1, 2, figsize=(11, 4))
        for path, value in completed:
            if value['repeat']:
                continue
            with np.load(path / 'trajectories.npz') as data:
                tcp = data['tcp']
                w = plan['window']
                target = np.asarray(plan['target_xyzw_xyz'])
                stop = w['end']
                indices = np.arange(w['start'], stop)
                axes[0].plot(indices, 1000 * np.linalg.norm(tcp[indices, 4:] - target[4:], axis=1), label=value['condition'])
                axes[1].plot(tcp[indices, 4] * 1000, tcp[indices, 6] * 1000, label=value['condition'])
        axes[0].axvline(plan['window']['close'], color='black', linestyle=':', label='Closure begins')
        axes[0].set(xlabel='Source action index', ylabel='Distance to unshifted reference pose (mm)')
        axes[1].set(xlabel='World X (mm)', ylabel='World Z (mm)')
        axes[1].scatter([plan['target_xyzw_xyz'][4] * 1000], [plan['target_xyzw_xyz'][6] * 1000], marker='*', color='black', s=100)
        axes[0].legend(fontsize=7)
        fig.suptitle('Analytic oracle-pose approach diagnostic — one mug source, repeat 0')
        fig.tight_layout()
        fig.savefig(args.out_dir / 'approach_comparison.png', dpi=160)
        plt.close(fig)
        lines += ['', '![Approach measurements](approach_comparison.png)', '']
    (args.out_dir / 'README.md').write_text('\n'.join(lines) + '\n')
    print(json.dumps(summary, indent=2))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mode', choices=['prepare', 'worker', 'report'], required=True)
    parser.add_argument('--out-dir', type=Path, required=True)
    parser.add_argument('--data-root', type=Path, default=Path('/p/part2action/data/PartInstruct'))
    parser.add_argument('--reference', type=Path, default=DEFAULT_REFERENCE)
    parser.add_argument('--trial-index', type=int)
    args = parser.parse_args()
    if args.mode == 'prepare':
        prepare(args)
        return
    plan = json.loads((args.out_dir / 'plan.json').read_text())
    for name, expected in plan['source_sha256'].items():
        if sha(name) != expected:
            raise RuntimeError('Source changed: ' + name)
    if sha(args.out_dir / 'reference_inputs.npz') != plan['input_sha256']:
        raise RuntimeError('Reference inputs changed')
    if args.mode == 'report':
        report(args, plan)
    else:
        if args.trial_index is None or not 0 <= args.trial_index < len(plan['trials']):
            raise ValueError('A valid trial index is required')
        worker(args, plan)


if __name__ == '__main__':
    main()
