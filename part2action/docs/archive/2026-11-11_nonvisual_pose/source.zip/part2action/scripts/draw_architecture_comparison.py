"""Render the implemented visual policy and isolated pose-guided pilot.

This creates a standalone report figure, not a slide or a proposed architecture.
No model, experiment configuration, or historical presentation is modified.
Run with the part2action_train environment, which provides matplotlib and PIL.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch
from PIL import Image


ROOT = Path(__file__).resolve().parents[2]
DEFAULT_OUTPUT = ROOT / "part2action/docs/figures/2026-11-10_architecture_comparison"
STEM = "visual_policy_vs_pose_guided_pilot"
SOURCES = [
    "part2action/configs/architecture_update/"
    "hierarchical_world_geometry_10epoch_diffusion_next_action_transformer.yaml",
    "part2action/models/part2action_model.py",
    "part2action/models/pose_guided_actor.py",
    "part2action/models/part_conditioned_pose.py",
    "part2action/data/visible_pose_geometry.py",
    "part2action/configs/pose_learning/visible_geometry_v2.json",
    "part2action/scripts/run_pose_point_ablation.py",
    "part2action/scripts/run_sparse_visible_pose_geometry.py",
]

MERMAID = """flowchart LR
  subgraph A["(a) Original visual policy: Transformer control"]
    direction TB
    A0["RGB history + scene point cloud<br/>Task instruction + robot state"]
    A1["Perception encoders<br/>Frozen DINOv2 / Flan-T5<br/>Point-cloud encoder + learned visual part gate"]
    A2["Temporal / skill context + fusion<br/>Skill plan, phase selection, termination"]
    A3["Transformer diffusion action head<br/>Predict an 8-step command chunk"]
    A4["Execute first command<br/>TCP position + orientation + gripper"]
    A0 --> A1 --> A2 --> A3 --> A4
    A4 -->|"New visual observations + robot state"| A0
  end
  subgraph B["(b) Separate pose-guided grasp pilot"]
    direction TB
    B0["Geometry at approach start<br/>Complete GT shape OR visible depth shape<br/>GT-derived object / part selection"]
    B1["Initial robot state<br/>TCP pose + gripper opening"]
    B2["Learned pose predictor: MLP<br/>Fixed geometry statistics + initial state<br/>52 to 64 to 64 to 9"]
    BG["Oracle GT target TCP pose<br/>Alternative to pose prediction"]
    B3["Target grasp pose<br/>Predicted OR GT; fixed during grasp window"]
    BS["Current robot state<br/>TCP pose + gripper opening"]
    BT["Privileged source-event timing<br/>Reference closure / skill-end indices"]
    B4["Learned action controller: MLP<br/>18 to 128 to 128 to 128 to 7"]
    B5["Execute one command<br/>TCP position + orientation + gripper"]
    B0 --> B2
    B1 --> B2
    B2 --> B3
    BG -.->|"Oracle alternative"| B3
    B3 --> B4
    BS --> B4
    BT -.-> B4
    B4 --> B5
    B5 -->|"Refresh robot state"| BS
  end
  classDef learned fill:#eaf2fc,stroke:#285da8,color:#19334e;
  classDef oracle fill:#fff4df,stroke:#a76018,color:#73400e;
  classDef execution fill:#eef6f3,stroke:#46796a,color:#19334e;
  class A1,A2,A3,B2,B4 learned;
  class BG,BT oracle;
  class A4,B5 execution;
%% Auxiliary heads and internal feature connections are grouped for clarity.
%% No connection exists between the original Transformer and the pilot.
%% Geometry/initial robot state are read once; controller state refreshes each step.
%% Pilot controls only the initial grasp window; recorded prefix/tail are omitted.
%% No-pose control is a separately trained small MLP with zero pose channels.
"""

CAPTION = r"""% Standalone figure, not a slide. Copy the PDF beside this snippet, or
% set the graphic path to its location in the report. Requires graphicx.
\begin{figure*}[t]
  \centering
  \includegraphics[width=\textwidth]{visual_policy_vs_pose_guided_pilot.pdf}
  \caption{Implemented Part2Action architectures (simplified inference flow).
  (a) The original visual policy combines RGB history, scene geometry, language,
  and robot state with learned skill context. A Transformer diffusion head
  predicts eight commands; the first is executed before observing again.
  (b) A separate pose predictor maps geometry and initial robot state to a target
  TCP pose. A learned MLP controller directly predicts the next command from
  that target, current robot state, and privileged reference-event timing.
  Oracle evaluation supplies the ground-truth target pose instead of the
  predicted pose. Geometry conditions use complete GT shape or visible depth
  shape with GT-derived object/part selection. The pilot controls the initial
  grasp window; its recorded prefix and continuation are omitted.
  The original Transformer is not part of the pilot.}
  \label{fig:visual-policy-vs-pose-pilot}
\end{figure*}
"""


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def render(output: Path, dpi: int) -> dict:
    plt.rcParams.update({
        "font.family": "DejaVu Sans",
        "svg.fonttype": "none",
        "pdf.fonttype": 42,
        "pdf.compression": 9,
    })
    fig, ax = plt.subplots(figsize=(18, 13.7), dpi=100)
    fig.subplots_adjust(left=0, right=1, bottom=0, top=1)
    ax.set(xlim=(0, 1800), ylim=(1370, 0))
    ax.axis("off")

    navy = "#19334e"
    muted = "#53677a"
    border = "#b9c8d5"
    blue = "#285da8"
    teal = "#18766d"
    amber = "#a76018"
    learned_bg = "#eaf2fc"
    oracle_bg = "#fff4df"
    execution_bg = "#eef6f3"
    artists = []
    contained = []

    def text(x, y, label, size=17, weight="normal", color=navy,
             ha="center", rotation=0):
        artist = ax.text(x, y, label, fontsize=size, fontweight=weight,
                         color=color, ha=ha, va="center", linespacing=1.4,
                         rotation=rotation, zorder=6)
        artists.append(artist)
        return artist

    def rect(x, y, width, height, fill="white", edge=border, radius=13, lw=1.4,
             zorder=3):
        ax.add_patch(FancyBboxPatch(
            (x, y), width, height,
            boxstyle=f"round,pad=0,rounding_size={radius}",
            facecolor=fill, edgecolor=edge, linewidth=lw, zorder=zorder))

    def box(x, y, width, height, title, detail="", fill="white",
            edge=border, title_size=19, detail_size=16, title_color=navy):
        rect(x, y, width, height, fill, edge)
        title_y = y + (30 if detail else height / 2)
        artist = text(x + width / 2, title_y, title,
                      title_size, "bold", title_color)
        contained.append((artist, (x, y, width, height)))
        if detail:
            artist = text(x + width / 2, y + (height + 35) / 2, detail,
                          detail_size, color=muted)
            contained.append((artist, (x, y, width, height)))

    def route(points, color=muted, dashed=False, lw=1.7):
        style = (0, (5, 4)) if dashed else "-"
        if len(points) > 2:
            ax.plot([p[0] for p in points[:-1]], [p[1] for p in points[:-1]],
                    color=color, linewidth=lw, linestyle=style, zorder=2)
        ax.add_patch(FancyArrowPatch(
            points[-2], points[-1], arrowstyle="-|>",
            mutation_scale=18, shrinkA=0, shrinkB=0,
            color=color, linewidth=lw, linestyle=style, zorder=2))

    text(40, 42, "Part2Action: two action-generation architectures", 28,
         "bold", ha="left")
    text(40, 82, "Implemented systems · simplified inference dataflow", 17,
         color=muted, ha="left")

    rect(40, 120, 840, 1085, fill="#fbfcfe", edge="#d7e1e9", radius=19,
         zorder=0)
    rect(920, 120, 840, 1085, fill="#fbfdfc", edge="#d7e1e9", radius=19,
         zorder=0)
    text(460, 163, "(a) Original visual policy", 25, "bold", blue)
    text(460, 199, "Transformer control variant", 17, color=muted)
    text(1340, 163, "(b) Pose-guided grasp pilot", 25, "bold", teal)
    text(1340, 199, "Separate pose predictor + action controller", 17, color=muted)

    # The visual policy groups internal skill/perception cross-connections;
    # it does not imply that the frozen encoders or the gate are one model.
    box(155, 240, 610, 115, "Visual observations + task + state",
        "RGB history (2 frames) + scene point cloud\nInstruction + TCP pose + gripper opening")
    box(155, 405, 610, 130, "Perception encoders",
        "Frozen DINOv2 + Flan-T5\nScene point-cloud encoder + visual part gate",
        fill=learned_bg, edge=blue)
    box(155, 590, 610, 100, "Temporal / skill context + fusion",
        "Skill plan, phase selection, termination",
        fill=learned_bg, edge=blue)
    box(155, 755, 610, 125, "Transformer diffusion action head",
        "Action-generating model\nPredicts an 8-step command chunk",
        fill=learned_bg, edge=blue)
    box(155, 935, 610, 85, "Execute first command",
        "TCP position + orientation + gripper", fill=execution_bg,
        edge="#46796a")
    for start, end in [(355, 405), (535, 590), (690, 755), (880, 935)]:
        route([(460, start), (460, end)])
    route([(155, 977.5), (90, 977.5), (90, 297.5), (155, 297.5)])
    text(65, 635, "Refresh visual observations + robot state", 15,
         color=muted, rotation=90)
    box(155, 1080, 610, 80, "Closed-loop visual action generation",
        "The policy generates each executed action.",
        fill="white", title_size=18, detail_size=16)

    # Geometry is selected from an initial snapshot. The oracle pose is a
    # mutually exclusive replacement, not a second feature added to prediction.
    box(985, 240, 450, 115, "Geometry at approach start",
        "Complete GT shape OR camera depth\nGT-derived object / part selection",
        title_size=18, detail_size=15.5)
    box(1485, 240, 235, 115, "Initial state",
        "TCP pose\n+ gripper opening", title_size=17, detail_size=16)
    box(985, 405, 450, 130, "Learned pose predictor (MLP)",
        "Geometry statistics + initial state\n52 → 64 → 64 → 9",
        fill=learned_bg, edge=blue, title_size=18, detail_size=16)
    box(1485, 420, 235, 100, "Oracle GT pose",
        "Reference TCP pose\nReplaces prediction",
        fill=oracle_bg, edge=amber, title_color=amber,
        title_size=18, detail_size=15.5)
    box(985, 590, 450, 100, "Target grasp pose",
        "Predicted OR GT position + orientation\nFixed during the grasp window",
        title_size=19, detail_size=15.5)
    route([(1210, 355), (1210, 405)])
    route([(1485, 297.5), (1460, 297.5), (1460, 470), (1435, 470)])
    route([(1210, 535), (1210, 590)])
    route([(1602.5, 520), (1602.5, 640), (1435, 640)], color=amber, dashed=True)
    text(1602.5, 665, "Oracle alternative", 15, color=amber)

    # The controller is the trained action model. Current state (but not
    # camera input) refreshes during its control loop; source timing is privileged.
    box(985, 755, 450, 125, "Learned action controller",
        "Action-generating model\nMLP: 18 → 128 → 128 → 128 → 7",
        fill=learned_bg, edge=blue, title_size=18, detail_size=16)
    box(1485, 695, 235, 80, "Robot state",
        "TCP pose + opening", title_size=17, detail_size=15.5)
    box(1485, 810, 235, 80, "Event timing*",
        "Reference episode",
        fill=oracle_bg, edge=amber, title_color=amber,
        title_size=16.5, detail_size=15.5)
    box(985, 935, 450, 85, "Execute one command",
        "TCP position + orientation + gripper",
        fill=execution_bg, edge="#46796a", detail_size=15.5)
    route([(1210, 690), (1210, 755)])
    route([(1485, 735), (1460, 735), (1460, 790), (1435, 790)])
    route([(1485, 850), (1435, 850)], color=amber, dashed=True)
    route([(1210, 880), (1210, 935)])
    route([(1435, 977.5), (1740, 977.5), (1740, 735), (1720, 735)])
    text(1585, 1004, "Refresh state each step", 15, color=muted)
    box(985, 1080, 735, 80, "Isolated grasp-stage experiment",
        "The original Transformer is not used in this pipeline.",
        fill="white", title_size=18, detail_size=16)

    # Explicit report context: inference privileges and evaluation scope must
    # remain visible if this figure is reused without the conversation.
    for x, fill, edge, label in [
        (65, learned_bg, blue, "Learned modules (frozen encoders marked)"),
        (775, oracle_bg, amber, "Oracle / privileged inputs"),
        (1280, execution_bg, "#46796a", "Robot command execution"),
    ]:
        rect(x, 1233, 26, 22, fill, edge, radius=4)
        text(x + 41, 1244, label, 16, color=muted, ha="left")
    text(40, 1290,
         "* Timing uses reference closure / skill-end indices. The pilot controls the initial grasp; its prefix and continuation are recorded.",
         15.5, color=muted, ha="left")
    text(40, 1326,
         "No-pose control = separately trained small MLP with zero target-pose channels. Auxiliary heads / internal connections are grouped or omitted.",
         15.5, color=muted, ha="left")

    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    layout_errors = []
    for artist in artists:
        bounds = artist.get_window_extent(renderer)
        if not (fig.bbox.x0 <= bounds.x0 and bounds.x1 <= fig.bbox.x1
                and fig.bbox.y0 <= bounds.y0 and bounds.y1 <= fig.bbox.y1):
            layout_errors.append(f"Text clipped by figure: {artist.get_text()}")
    for artist, (x, y, width, height) in contained:
        bounds = artist.get_window_extent(renderer)
        left_top = ax.transData.transform((x + 8, y + 5))
        right_bottom = ax.transData.transform((x + width - 8, y + height - 5))
        if not (left_top[0] <= bounds.x0 and bounds.x1 <= right_bottom[0]
                and right_bottom[1] <= bounds.y0 and bounds.y1 <= left_top[1]):
            layout_errors.append(f"Text exceeds its box: {artist.get_text()}")
    for i, first in enumerate(artists):
        for second in artists[i + 1:]:
            if first.get_window_extent(renderer).overlaps(second.get_window_extent(renderer)):
                layout_errors.append(f"Overlapping text: {first.get_text()} / {second.get_text()}")
    if layout_errors:
        raise ValueError("\n".join(layout_errors))

    for extension in ("svg", "pdf", "png"):
        fig.savefig(output / f"{STEM}.{extension}", dpi=dpi, facecolor="white")
    plt.close(fig)
    (output / f"{STEM}.mmd").write_text(MERMAID)
    (output / "report_figure.tex").write_text(CAPTION)
    with Image.open(output / f"{STEM}.png") as raster:
        raster.load()
        dimensions = list(raster.size)
    return {"png_dimensions": dimensions, "text_layout_checks": "passed"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out-dir", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--dpi", type=int, default=240)
    args = parser.parse_args()
    if args.dpi < 100:
        parser.error("Use at least 100 dpi for legible output")
    output = args.out_dir.resolve()
    output.mkdir(parents=True, exist_ok=True)
    outputs = [output / f"{STEM}.{ext}" for ext in ("png", "svg", "pdf", "mmd")]
    outputs += [output / "report_figure.tex", output / "manifest.json"]
    if any(path.exists() for path in outputs):
        raise FileExistsError("Use a new output directory to preserve the existing figure")
    checks = render(output, args.dpi)
    manifest = {
        "title": "Original visual policy versus isolated pose-guided grasp pilot",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "generator": str(Path(__file__).resolve().relative_to(ROOT)),
        "generator_sha256": sha(Path(__file__).resolve()),
        "source_sha256": {path: sha(ROOT / path) for path in SOURCES},
        "scope": [
            "Implemented inference architectures; no performance comparison is claimed.",
            "The visual panel uses the Transformer control variant, with explicit contact-target input disabled.",
            "Auxiliary heads and interacting perception/skill connections are simplified.",
            "The pose pipeline is separate from the original Transformer.",
            "The diagram shows the point-free pose head used in the latest geometry studies.",
            "Geometry and initial robot state are read once; the target pose is held fixed during the grasp window.",
            "The controller uses current robot state and privileged reference-event timing; it does not read images.",
            "Oracle pose replaces predicted pose and retains the trained action controller.",
            "Visible shape coordinates come from depth; object/part selection is GT-derived proximity labeling.",
            "The pilot controls the first grasp skill; recorded prefix and continuation are not learned by this controller.",
            "The separately trained no-pose MLP control is distinct from the original visual Transformer.",
        ],
        "files": {path.name: {"bytes": path.stat().st_size, "sha256": sha(path)}
                  for path in outputs if path.name != "manifest.json"},
        **checks,
    }
    (output / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps({"output": str(output), **checks,
                      "files": list(manifest["files"])}, indent=2))


if __name__ == "__main__":
    main()
