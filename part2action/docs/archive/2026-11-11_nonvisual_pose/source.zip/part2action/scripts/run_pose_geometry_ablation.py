"""Matched geometry-feature ablation with a frozen pose-conditioned actor.

All heads receive the same privileged surface point. This isolates pose-head
features, not localization or an OAF reproduction. Long stages run on Slurm.
"""
from __future__ import annotations

import argparse
import copy
import csv
import hashlib
import json
from pathlib import Path
import random
import shutil
import subprocess
import time

import numpy as np
from scipy.spatial.transform import Rotation

from diagnostics.pose_guided_approach import approach_window, pose_error
from models.interaction_pose_head import InteractionPoseHead, pose_features, rotation6d
from models.pose_geometry_ablation import FEATURE_VARIANTS, apply_feature_variant, feature_mask
from models.pose_guided_actor import PoseGuidedActor
from run_point_to_pose import BASE, collect, head_loss, head_metrics
from run_pose_guided_approach import ROOT, contacts, dump, render_frame, sha

PARENT = Path('/p/part2action/results/diagnostics/point_to_pose_20261105_01')
VARIANTS = ('point_state', 'object_geometry', 'part_geometry', 'part_geometry_semantics')


def read(path):
    return json.loads(Path(path).read_text())


def write_csv(path, rows):
    if not rows:
        return
    with Path(path).open('w') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def model_paths(root, variant, seed):
    stem = root / 'models' / variant / f'seed{seed}'
    return stem.with_suffix('.pt'), stem.with_suffix('.json')


def placeholder(root, plan, status):
    (root / 'README.md').write_text(
        '# Matched point-to-pose geometry ablation\n\n'
        f'**Status: {status}.**\n\n{plan["protocol"]}\n\n'
        f'{len(plan["cases"])} geometry sources; {len(plan["training_trials"])} matched heads; '
        f'{len(plan["trials"])} executions.\n\n'
        '[Plan](plan.json) · [Job IDs](submissions.json) · [Status snapshot](status.json)\n\n'
        'Final tables, paired outcomes, learning curves and execution videos will appear here automatically. '
        'The status snapshot is not live; use the background checker for progress.\n\n'
        + '\n'.join('- ' + text for text in plan['limits']) + '\n')


def prepare(args):
    import h5py
    if tuple(FEATURE_VARIANTS) != VARIANTS:
        raise ValueError('Declared feature variants disagree with model utility')
    old = read(PARENT / 'plan.json')
    if read(PARENT / 'summary.json')['status'] != 'completed':
        raise ValueError('Parent collection/training/execution must be complete')
    cases = copy.deepcopy(old['cases'])
    base = read(BASE / 'plan.json')
    eligible = set(read(BASE / 'summary.json')['eligible_case_indices'])
    meta = read(Path(old['data_root']) / 'episodes_meta_train.json')
    episodes = {str(e['ep_id']): e for rows in meta['mug']['train'].values() for e in rows}
    args.out_dir.mkdir(parents=True, exist_ok=False)
    (args.out_dir / 'cases').mkdir()
    (args.out_dir / 'observations').mkdir()
    excluded, extras = [], []
    seen = {c['demo'] for c in cases}
    rng = random.Random(20261107)
    with h5py.File(Path(old['data_root']) / 'demos/mug.hdf5') as handle:
        for instance in sorted(old['instance_split']['test']):
            candidates = [(i, c) for i, c in enumerate(base['cases'])
                          if i in eligible and c['object'] == 'mug' and c['task_type'] == '3'
                          and c['object_id'] == instance and c['demo'] not in seen and c['actions'] <= 200]
            rng.shuffle(candidates)
            for source_index, source in candidates:
                if sum(c['split'] == 'test' and c['object_id'] == instance for c in cases) >= 6:
                    break
                try:
                    demo = handle['data'][source['demo']]
                    actions = demo['actions'][:]
                    instructions = [s.decode() if isinstance(s, bytes) else str(s)
                                    for s in demo['skill_instructions'][:]]
                    window = approach_window(actions, instructions)
                    if window['close'] < 10 or window['end'] > 160:
                        raise ValueError('Outside unchanged event budget')
                    reference = BASE / 'cases' / f'{source_index:05d}' / 'repeat_0'
                    with np.load(reference / 'trajectories.npz') as values:
                        if not np.array_equal(actions, values['actions']):
                            raise ValueError('Reference command mismatch')
                        goal = values['before_tcp'][window['close']].copy()
                        path = args.out_dir / 'cases' / f'extra_{len(cases):03d}.npz'
                        np.savez_compressed(path, source_actions=actions, before_tcp=values['before_tcp'],
                                            reference_tcp=values['replay_tcp'],
                                            reference_object=values['object_xyz'], goal=goal)
                    episode = episodes[source['episode_id']]
                    extras.append(len(cases))
                    cases.append({**source, 'split': 'test', 'source_index': source_index,
                                  'episode': episode, 'part': episode['chain_params'][0]['params'].get('part_grasp', ''),
                                  'window': window, 'reference': str(reference), 'case_file': str(path),
                                  'case_sha256': sha(path), 'goal_xyzw_xyz': goal.tolist(),
                                  'origin': 'Fixed expanded pilot within original held-out instances'})
                    seen.add(source['demo'])
                except (KeyError, ValueError, OSError) as error:
                    excluded.append({'demo': source['demo'], 'reason': str(error)})
    if any(sum(c['split'] == 'test' and c['object_id'] == obj for c in cases) != 6
           for obj in old['instance_split']['test']):
        raise ValueError('Could not fill prespecified six demonstrations per test instance')
    for i in range(len(old['cases'])):
        source = PARENT / 'observations' / f'{i:03d}'
        record = read(source / 'summary.json')
        if record['status'] != 'completed' or sha(source / 'inputs.npz') != record['input_sha256']:
            raise ValueError('Parent observation invalid')
        shutil.copytree(source, args.out_dir / 'observations' / f'{i:03d}')
    shutil.copyfile(PARENT / 'frozen_actor.pt', args.out_dir / 'frozen_actor.pt')
    files = [Path(__file__), ROOT / 'part2action/models/pose_geometry_ablation.py',
             ROOT / 'part2action/slurm/pose_geometry_ablation.sbatch']
    files.extend(Path(p) for p in old['source_sha256'])
    files = list(dict.fromkeys(files))
    source_hashes = {str(path): sha(path) for path in files}
    for path, expected in old['source_sha256'].items():
        if source_hashes[path] != expected:
            raise ValueError('Parent simulation/model code changed: ' + path)
    evaluation_indices = [0] + [i for i, case in enumerate(cases) if case['split'] == 'test']
    plan = {**old, 'study': 'matched_pose_geometry_ablation', 'parent': str(PARENT), 'cases': cases,
            'new_collection_indices': extras, 'excluded': excluded, 'source_sha256': source_hashes,
            'variants': list(VARIANTS), 'feature_masks': {v: feature_mask(v).astype(int).tolist() for v in VARIANTS},
            'training_trials': [{'variant': v, 'seed': seed} for v in VARIANTS for seed in old['seeds']],
            'trials': [{'case_index': i, 'condition': v} for i in evaluation_indices
                       for v in ('oracle_pose', *VARIANTS)], 'evaluation_case_indices': evaluation_indices,
            'batch_size': 64, 'selection_seed': 20261107,
            'protocol': 'Four equally sized pose heads share the same supplied point, frozen controller, '
                        'training examples, initialization/minibatches per seed, loss and update budget. '
                        'Vary only retained geometry/semantic input channels. Observe once after action 0; '
                        'execute neural actor through the first skill, then original recorded continuation.',
            'limits': [
                'Every head receives the same privileged point selected using the successful reference TCP pose.',
                'Object geometry means centroid/extents, not RGB or full scene encoding.',
                'Point/state vs object vs part geometry vs added semantic identity isolates features, not learned localization.',
                'The actor, source-event clock, action-0 prefix and recorded continuation are fixed.',
                '24 held-out demonstrations belong to four previously inspected mug instances; not 24 independent shapes or a fresh final benchmark.',
                'Training/development examples and instance split are unchanged; new sources expand evaluation only.',
                'Three head training seeds; execution uses predetermined seed 42 only.',
                'The original training calibration failure remains in every condition.',
                'This is not an OAF implementation, full visual-policy repair, or tolerance evaluator.'],
            'no_auto_expansion': True}
    dump(args.out_dir / 'plan.json', plan)
    snapshots = args.out_dir / 'source_snapshot'
    snapshots.mkdir()
    for i, path in enumerate(files):
        (snapshots / f'{i:02d}_{path.name}').write_bytes(path.read_bytes())
    dump(args.out_dir / 'status.json', {'status': 'prepared', 'sources': len(cases),
                                       'models': len(plan['training_trials']), 'evaluations': len(plan['trials'])})
    placeholder(args.out_dir, plan, 'prepared')
    print(json.dumps({'sources': len(cases), 'new_collections': len(extras),
                      'train': 63, 'development': 8, 'test': 24,
                      'models': len(plan['training_trials']), 'evaluations': len(plan['trials'])}))


def load_data(root, plan):
    records = [read(root / 'observations' / f'{i:03d}' / 'summary.json') for i in range(len(plan['cases']))]
    if any(row['status'] != 'completed' for row in records):
        raise ValueError('Geometry collection incomplete or invalid')
    features, points, goals = [], [], []
    for i, row in enumerate(records):
        path = root / 'observations' / f'{i:03d}' / 'inputs.npz'
        if sha(path) != row['input_sha256']:
            raise ValueError('Observation changed')
        with np.load(path) as values:
            check = pose_features(values['point'], values['part_cloud'], values['object_cloud'],
                                  values['tcp'], float(values['opening']), plan['cases'][i]['part'])
            np.testing.assert_allclose(check, values['features'], rtol=0, atol=0)
            features.append(values['features']); points.append(values['point']); goals.append(values['goal'])
    return np.asarray(features), np.asarray(points), np.asarray(goals)


def train(args, plan):
    import torch
    torch.set_num_threads(2)
    trial = plan['training_trials'][args.index]
    variant, seed = trial['variant'], trial['seed']
    checkpoint_path, summary_path = model_paths(args.out_dir, variant, seed)
    checkpoint_path.parent.mkdir(parents=True, exist_ok=True)
    if checkpoint_path.exists() or summary_path.exists():
        raise FileExistsError('Refusing to overwrite model trial')
    started = time.monotonic()
    try:
        raw, points, goals = load_data(args.out_dir, plan)
        x = torch.tensor(apply_feature_variant(raw, variant), dtype=torch.float32)
        point = torch.tensor(points, dtype=torch.float32)
        position = torch.tensor(goals[:, 4:], dtype=torch.float32)
        matrices = Rotation.from_quat(goals[:, :4]).as_matrix()
        matrix = torch.tensor(matrices, dtype=torch.float32)
        target6 = torch.tensor(rotation6d(matrices), dtype=torch.float32)
        values = [x, point, position, matrix, target6]
        indices = {split: torch.tensor([i for i, case in enumerate(plan['cases']) if case['split'] == split])
                   for split in ('train', 'development', 'test')}
        torch.manual_seed(seed)
        model = InteractionPoseHead(plan['hidden'], plan['max_offset_m'])
        initial_sha = hashlib.sha256(b''.join(t.detach().numpy().tobytes() for t in model.state_dict().values())).hexdigest()
        batches_sha = hashlib.sha256()
        optimizer = torch.optim.AdamW(model.parameters(), lr=.001, weight_decay=.0001)
        schedule = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, plan['updates'], eta_min=1e-5)
        rng = torch.Generator().manual_seed(seed)
        history, best = [], float('inf')
        for update in range(plan['updates'] + 1):
            if update % 100 == 0:
                model.eval()
                metrics = head_metrics(model, *[v[indices['development']] for v in values])
                history.append({'variant': variant, 'seed': seed, 'update': update, **metrics})
                if metrics['loss'] < best:
                    best = metrics['loss']
                    torch.save({'state_dict': model.state_dict(), 'hidden': plan['hidden'],
                                'max_offset_m': plan['max_offset_m'], 'variant': variant,
                                'seed': seed, 'update': update, 'development_metrics': metrics}, checkpoint_path)
                dump(checkpoint_path.with_suffix('.progress.json'), {'variant': variant, 'seed': seed,
                                                                    'update': update, 'updates': plan['updates']})
            if update == plan['updates']:
                break
            model.train()
            batch = indices['train'][torch.randint(len(indices['train']), (plan['batch_size'],), generator=rng)]
            batches_sha.update(batch.numpy().tobytes())
            optimizer.zero_grad(set_to_none=True)
            prediction = model(x[batch], point[batch])
            loss = head_loss(prediction, position[batch], matrix[batch], target6[batch])
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.)
            optimizer.step(); schedule.step()
        checkpoint = torch.load(checkpoint_path, map_location='cpu', weights_only=False)
        model.load_state_dict(checkpoint['state_dict']); model.eval()
        with torch.no_grad():
            prediction = model(x, point)
        predicted = np.c_[Rotation.from_matrix(prediction['rotation'].numpy()).as_quat(), prediction['position'].numpy()]
        rows = []
        for i, (actual, target) in enumerate(zip(predicted, goals)):
            case = plan['cases'][i]
            rows.append({'variant': variant, 'seed': seed, 'case_index': i, 'split': case['split'],
                         'object_id': case['object_id'], 'demo': case['demo'], 'part': case['part'],
                         **pose_error(actual, target)})
        write_csv(checkpoint_path.with_suffix('.predictions.csv'), rows)
        write_csv(checkpoint_path.with_suffix('.history.csv'), history)
        train_ids = indices['train'].numpy()
        mean_offset = (goals[train_ids, 4:] - points[train_ids]).mean(0)
        mean_rotation = Rotation.from_quat(goals[train_ids, :4]).mean().as_quat()
        mean_errors = [pose_error(np.r_[mean_rotation, points[i] + mean_offset], goals[i])
                       for i in indices['test'].numpy()]
        dump(summary_path, {'status': 'completed', **trial, 'checkpoint_sha256': sha(checkpoint_path),
                            'selected_update': checkpoint['update'], 'initial_parameters_sha256': initial_sha,
                            'minibatches_sha256': batches_sha.hexdigest(), 'updates': plan['updates'],
                            'train_case_indices': train_ids.tolist(),
                            'parameter_count': sum(p.numel() for p in model.parameters()),
                            'elapsed_seconds': time.monotonic() - started,
                            'mean_offset_test': {k: float(np.mean([v[k] for v in mean_errors])) for k in mean_errors[0]},
                            **{split: head_metrics(model, *[v[indices[split]] for v in values]) for split in indices}})
    except BaseException as error:
        dump(summary_path, {'status': 'blocked', **trial, 'error': repr(error)})
        raise


def evaluate(args, plan):
    import torch
    import imageio.v2 as imageio
    from diagnostics.execution_trace import physical_state
    from generate_logged_references import make_env, native_grasp
    trial = plan['trials'][args.index]
    case = plan['cases'][trial['case_index']]
    condition = trial['condition']
    out = args.out_dir / 'rollouts' / f'{args.index:03d}_{case["demo"]}_{condition}'
    out.mkdir(parents=True, exist_ok=False)
    env = None
    try:
        actor_checkpoint = torch.load(args.out_dir / 'frozen_actor.pt', map_location='cpu', weights_only=False)
        actor = PoseGuidedActor(actor_checkpoint['pose_enabled'], actor_checkpoint['hidden'])
        actor.load_state_dict(actor_checkpoint['state_dict']); actor.eval()
        observation_path = args.out_dir / 'observations' / f'{trial["case_index"]:03d}'
        observation = read(observation_path / 'summary.json')
        if observation['status'] != 'completed' or sha(observation_path / 'inputs.npz') != observation['input_sha256']:
            raise ValueError('Invalid scene observation')
        with np.load(observation_path / 'inputs.npz') as values:
            context = {key: values[key].copy() for key in values.files}
        with np.load(case['case_file']) as values:
            actions, oracle = values['source_actions'].copy(), values['goal'].copy()
            expected_object_after_prefix = values['reference_object'][0].copy()
        head_sha = None
        if condition == 'oracle_pose':
            goal = oracle.copy()
        else:
            path, summary_path = model_paths(args.out_dir, condition, plan['execution_head_seed'])
            if not summary_path.exists() or read(summary_path)['status'] != 'completed':
                dump(out / 'summary.json', {'status': 'blocked', **trial, 'reason': 'Required pose head did not finish'})
                return
            head_sha = sha(path)
            if head_sha != read(summary_path)['checkpoint_sha256']:
                raise ValueError('Pose checkpoint changed')
            checkpoint = torch.load(path, map_location='cpu', weights_only=False)
            if checkpoint['variant'] != condition:
                raise ValueError('Variant checkpoint mismatch')
            head = InteractionPoseHead(checkpoint['hidden'], checkpoint['max_offset_m'])
            head.load_state_dict(checkpoint['state_dict']); head.eval()
            features = apply_feature_variant(context['features'], condition)
            goal = head.predict(features, context['point'])
        dump(out / 'inferred_pose.json', {'condition': condition, 'goal_xyzw_xyz': goal.tolist(),
                                         'point': context['point'].tolist(), 'oracle_xyzw_xyz': oracle.tolist(),
                                         'error': pose_error(goal, oracle)})
        env = make_env(Path(plan['data_root']), case, 42, native_task_context=True)
        config = env.config
        view = env.world.p.computeViewMatrixFromYawPitchRoll(cameraTargetPosition=list(config.cam_static_target),
            distance=config.cam_static_dist, yaw=config.cam_static_yaw, pitch=config.cam_static_pitch,
            roll=0, upAxisIndex=config.up_axis_index)
        projection = env.world.p.computeProjectionMatrixFOV(fov=60, aspect=1, nearVal=config.cam_near, farVal=config.cam_far)
        rows, frames, executed, states, before = [], [], [], [], []
        boundary = None
        for i, source in enumerate(actions):
            state = physical_state(env)
            before.append(state['tcp_xyzw_xyz'])
            if i == 1:
                np.testing.assert_allclose(state['tcp_xyzw_xyz'], context['tcp'], atol=1e-6, rtol=0)
                np.testing.assert_allclose(state['object_xyz'], expected_object_after_prefix, atol=1e-6, rtol=0)
                dump(out / 'decision_state.json', state)
            neural = 1 <= i < case['window']['end']
            action = actor.predict(state['tcp_xyzw_xyz'], state['finger_m'], goal, i,
                                   case['window']['close'], case['window']['end']) if neural else source.copy()
            _, _, done, _ = env.step(action.copy())
            after = physical_state(env)
            states.append(after); executed.append(action)
            rows.append({'index': i, 'neural_action': neural, 'native_task_success': bool(done),
                         'oracle_pose_error_mm': pose_error(after['tcp_xyzw_xyz'], oracle)['position_mm']})
            if i == case['window']['end'] - 1:
                boundary = {'native_part_grasp': native_grasp(env), 'contacts': contacts(env),
                            'oracle_pose_error': pose_error(after['tcp_xyzw_xyz'], oracle)}
            if i >= 1 and i % 2 == 0:
                frames.append(render_frame(env, view, projection,
                    f'GEOMETRY ABLATION | {condition} | {case["demo"]} | {case["split"]}\nStep {i} | success {bool(done)}'))
        executed = np.asarray(executed)
        if not np.array_equal(executed[0], actions[0]) or not np.array_equal(executed[case['window']['end']:], actions[case['window']['end']:]):
            raise RuntimeError('Prefix/recorded continuation changed')
        np.savez_compressed(out / 'trajectories.npz', applied_actions=executed, source_actions=actions,
                            before_tcp=np.asarray(before), tcp=np.asarray([s['tcp_xyzw_xyz'] for s in states]),
                            finger_m=np.asarray([s['finger_m'] for s in states]),
                            object_xyz=np.asarray([s['object_xyz'] for s in states]),
                            point=context['point'], inferred_goal=goal, oracle_goal=oracle)
        imageio.mimsave(out / 'execution.gif', frames, duration=.1, loop=0)
        write_csv(out / 'per_step.csv', rows)
        dump(out / 'summary.json', {'status': 'completed', **trial, 'split': case['split'],
                                    'object_id': case['object_id'], 'demo': case['demo'], 'part': case['part'],
                                    'pose_prediction_error': pose_error(goal, oracle),
                                    'native_full_task_success': any(r['native_task_success'] for r in rows),
                                    'boundary': boundary, 'actor_sha256': plan['actor_sha256'],
                                    'pose_head_sha256': head_sha})
    except BaseException as error:
        dump(out / 'summary.json', {'status': 'runtime_error', **trial, 'error': repr(error)})
        raise
    finally:
        if env is not None:
            env.close()


def report(args, plan):
    training = []
    for trial in plan['training_trials']:
        _, path = model_paths(args.out_dir, trial['variant'], trial['seed'])
        training.append(read(path) if path.exists() else {'status': 'missing', **trial})
    matched = {}
    for seed in plan['seeds']:
        rows = [row for row in training if row['seed'] == seed and row['status'] == 'completed']
        matched[str(seed)] = len(rows) == len(VARIANTS) and all(len({r[key] for r in rows}) == 1 for key in
            ('initial_parameters_sha256', 'minibatches_sha256', 'updates', 'parameter_count'))
    training_complete = all(row['status'] == 'completed' for row in training) and all(matched.values())
    dump(args.out_dir / 'training_summary.json', {'status': 'completed' if training_complete else 'blocked',
                                                 'models': training, 'matched_training_audit': matched})
    paths = sorted((args.out_dir / 'rollouts').glob('*/summary.json'))
    records = [(path, read(path)) for path in paths]
    good = [(path, row) for path, row in records if row['status'] == 'completed']
    observations = [read(path) for path in (args.out_dir / 'observations').glob('*/summary.json')]
    groups, instances = [], []
    for split in ('train', 'test'):
        for condition in ('oracle_pose', *VARIANTS):
            rows = [row for _, row in good if row['split'] == split and row['condition'] == condition]
            object_ids = sorted({row['object_id'] for row in rows})
            for obj in object_ids:
                subset = [row for row in rows if row['object_id'] == obj]
                instances.append({'split': split, 'condition': condition, 'object_id': obj, 'completed': len(subset),
                                  'task_success': sum(r['native_full_task_success'] for r in subset),
                                  'native_part_grasp': sum(r['boundary']['native_part_grasp'] for r in subset)})
            groups.append({'split': split, 'condition': condition, 'completed': len(rows), 'instances': len(object_ids),
                           'task_success': sum(r['native_full_task_success'] for r in rows),
                           'native_part_grasp': sum(r['boundary']['native_part_grasp'] for r in rows),
                           'instance_balanced_task_rate': float(np.mean([
                               np.mean([r['native_full_task_success'] for r in rows if r['object_id'] == obj])
                               for obj in object_ids])) if object_ids else None})
    paired = []
    for index in plan['evaluation_case_indices']:
        case = plan['cases'][index]
        row = {'case_index': index, 'split': case['split'], 'object_id': case['object_id'], 'demo': case['demo']}
        for condition in ('oracle_pose', *VARIANTS):
            matches = [r for _, r in good if r['case_index'] == index and r['condition'] == condition]
            row[condition + '_task'] = matches[0]['native_full_task_success'] if matches else None
            row[condition + '_grasp'] = matches[0]['boundary']['native_part_grasp'] if matches else None
        paired.append(row)
    complete = training_complete and len(good) == len(plan['trials']) and len(records) == len(good)
    planned_indices = {(trial['case_index'], trial['condition']): i for i, trial in enumerate(plan['trials'])}
    observed_indices = {planned_indices[(row['case_index'], row['condition'])] for _, row in records}
    summary = {'status': 'completed' if complete else 'blocked', 'groups': groups, 'per_instance': instances,
               'finished_rollouts': len(records), 'planned_rollouts': len(plan['trials']),
               'observations': len(observations), 'planned_observations': len(plan['cases']),
               'matched_training_audit': matched, 'training': training, 'limits': plan['limits'],
               'errors_or_blocks': [row for _, row in records if row['status'] != 'completed'],
               'missing_trial_indices': sorted(set(range(len(plan['trials']))) - observed_indices)}
    dump(args.out_dir / 'summary.json', summary); dump(args.out_dir / 'status.json', summary)
    write_csv(args.out_dir / 'paired_execution_outcomes.csv', paired)
    write_csv(args.out_dir / 'per_instance_outcomes.csv', instances)
    lines = ['# Matched point-to-pose geometry ablation', '', f'**Status: {summary["status"]}.**', '',
             plan['protocol'], '', f'{len(good)}/{len(plan["trials"])} simulations completed. '
             'Runtime errors, missing and blocked jobs are not physical task failures.', '',
             '## Offline pose prediction', '', '| Features | Seed | Test sources | Position error | Rotation error |',
             '| --- | ---: | ---: | ---: | ---: |']
    for row in training:
        if row['status'] == 'completed':
            metrics = row['test']
            lines.append(f'| {row["variant"]} | {row["seed"]} | {metrics["samples"]} | '
                         f'{metrics["position_mean_mm"]:.2f} mm | {metrics["rotation_mean_deg"]:.2f} deg |')
    lines += ['', '## Execution with the same frozen actor', '',
              '| Split | Features / pose | Trials | Mug instances | First-skill part grasp | Full task after recorded continuation |',
              '| --- | --- | ---: | ---: | ---: | ---: |']
    for row in groups:
        lines.append(f'| {row["split"]} | {row["condition"]} | {row["completed"]} | {row["instances"]} | '
                     f'{row["native_part_grasp"]} | {row["task_success"]} |')
    lines += ['', '## Interpretation limits', ''] + ['- ' + value for value in plan['limits']]
    lines += ['', '[Paired outcomes](paired_execution_outcomes.csv) · [Per-instance outcomes](per_instance_outcomes.csv)',
              '[Summary](summary.json) · [Frozen plan](plan.json) · [Job IDs](submissions.json)', '', '## Videos', '']
    for path, row in good:
        lines.append(f'- {row["split"]} / {row["demo"]} / {row["condition"]}: '
                     f'[video]({path.parent.relative_to(args.out_dir)}/execution.gif)')
    if any((args.out_dir / 'models').glob('*/*.history.csv')):
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        fig, axes = plt.subplots(1, 2, figsize=(11, 4))
        for variant in VARIANTS:
            path, _ = model_paths(args.out_dir, variant, plan['execution_head_seed'])
            history_path = path.with_suffix('.history.csv')
            if not history_path.exists():
                continue
            with history_path.open() as handle:
                history = list(csv.DictReader(handle))
            for ax, metric in zip(axes, ('position_mean_mm', 'rotation_mean_deg')):
                ax.plot([int(r['update']) for r in history], [float(r[metric]) for r in history], label=variant)
        axes[0].set(xlabel='Updates', ylabel='Development position error (mm)')
        axes[1].set(xlabel='Updates', ylabel='Development rotation error (deg)'); axes[1].legend(fontsize=7)
        fig.tight_layout(); fig.savefig(args.out_dir / 'matched_training_curves.png', dpi=160); plt.close(fig)
        lines += ['', '![Matched learning curves](matched_training_curves.png)']
    (args.out_dir / 'README.md').write_text('\n'.join(lines) + '\n')


def submit(args, plan):
    jobs = {}
    stages = [('collect', None, len(plan['new_collection_indices'])),
              ('train', 'collect', len(plan['training_trials'])),
              ('evaluate', 'train', len(plan['trials'])), ('report', 'evaluate', None)]
    for mode, dependency, count in stages:
        command = ['sbatch', '--parsable', f'--export=ALL,MODE={mode},GEOMETRY_STUDY={args.out_dir}',
                   f'--output={args.out_dir}/{mode}_%A_%a.out', f'--error={args.out_dir}/{mode}_%A_%a.err']
        if dependency:
            command.append('--dependency=afterany:' + jobs[dependency])
        if count:
            command.append(f'--array=0-{count - 1}%4')
        command.append(str(ROOT / 'part2action/slurm/pose_geometry_ablation.sbatch'))
        result = subprocess.run(command, check=True, capture_output=True, text=True)
        job = result.stdout.strip().split(';')[0]
        if not job.isdigit():
            raise RuntimeError('Unexpected Slurm response: ' + result.stdout)
        jobs[mode] = job
        dump(args.out_dir / 'submissions.json', jobs)
    dump(args.out_dir / 'status.json', {'status': 'queued', 'jobs': jobs})
    placeholder(args.out_dir, plan, 'queued')
    print(json.dumps(jobs, indent=2))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mode', choices=('prepare', 'submit', 'collect', 'train', 'evaluate', 'report'), required=True)
    parser.add_argument('--out-dir', type=Path, required=True)
    parser.add_argument('--index', type=int)
    args = parser.parse_args()
    if args.mode == 'prepare':
        prepare(args); return
    plan = read(args.out_dir / 'plan.json')
    for path, expected in plan['source_sha256'].items():
        if sha(path) != expected:
            raise RuntimeError('Frozen source changed: ' + path)
    if sha(args.out_dir / 'frozen_actor.pt') != plan['actor_sha256']:
        raise RuntimeError('Frozen actor changed')
    if args.mode == 'collect':
        args.index = plan['new_collection_indices'][args.index]
    if args.mode in ('collect', 'evaluate'):
        index = args.index if args.mode == 'collect' else plan['trials'][args.index]['case_index']
        case = plan['cases'][index]
        if sha(case['case_file']) != case['case_sha256']:
            raise RuntimeError('Case source changed')
    {'submit': submit, 'collect': collect, 'train': train, 'evaluate': evaluate, 'report': report}[args.mode](args, plan)


if __name__ == '__main__':
    main()
