"""Background point-to-pose pilot with a frozen learned low-level actor.

Slurm stages: collect actual initial geometry -> train supervised pose heads ->
execute frozen actor with inferred poses -> report, including upstream failures.
"""
from __future__ import annotations

import argparse
import copy
import csv
import hashlib
import json
from pathlib import Path
import random
import shutil
import subprocess
import time

import numpy as np
from scipy.spatial.transform import Rotation

from diagnostics.pose_guided_approach import approach_window, pose_error
from models.interaction_pose_head import InteractionPoseHead, pose_features, rotation6d
from models.pose_guided_actor import PoseGuidedActor
from run_pose_guided_approach import ROOT, contacts, dump, render_frame, sha

PARENT = Path('/p/part2action/results/diagnostics/learned_pose_actor_20261105_01')
BASE = Path('/p/part2action/results/diagnostics/full_trajectory_baselines_20261102/full')
CONDITIONS = ('oracle_pose', 'predicted_pose', 'shifted_point', 'mean_offset_pose')


def prepare(args):
    import h5py
    parent = json.loads((PARENT / 'plan.json').read_text())
    prior = json.loads((PARENT / 'summary.json').read_text())
    if prior['status'] != 'completed' or prior['runtime_errors']:
        raise ValueError('Parent actor study is not complete')
    args.out_dir.mkdir(parents=True, exist_ok=False)
    (args.out_dir / 'cases').mkdir()
    cases = copy.deepcopy(parent['cases'])
    for case in cases: case['origin'] = 'parent fixed split/source'
    training_ids = set(parent['instance_split']['train'])
    base_plan = json.loads((BASE / 'plan.json').read_text())
    eligible = set(json.loads((BASE / 'summary.json').read_text())['eligible_case_indices'])
    meta = json.loads((args.data_root / 'episodes_meta_train.json').read_text())
    lookup = {str(e['ep_id']): e for rows in meta['mug']['train'].values() for e in rows}
    rng = random.Random(20261105)
    seen = {c['demo'] for c in cases}
    excluded = []
    with h5py.File(args.data_root / 'demos/mug.hdf5') as h:
        for instance in sorted(training_ids):
            candidates = [(i, c) for i, c in enumerate(base_plan['cases']) if i in eligible
                          and c['object'] == 'mug' and c['task_type'] == '3'
                          and c['object_id'] == instance and c['demo'] not in seen and c['actions'] <= 200]
            rng.shuffle(candidates)
            for index, source in candidates:
                if sum(c['object_id'] == instance and c['split'] == 'train' for c in cases) >= 12: break
                try:
                    d = h['data'][source['demo']]
                    actions = d['actions'][:]
                    instructions = [v.decode() if isinstance(v, bytes) else str(v) for v in d['skill_instructions'][:]]
                    window = approach_window(actions, instructions)
                    if window['close'] < 10 or window['end'] > 160: raise ValueError('Outside fixed event budget')
                    reference = (BASE / 'cases' / f'{index:05d}' / 'repeat_0').resolve()
                    with np.load(reference / 'trajectories.npz') as z:
                        if not np.array_equal(actions, z['actions']): raise ValueError('Command identity mismatch')
                        goal = z['before_tcp'][window['close']].copy()
                        case_path = args.out_dir / 'cases' / f'extra_{len(cases):03d}.npz'
                        np.savez_compressed(case_path, source_actions=actions, before_tcp=z['before_tcp'],
                            reference_tcp=z['replay_tcp'], reference_object=z['object_xyz'], goal=goal)
                    episode = lookup[source['episode_id']]
                    cases.append({**source, 'split': 'train', 'source_index': index, 'episode': episode,
                        'part': episode['chain_params'][0]['params'].get('part_grasp', ''), 'window': window,
                        'reference': str(reference), 'case_file': str(case_path), 'case_sha256': sha(case_path),
                        'goal_xyzw_xyz': goal.tolist(), 'origin': 'extra source from original training instances'})
                    seen.add(source['demo'])
                except (KeyError, ValueError, OSError) as error:
                    excluded.append({'demo': source['demo'], 'reason': str(error)})
    actor_path = PARENT / 'with_pose.pt'
    expected = json.loads((PARENT / 'training_summary.json').read_text())['with_pose']['checkpoint_sha256']
    if sha(actor_path) != expected: raise ValueError('Frozen actor changed')
    shutil.copyfile(actor_path, args.out_dir / 'frozen_actor.pt')
    evaluations = parent['evaluation_case_indices']
    files = [Path(__file__), ROOT / 'part2action/models/interaction_pose_head.py',
        ROOT / 'part2action/models/pose_guided_actor.py', ROOT / 'part2action/scripts/run_pose_guided_approach.py',
        ROOT / 'part2action/diagnostics/pose_guided_approach.py', ROOT / 'part2action/scripts/generate_logged_references.py',
        ROOT / 'part2action/scripts/run_interaction_tolerance_pilot.py', ROOT / 'part2action/diagnostics/execution_trace.py',
        ROOT / 'part2action/diagnostics/evaluation_scenarios.py', ROOT / 'part2action/slurm/point_to_pose.sbatch',
        ROOT / 'PartInstruct/PartInstruct/PartGym/config/config_oracle.yaml',
        ROOT / 'PartInstruct/PartInstruct/PartGym/env/bullet_env.py',
        ROOT / 'PartInstruct/PartInstruct/PartGym/env/backend/planner/panda_arm.py',
        ROOT / 'PartInstruct/PartInstruct/PartGym/env/backend/planner/bullet_planner.py',
        ROOT / 'PartInstruct/PartInstruct/PartGym/env/backend/bullet_sim.py']
    plan = {'study': 'annotated_surface_point_to_interaction_pose', 'parent': str(PARENT),
        'data_root': str(args.data_root), 'cases': cases, 'excluded': excluded,
        'instance_split': parent['instance_split'], 'seeds': [42, 43, 44], 'execution_head_seed': 42,
        'actor_sha256': expected, 'hidden': 64, 'max_offset_m': .1, 'updates': 3000,
        'trials': [{'case_index': i, 'condition': condition} for i in evaluations for condition in CONDITIONS],
        'source_sha256': {str(p): sha(p) for p in files},
        'limits': ['Annotated target-part geometry and an oracle selected surface point are diagnostic inputs.',
            'The surface point is nearest the successful reference TCP goal; it is not measured finger contact.',
            'No deployed localization, RGB encoder or evaluator is trained.',
            'The learned low-level actor is frozen, with the existing privileged event clock.',
            'Pose head predicts TCP offset and orientation; the frozen actor predicts opening.',
            'Same four pilot evaluation instances as the previous study; not a new untouched final benchmark.',
            'Additional training demos remain within the original six training instances.',
            'Three pose-head seeds offline; fixed seed 42 for execution, not selected by test outcomes.'],
        'protocol': 'Observe actual scene after original action 0; infer one pose from point/local part geometry; '
                    'use frozen neural actor through first skill, then original continuation. '
                    'Compare oracle pose, learned pose, +5 cm point intervention, and training-mean offset/orientation baseline.',
        'no_auto_expansion': True}
    dump(args.out_dir / 'plan.json', plan)
    snapshots = args.out_dir / 'source_snapshot';snapshots.mkdir()
    for i, p in enumerate(files): (snapshots / (f'{i:02d}_' + p.name)).write_bytes(p.read_bytes())
    dump(args.out_dir / 'status.json', {'status': 'prepared', 'sources': len(cases), 'evaluations': len(plan['trials'])})
    print(json.dumps({'sources': len(cases), 'split_counts': {s: sum(c['split'] == s for c in cases) for s in ['train','development','test']}, 'evaluations': len(plan['trials'])}, indent=2))


def collect(args, plan):
    from generate_logged_references import make_env
    from diagnostics.execution_trace import physical_state
    case = plan['cases'][args.index]
    out = args.out_dir / 'observations' / f'{args.index:03d}'
    out.mkdir(parents=True, exist_ok=False)
    env = None
    try:
        with np.load(case['case_file']) as z:
            action = z['source_actions'][0].copy()
            expected = z['before_tcp'][1].copy()
            reference_object = z['reference_object'][0].copy()
            goal = z['goal'].copy()
        env = make_env(Path(plan['data_root']), case, 42, native_task_context=True)
        env.step(action)
        state = physical_state(env)
        error = pose_error(state['tcp_xyzw_xyz'], expected)
        if error['position_mm'] > 1 or error['rotation_deg'] > 1 or np.linalg.norm(np.asarray(state['object_xyz']) - reference_object) > .001:
            raise ValueError('Actual starting scene does not reproduce reference')
        sim_time = env.world.sim_time
        env.parser.update_part_pcds()
        part = np.asarray(env.parser.part_pcds[case['part'] or env.parser.obj_name])[:, :3]
        obj = np.asarray(env.parser.part_pcds[env.parser.obj_name])[:, :3]
        part = part[np.isfinite(part).all(1)];obj = obj[np.isfinite(obj).all(1)]
        point = part[np.linalg.norm(part - goal[4:], axis=1).argmin()]
        distance = float(np.linalg.norm(goal[4:] - point))
        if distance > plan['max_offset_m']: raise ValueError('Reference offset exceeds fixed 10 cm bound')
        features = pose_features(point, part, obj, state['tcp_xyzw_xyz'], state['finger_m'], case['part'])
        if env.world.sim_time != sim_time: raise RuntimeError('Geometry observation advanced physics')
        np.savez_compressed(out / 'inputs.npz', features=features, point=point, part_cloud=part,
            object_cloud=obj, tcp=np.asarray(state['tcp_xyzw_xyz']), opening=state['finger_m'], goal=goal)
        dump(out / 'summary.json', {'status': 'completed', 'case_index': args.index, 'split': case['split'],
            'surface_to_tcp_m': distance, 'prefix_error': error, 'input_sha256': sha(out / 'inputs.npz'),
            'label_source': 'Successful replay measured preclosure pose',
            'point_source': 'Current annotated-part surface nearest that reference pose; privileged proxy'})
    except BaseException as error:
        dump(out / 'summary.json', {'status': 'runtime_error', 'case_index': args.index, 'error': repr(error)})
        raise
    finally:
        if env is not None: env.close()


def head_loss(pred, position, matrix, target6):
    from torch.nn import functional as F
    return (F.smooth_l1_loss(pred['position'] / .05, position / .05, beta=.1)
            + .5 * F.mse_loss(pred['rotation6d'], target6)
            + .1 * F.mse_loss(pred['rotation'], matrix))


def head_metrics(model, x, point, position, matrix, target6):
    import torch
    with torch.no_grad():
        p = model(x, point)
        distance = (p['position'] - position).norm(dim=-1) * 1000
        rotation = Rotation.from_matrix(p['rotation'].numpy())
        target = Rotation.from_matrix(matrix.numpy())
        angle = np.rad2deg((target.inv() * rotation).magnitude())
        return {'samples': len(x), 'loss': float(head_loss(p, position, matrix, target6)),
                'position_mean_mm': float(distance.mean()), 'position_max_mm': float(distance.max()),
                'rotation_mean_deg': float(angle.mean()), 'rotation_max_deg': float(angle.max())}


def train(args, plan):
    import torch
    torch.set_num_threads(2)
    records = [json.loads(p.read_text()) for p in sorted((args.out_dir / 'observations').glob('*/summary.json'))]
    if len(records) != len(plan['cases']) or any(r['status'] != 'completed' for r in records):
        dump(args.out_dir / 'training_summary.json', {'status': 'blocked', 'reason': 'Collection incomplete or invalid; no pose model trained',
            'observed': len(records), 'planned': len(plan['cases']), 'errors': [r for r in records if r['status'] != 'completed']})
        return
    features, points, poses = [], [], []
    for i in range(len(plan['cases'])):
        directory = args.out_dir / 'observations' / f'{i:03d}'
        summary = json.loads((directory / 'summary.json').read_text())
        if sha(directory / 'inputs.npz') != summary['input_sha256']: raise ValueError('Observation changed')
        with np.load(directory / 'inputs.npz') as z:
            features.append(z['features']);points.append(z['point']);poses.append(z['goal'])
    x = torch.tensor(np.asarray(features), dtype=torch.float32)
    point = torch.tensor(np.asarray(points), dtype=torch.float32)
    poses = np.asarray(poses)
    position = torch.tensor(poses[:, 4:], dtype=torch.float32)
    matrices = Rotation.from_quat(poses[:, :4]).as_matrix()
    matrix = torch.tensor(matrices, dtype=torch.float32)
    target6 = torch.tensor(rotation6d(matrices), dtype=torch.float32)
    indices = {s: torch.tensor([i for i,c in enumerate(plan['cases']) if c['split'] == s]) for s in ['train','development','test']}
    values = [x, point, position, matrix, target6]
    history, results = [], {}
    for seed in plan['seeds']:
        torch.manual_seed(seed)
        model = InteractionPoseHead(plan['hidden'], plan['max_offset_m'])
        optimizer = torch.optim.AdamW(model.parameters(), lr=.001, weight_decay=.0001)
        schedule = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, plan['updates'], eta_min=1e-5)
        rng = torch.Generator().manual_seed(seed)
        best = float('inf')
        for update in range(plan['updates'] + 1):
            if update % 100 == 0:
                model.eval()
                dev = head_metrics(model, *[v[indices['development']] for v in values])
                history.append({'seed': seed, 'update': update, **dev})
                if dev['loss'] < best:
                    best = dev['loss']
                    torch.save({'state_dict': model.state_dict(), 'hidden': plan['hidden'],
                        'max_offset_m': plan['max_offset_m'], 'seed': seed, 'update': update,
                        'development_metrics': dev}, args.out_dir / f'pose_head_seed{seed}.pt')
                dump(args.out_dir / 'training_progress.json', {'seed': seed, 'update': update, 'updates': plan['updates']})
            if update == plan['updates']: break
            model.train()
            batch = indices['train'][torch.randint(len(indices['train']), (64,), generator=rng)]
            optimizer.zero_grad(set_to_none=True)
            pred = model(x[batch], point[batch])
            loss = head_loss(pred, position[batch], matrix[batch], target6[batch])
            loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(), 5.)
            optimizer.step();schedule.step()
        checkpoint = torch.load(args.out_dir / f'pose_head_seed{seed}.pt', map_location='cpu', weights_only=False)
        model.load_state_dict(checkpoint['state_dict']);model.eval()
        results[str(seed)] = {'selected_update': checkpoint['update'],
            'checkpoint_sha256': sha(args.out_dir / f'pose_head_seed{seed}.pt'),
            **{s: head_metrics(model, *[v[indices[s]] for v in values]) for s in indices}}
    train_ids = indices['train'].numpy()
    baseline = {'offset_m': (poses[train_ids, 4:] - np.asarray(points)[train_ids]).mean(0).tolist(),
                'rotation_xyzw': Rotation.from_quat(poses[train_ids, :4]).mean().as_quat().tolist()}
    dump(args.out_dir / 'training_summary.json', {'status': 'completed', 'seeds': results,
        'mean_offset_baseline': baseline, 'execution_seed': plan['execution_head_seed'], 'limits': plan['limits']})
    with (args.out_dir / 'training_history.csv').open('w') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(history[0]));writer.writeheader();writer.writerows(history)


def evaluate(args, plan):
    import torch
    from diagnostics.execution_trace import physical_state
    from generate_logged_references import make_env, native_grasp
    import imageio.v2 as imageio
    trial = plan['trials'][args.index];case = plan['cases'][trial['case_index']]
    out = args.out_dir / 'rollouts' / f'{args.index:03d}_{case["demo"]}_{trial["condition"]}'
    out.mkdir(parents=True, exist_ok=False)
    training_path = args.out_dir / 'training_summary.json'
    if not training_path.exists() or json.loads(training_path.read_text())['status'] != 'completed':
        dump(out / 'summary.json', {'status': 'blocked', **trial, 'reason': 'Upstream pose training did not complete'})
        return
    training = json.loads(training_path.read_text())
    actor_checkpoint = torch.load(args.out_dir / 'frozen_actor.pt', map_location='cpu', weights_only=False)
    actor = PoseGuidedActor(actor_checkpoint['pose_enabled'], actor_checkpoint['hidden'])
    actor.load_state_dict(actor_checkpoint['state_dict']);actor.eval()
    seed = plan['execution_head_seed']
    head_path = args.out_dir / f'pose_head_seed{seed}.pt'
    if sha(head_path) != training['seeds'][str(seed)]['checkpoint_sha256']: raise ValueError('Pose head changed')
    checkpoint = torch.load(head_path, map_location='cpu', weights_only=False)
    head = InteractionPoseHead(checkpoint['hidden'], checkpoint['max_offset_m'])
    head.load_state_dict(checkpoint['state_dict']);head.eval()
    with np.load(case['case_file']) as z: actions, oracle = z['source_actions'].copy(), z['goal'].copy()
    with np.load(args.out_dir / 'observations' / f'{trial["case_index"]:03d}' / 'inputs.npz') as z:
        context = {k: z[k].copy() for k in z.files}
    condition = trial['condition'];point = context['point'].copy()
    if condition == 'shifted_point': point[0] += .05
    features = pose_features(point, context['part_cloud'], context['object_cloud'], context['tcp'],
                             float(context['opening']), case['part'])
    if condition == 'oracle_pose': goal = oracle.copy()
    elif condition == 'mean_offset_pose':
        base = training['mean_offset_baseline'];goal = np.r_[base['rotation_xyzw'], point + base['offset_m']]
    else: goal = head.predict(features, point)
    dump(out / 'inferred_pose.json', {'point': point.tolist(), 'goal_xyzw_xyz': goal.tolist(),
                                    'oracle_xyzw_xyz': oracle.tolist(), 'error': pose_error(goal, oracle)})
    env = None
    try:
        env = make_env(Path(plan['data_root']), case, 42, native_task_context=True)
        config = env.config
        view = env.world.p.computeViewMatrixFromYawPitchRoll(cameraTargetPosition=list(config.cam_static_target),
            distance=config.cam_static_dist, yaw=config.cam_static_yaw, pitch=config.cam_static_pitch, roll=0, upAxisIndex=config.up_axis_index)
        projection = env.world.p.computeProjectionMatrixFOV(fov=60, aspect=1, nearVal=config.cam_near, farVal=config.cam_far)
        rows, frames, executed, states = [], [], [], []
        boundary = None
        for i, source in enumerate(actions):
            state = physical_state(env)
            if i == 1:
                np.testing.assert_allclose(state['tcp_xyzw_xyz'], context['tcp'], atol=1e-6, rtol=0)
                dump(out / 'decision_state.json', state)
            neural = 1 <= i < case['window']['end']
            action = actor.predict(state['tcp_xyzw_xyz'], state['finger_m'], goal, i,
                                   case['window']['close'], case['window']['end']) if neural else source.copy()
            _, _, done, _ = env.step(action.copy())
            after = physical_state(env);states.append(after);executed.append(action)
            rows.append({'index': i, 'neural_action': neural, 'native_task_success': bool(done),
                         'oracle_pose_error_mm': pose_error(after['tcp_xyzw_xyz'], oracle)['position_mm']})
            if i == case['window']['end'] - 1:
                boundary = {'native_part_grasp': native_grasp(env), 'contacts': contacts(env),
                            'oracle_pose_error': pose_error(after['tcp_xyzw_xyz'], oracle)}
            if i >= 1 and i % 2 == 0:
                frames.append(render_frame(env, view, projection,
                    f'POINT -> POSE | {condition} | {case["demo"]} | {case["split"]}\nStep {i} | task success {bool(done)}'))
        executed = np.asarray(executed)
        assert np.array_equal(executed[0], actions[0]) and np.array_equal(executed[case['window']['end']:], actions[case['window']['end']:])
        np.savez_compressed(out / 'trajectories.npz', applied_actions=executed, source_actions=actions,
            tcp=np.asarray([s['tcp_xyzw_xyz'] for s in states]), object_xyz=np.asarray([s['object_xyz'] for s in states]),
            point=point, inferred_goal=goal, oracle_goal=oracle)
        imageio.mimsave(out / 'execution.gif', frames, duration=.1, loop=0)
        with (out / 'per_step.csv').open('w') as handle:
            writer = csv.DictWriter(handle, fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
        dump(out / 'summary.json', {'status': 'completed', **trial, 'split': case['split'],
            'object_id': case['object_id'], 'demo': case['demo'], 'pose_prediction_error': pose_error(goal, oracle),
            'native_full_task_success': any(r['native_task_success'] for r in rows), 'boundary': boundary,
            'actor_sha256': plan['actor_sha256'], 'pose_head_sha256': sha(head_path)})
    except BaseException as error:
        dump(out / 'summary.json', {'status': 'runtime_error', **trial, 'error': repr(error)})
        raise
    finally:
        if env is not None: env.close()


def report(args, plan):
    observations = [json.loads(p.read_text()) for p in (args.out_dir / 'observations').glob('*/summary.json')]
    training_path = args.out_dir / 'training_summary.json'
    training = json.loads(training_path.read_text()) if training_path.exists() else {'status': 'missing'}
    paths = sorted((args.out_dir / 'rollouts').glob('*/summary.json'))
    records = [(p, json.loads(p.read_text())) for p in paths]
    good = [(p, v) for p, v in records if v['status'] == 'completed']
    complete = len(records) == len(plan['trials']) and len(good) == len(records) and training['status'] == 'completed'
    groups = []
    for split in ['train', 'test']:
        for condition in CONDITIONS:
            rows = [v for _,v in good if v['split'] == split and v['condition'] == condition]
            groups.append({'split': split, 'condition': condition, 'completed': len(rows),
                           'task_success': sum(v['native_full_task_success'] for v in rows),
                           'native_part_grasp': sum(v['boundary']['native_part_grasp'] for v in rows)})
    summary = {'status': 'completed' if complete else 'blocked', 'observations': len(observations),
        'planned_observations': len(plan['cases']), 'finished_rollouts': len(records),
        'planned_rollouts': len(plan['trials']), 'successful_rollout_executions': len(good),
        'training_status': training['status'], 'groups': groups,
        'collection_errors': [r for r in observations if r['status'] != 'completed'],
        'rollout_errors_or_blocks': [v for _,v in records if v['status'] != 'completed'],
        'training': training, 'limits': plan['limits']}
    dump(args.out_dir / 'summary.json', summary);dump(args.out_dir / 'status.json', summary)
    lines = ['# Point-to-gripper-pose pilot', '', f'**Status: {summary["status"]}.**', '', plan['protocol'], '',
        f'Geometry sources {len(observations)}/{len(plan["cases"])}; rollout records {len(records)}/{len(plan["trials"])}; training {training["status"]}.', '',
        '## Pose prediction (whole pilot instances held out)', '']
    if training['status'] == 'completed':
        lines += ['| Head seed | Mean position error | Mean orientation error |', '| --- | ---: | ---: |']
        for seed, value in training['seeds'].items():
            test = value['test'];lines.append(f'| {seed} | {test["position_mean_mm"]:.2f} mm | {test["rotation_mean_deg"]:.2f} deg |')
    else: lines.append('Training did not complete; inspect summary.json and Slurm logs. Skipped executions are not physical failures.')
    lines += ['', '## Execution with the same frozen neural actor', '',
        '| Split | Supplied pose | Completed | Original task succeeds | Native part grasp before continuation |',
        '| --- | --- | ---: | ---: | ---: |']
    for row in groups:lines.append(f'| {row["split"]} | {row["condition"]} | {row["completed"]} | {row["task_success"]} | {row["native_part_grasp"]} |')
    lines += ['', '## Scope', ''] + ['- ' + v for v in plan['limits']]
    lines += ['', '[Summary](summary.json) · [Frozen plan](plan.json) · [Job IDs](submissions.json)', '', '## Executions', '']
    for path, value in good:
        relative = path.parent.relative_to(args.out_dir)
        lines.append(f'- {value["split"]} / {value["demo"]} / {value["condition"]}: [video]({relative}/execution.gif), [measurements]({relative}/summary.json)')
    if (args.out_dir / 'training_history.csv').exists():
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        with (args.out_dir / 'training_history.csv').open() as handle: history = list(csv.DictReader(handle))
        fig, axes = plt.subplots(1, 2, figsize=(10, 4))
        for seed in plan['seeds']:
            rows = [r for r in history if int(r['seed']) == seed]
            for ax, metric in zip(axes, ['position_mean_mm', 'rotation_mean_deg']):
                ax.plot([int(r['update']) for r in rows], [float(r[metric]) for r in rows], label=f'seed {seed}')
        axes[0].set(xlabel='Updates', ylabel='Development position error (mm)')
        axes[1].set(xlabel='Updates', ylabel='Development rotation error (deg)');axes[1].legend()
        fig.tight_layout();fig.savefig(args.out_dir / 'pose_training_curves.png', dpi=160);plt.close(fig)
        lines += ['', '![Pose learning curves](pose_training_curves.png)', '']
    (args.out_dir / 'README.md').write_text('\n'.join(lines))


def submit(args, plan):
    launcher = ROOT / 'part2action/slurm/point_to_pose.sbatch'
    jobs = {}
    for mode, dependency, array in [('collect', None, f'0-{len(plan["cases"])-1}%4'),
                                   ('train', 'collect', None), ('evaluate', 'train', f'0-{len(plan["trials"])-1}%4'),
                                   ('report', 'evaluate', None)]:
        command = ['sbatch', '--parsable', f'--export=ALL,MODE={mode},POSE_STUDY={args.out_dir}',
                   f'--output={args.out_dir}/{mode}_%A_%a.out', f'--error={args.out_dir}/{mode}_%A_%a.err']
        if dependency:command.append('--dependency=afterany:' + jobs[dependency])
        if array:command.append('--array=' + array)
        command.append(str(launcher))
        result = subprocess.run(command, check=True, capture_output=True, text=True)
        job = result.stdout.strip().split(';')[0]
        if not job.isdigit():raise RuntimeError('Unexpected submission: ' + result.stdout)
        jobs[mode] = job
        dump(args.out_dir / 'submissions.json', jobs)
    dump(args.out_dir / 'status.json', {'status': 'queued', 'jobs': jobs,
        'sources': len(plan['cases']), 'evaluations': len(plan['trials']), 'automatic_report': 'README.md and summary.json'})
    (args.out_dir / 'README.md').write_text('# Point-to-gripper-pose pilot\n\nStatus: queued.\n\n'
        'Stages: actual geometry collection -> supervised pose training -> frozen-actor execution -> automatic report.\n\n'
        '[Job IDs](submissions.json) · [Status](status.json) · [Plan](plan.json)\n\n'
        'The final report, learning curves and execution videos will be written here automatically. '
        'If upstream validation fails, the report records the blocking reason.\n')
    print(json.dumps(jobs, indent=2))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mode', choices=['prepare','submit','collect','train','evaluate','report'], required=True)
    parser.add_argument('--out-dir', type=Path, required=True)
    parser.add_argument('--data-root', type=Path, default=Path('/p/part2action/data/PartInstruct'))
    parser.add_argument('--index', type=int)
    args = parser.parse_args()
    if args.mode == 'prepare':prepare(args);return
    plan = json.loads((args.out_dir / 'plan.json').read_text())
    for name, expected in plan['source_sha256'].items():
        if sha(name) != expected:raise RuntimeError('Source changed: ' + name)
    if sha(args.out_dir / 'frozen_actor.pt') != plan['actor_sha256']:raise RuntimeError('Frozen actor changed')
    if args.mode in ['collect','evaluate']:
        case_index = args.index if args.mode == 'collect' else plan['trials'][args.index]['case_index']
        case = plan['cases'][case_index]
        if sha(case['case_file']) != case['case_sha256']:raise RuntimeError('Source case changed')
    {'submit': submit, 'collect': collect, 'train': train, 'evaluate': evaluate, 'report': report}[args.mode](args, plan)


if __name__ == '__main__':main()
