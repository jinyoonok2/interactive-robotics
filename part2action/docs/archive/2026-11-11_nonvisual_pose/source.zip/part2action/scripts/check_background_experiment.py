"""Read progress of a queued point-to-pose study without importing ML packages."""
import argparse
import json
from pathlib import Path


def read(path):
    return json.loads(path.read_text()) if path.exists() else None


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('study', type=Path)
    args = parser.parse_args()
    root = args.study
    plan = read(root / 'plan.json')
    if plan is None: raise SystemExit('No experiment plan at ' + str(root))
    collection = [read(p) for p in root.glob('observations/*/summary.json')]
    executions = [read(p) for p in root.glob('rollouts/*/summary.json')]
    training = read(root / 'training_summary.json')
    progress = read(root / 'training_progress.json')
    result = read(root / 'summary.json')
    print('Study:', root.resolve())
    print('Geometry collection:', len(collection), '/', len(plan['cases']),
          '| errors:', sum(v['status'] != 'completed' for v in collection))
    print('Training:', training['status'] if training else 'pending or running')
    if plan.get('training_trials'):
        models = [read(root / 'models' / row['variant'] / f'seed{row["seed"]}.json')
                  for row in plan['training_trials']]
        print('Matched pose heads:', sum(v is not None and v['status'] == 'completed' for v in models),
              '/', len(models), '| blocked:', sum(v is not None and v['status'] != 'completed' for v in models))
    if progress: print('Latest training progress:', progress)
    print('Simulation records:', len(executions), '/', len(plan['trials']),
          '| errors/blocked:', sum(v['status'] != 'completed' for v in executions))
    if 'reused_rollout_count' in plan:
        print('Reused prior executions:', plan['reused_rollout_count'],
              '| additional executions planned:', len(plan['new_trial_indices']))
    print('Final report:', result['status'] if result else 'pending')
    jobs = read(root / 'submissions.json')
    if jobs:
        print('Slurm jobs:', jobs)
        print('Live scheduler check: squeue -j ' + ','.join(str(v) for v in jobs.values() if str(v).isdigit()))
    print('Report path:', root / 'README.md')
    if training and training['status'] == 'blocked': print('Blocking reason:', training.get('reason'))
    if result and result.get('groups'):
        for row in result['groups']:
            if row['split'] == 'test':print('Held-instance result:', row)


if __name__ == '__main__': main()
