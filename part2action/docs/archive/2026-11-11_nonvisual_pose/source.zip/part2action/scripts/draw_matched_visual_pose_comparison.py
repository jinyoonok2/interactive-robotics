"""Draw the intended matched visual-baseline versus visual-plus-pose comparison.

The pose extension is proposed, not an implemented or evaluated policy. This
figure supersedes no historical figure and changes no model or run configuration.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch
from PIL import Image

ROOT = Path(__file__).resolve().parents[2]
DEFAULT_OUT = ROOT / "part2action/docs/figures/2026-11-10_matched_visual_pose_comparison"
STEM = "visual_baseline_plus_pose"

MERMAID = """flowchart LR
  subgraph A["(a) Existing visual baseline"]
    direction TB
    A0["RGB history + scene point cloud<br/>Task + TCP pose + gripper opening"]
    A1["Existing encoders + part gate<br/>Temporal / skill / scene fusion"]
    A2["Shared policy context h_t"]
    A3["Transformer diffusion action head<br/>8 x 7 action chunk"]
    A4["Execute first command"]
    A0 --> A1 --> A2 --> A3 --> A4
    A4 -->|"New observations + state"| A0
  end
  subgraph B["(b) Proposed matched extension: not implemented or evaluated"]
    direction TB
    B0["SAME RGB history + scene point cloud<br/>SAME task + TCP pose + gripper opening"]
    B1["SAME encoders + part gate<br/>SAME temporal / skill / scene fusion"]
    B2["Shared policy context h_t"]
    P["NEW pose estimator<br/>Policy context + measured TCP<br/>Target gripper position + orientation"]
    E["NEW pose-context embedding"]
    F["Original context + predicted pose context"]
    B3["SAME Transformer diffusion action head<br/>8 x 7 action chunk"]
    B4["Execute first command"]
    B0 --> B1 --> B2
    B2 --> P --> E --> F
    B2 --> F --> B3 --> B4
    B4 -->|"New observations + state"| B0
  end
  classDef existing fill:#eaf2fc,stroke:#285da8,color:#19334e;
  classDef added fill:#e5f5f0,stroke:#18766d,color:#19334e;
  class A1,A2,A3,B1,B2,B3 existing;
  class P,E added;
%% Same observations, data, shared initialization, training budget and evaluation.
%% No small MLP action controller; the original diffusion head produces actions.
%% Normal inference receives no GT pose, GT part cloud, reference clock or replay tail.
%% Oracle-pose evaluation replaces the prediction in this same visual policy.
"""

CAPTION = r"""% Proposed design. Requires graphicx. Place the PDF beside this snippet
% or adjust the includegraphics path to match the report's figure directory.
\begin{figure*}[t]
  \centering
  \includegraphics[width=\textwidth]{visual_baseline_plus_pose.pdf}
  \caption{Intended matched architecture comparison (pose extension not yet
  implemented or evaluated). Both arms retain RGB history, scene point clouds,
  language, measured robot state, the existing observation encoders, part gate,
  skill hierarchy, and Transformer diffusion action-head architecture.
  The proposed extension predicts a target gripper position and orientation
  from the learned policy context and measured TCP pose. An embedding of the
  predicted relative pose conditions the original action head alongside the
  original policy context. No separate small action controller is used.
  Normal inference uses predicted pose and grounding; GT poses provide training
  supervision or a separately identified oracle diagnostic. Data, shared
  initialization, training budget, and evaluation must be matched.}
  \label{fig:matched-visual-pose-design}
\end{figure*}
"""


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def render(out, dpi):
    plt.rcParams.update({"font.family": "DejaVu Sans", "svg.fonttype": "none",
                         "pdf.fonttype": 42})
    fig, ax = plt.subplots(figsize=(18, 14.5), dpi=100)
    fig.subplots_adjust(left=0, right=1, bottom=0, top=1)
    ax.set(xlim=(0, 1800), ylim=(1450, 0)); ax.axis("off")
    navy, muted, blue, teal = "#19334e", "#53677a", "#285da8", "#18766d"
    border, old_bg, new_bg = "#b9c8d5", "#eaf2fc", "#e5f5f0"
    labels, contained = [], []

    def text(x, y, label, size=17, color=navy, bold=False, ha="center", rotation=0):
        item = ax.text(x, y, label, fontsize=size, color=color,
                       fontweight="bold" if bold else "normal", ha=ha, va="center",
                       rotation=rotation, linespacing=1.35, zorder=6)
        labels.append(item)
        return item

    def rect(x, y, w, h, fill="white", edge=border, zorder=3):
        ax.add_patch(FancyBboxPatch((x, y), w, h,
            boxstyle="round,pad=0,rounding_size=14", facecolor=fill,
            edgecolor=edge, linewidth=1.4, zorder=zorder))

    def box(x, y, w, h, title, detail="", fill="white", edge=border,
            title_size=19, detail_size=16):
        rect(x, y, w, h, fill, edge)
        item = text(x + w / 2, y + (29 if detail else h / 2), title,
                    title_size, bold=True)
        contained.append((item, (x, y, w, h)))
        if detail:
            item = text(x + w / 2, y + (h + 35) / 2, detail, detail_size, color=muted)
            contained.append((item, (x, y, w, h)))

    def arrow(points, color=muted):
        if len(points) > 2:
            ax.plot([p[0] for p in points[:-1]], [p[1] for p in points[:-1]],
                    color=color, lw=1.7, zorder=2)
        ax.add_patch(FancyArrowPatch(points[-2], points[-1], arrowstyle="-|>",
            color=color, lw=1.7, mutation_scale=18, shrinkA=0, shrinkB=0, zorder=2))

    text(40, 43, "Intended comparison: retain vision, add pose estimation", 27,
         bold=True, ha="left")
    text(40, 83, "Matched visual-policy design · pose extension not yet implemented or evaluated",
         17, color=muted, ha="left")
    rect(40, 125, 810, 1130, fill="#fbfcfe", edge="#d7e1e9", zorder=0)
    rect(905, 125, 855, 1130, fill="#fbfdfc", edge="#d7e1e9", zorder=0)
    text(445, 166, "(a) Original visual baseline", 24, blue, bold=True)
    text(1332, 166, "(b) Baseline + pose estimator", 24, teal, bold=True)
    text(445, 204, "Existing architecture", 17, color=muted)
    text(1332, 204, "Proposed extension of the same policy", 17, color=muted)

    for x in (140, 1005):
        box(x, 250, 610, 110, "Same observations + task + state",
            "RGB history + scene point cloud\nTask + measured TCP pose + gripper opening")
        box(x, 410, 610, 140, "Same encoders, grounding, and fusion",
            "DINOv2 / Flan-T5 + learned part gate\nScene encoder + temporal / skill context + state",
            fill=old_bg, edge=blue)
        arrow([(x + 305, 360), (x + 305, 410)])

    box(140, 620, 610, 85, "Policy context", "Existing fused features h_t",
        fill=old_bg, edge=blue)
    box(1005, 620, 330, 85, "Policy context", "Existing features h_t",
        fill=old_bg, edge=blue)
    arrow([(445, 550), (445, 620)])
    arrow([(1310, 550), (1310, 585), (1170, 585), (1170, 620)])

    box(1410, 605, 300, 115, "NEW: Pose estimator",
        "Context + TCP pose\nPosition + orientation",
        fill=new_bg, edge=teal, title_size=17, detail_size=14.5)
    box(1410, 785, 300, 85, "NEW: Pose context",
        "Embed relative pose",
        fill=new_bg, edge=teal, title_size=17, detail_size=14.5)
    box(1005, 785, 330, 85, "Action features",
        "h_t + pose context", title_size=19, detail_size=17)
    arrow([(1335, 662.5), (1410, 662.5)], teal)
    arrow([(1560, 720), (1560, 785)], teal)
    arrow([(1410, 827.5), (1335, 827.5)], teal)
    arrow([(1170, 705), (1170, 785)])

    for x in (140, 1005):
        box(x, 940, 610, 100, "Same Transformer diffusion action head",
            "8-step × 7-command action chunk", fill=old_bg, edge=blue,
            title_size=18)
        box(x, 1090, 610, 85, "Execute first command",
            "TCP position + orientation + gripper", fill="#eef6f3", edge="#46796a")
        arrow([(x + 305, 1040), (x + 305, 1090)])
        feedback_x = x - 50
        arrow([(x, 1132.5), (feedback_x, 1132.5), (feedback_x, 305), (x, 305)])
        text(feedback_x - 22, 735, "Refresh visual observations + robot state", 14.5,
             color=muted, rotation=90)
    arrow([(445, 705), (445, 940)])
    text(635, 821, "Original context", 16, color=muted)
    arrow([(1170, 870), (1170, 905), (1310, 905), (1310, 940)])
    text(445, 1217, "Original action generator retained", 17, blue, bold=True)
    text(1332, 1217, "Only the pose branch and its conditioning are added", 16, teal, bold=True)

    text(40, 1301, "Match: observations, data, shared initialization, update budget, seeds, action decoder, and evaluation.",
         17, bold=True, ha="left")
    text(40, 1349, "Normal inference: predicted pose and grounding. No GT part clouds, reference-event clock, or recorded continuation.",
         16, color=muted, ha="left")
    text(40, 1390, "GT pose is training supervision or a separate oracle diagnostic in this same visual policy. No small action controller is added.",
         16, color=muted, ha="left")

    fig.canvas.draw(); renderer = fig.canvas.get_renderer()
    errors = []
    for item in labels:
        b = item.get_window_extent(renderer)
        if not (fig.bbox.x0 <= b.x0 and b.x1 <= fig.bbox.x1
                and fig.bbox.y0 <= b.y0 and b.y1 <= fig.bbox.y1):
            errors.append("Clipped text: " + item.get_text())
    for item, (x, y, w, h) in contained:
        b = item.get_window_extent(renderer)
        a, z = ax.transData.transform((x + 7, y + 4)), ax.transData.transform((x + w - 7, y + h - 4))
        if not (a[0] <= b.x0 and b.x1 <= z[0] and z[1] <= b.y0 and b.y1 <= a[1]):
            errors.append("Text exceeds box: " + item.get_text())
    if errors:
        raise ValueError("\n".join(errors))
    for ext in ("png", "svg", "pdf"):
        fig.savefig(out / f"{STEM}.{ext}", dpi=dpi, facecolor="white")
    plt.close(fig)
    (out / f"{STEM}.mmd").write_text(MERMAID)
    (out / "report_figure.tex").write_text(CAPTION)
    with Image.open(out / f"{STEM}.png") as raster:
        dimensions = list(raster.size)
    return {"layout_checks": "passed", "png_dimensions": dimensions}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out-dir", type=Path, default=DEFAULT_OUT)
    parser.add_argument("--dpi", type=int, default=240)
    args = parser.parse_args(); out = args.out_dir.resolve()
    out.mkdir(parents=True, exist_ok=True)
    if list(out.iterdir()):
        raise FileExistsError("Use a fresh output directory to preserve prior figures")
    checks = render(out, args.dpi)
    manifest = {
        "status": "proposed_architecture_not_implemented_or_evaluated",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "generator": str(Path(__file__).resolve().relative_to(ROOT)),
        "generator_sha256": sha(__file__),
        "original_model_sha256": sha(ROOT / "part2action/models/part2action_model.py"),
        "files": {p.name: {"bytes": p.stat().st_size, "sha256": sha(p)} for p in sorted(out.iterdir())},
        **checks,
    }
    (out / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps({"output": str(out), **checks, "status": manifest["status"]}, indent=2))


if __name__ == "__main__":
    main()
