"""Part2Action: evaluate the existing geometry heads across training seeds.

Reuse the 125 seed-42/oracle executions. Only missing seed-43/44 executions
are submitted. No model training, new data collection, or other project work.
"""
from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path
import shutil
import subprocess

from run_pose_geometry_ablation import ROOT, VARIANTS, evaluate as execute_trial, model_paths, read, write_csv
from run_pose_guided_approach import dump, sha

PARENT = Path('/p/part2action/results/diagnostics/pose_geometry_ablation_20261107_01')


def trial_plan(plan, array_index):
    """Change the selected existing head seed, keeping actor/physics settings."""
    index = plan['new_trial_indices'][array_index]
    value = dict(plan)
    value['execution_head_seed'] = plan['trials'][index]['head_seed']
    return index, value


def placeholder(root, plan, state):
    (root / 'README.md').write_text(
        '# Part2Action geometry: training-seed replication\n\n'
        f'**Status: {state}.**\n\n'
        'Check whether the observed part-geometry grasp benefit holds across the three already trained head seeds. '
        'The learned low-level actor and simulator seed remain fixed.\n\n'
        f'Reuse {plan["reused_rollout_count"]} completed executions; run only '
        f'{len(plan["new_trial_indices"])} missing executions. No retraining or recollection.\n\n'
        '[Frozen plan](plan.json) · [Job IDs](submissions.json)\n\n'
        'The report will contain per-seed/per-instance results, paired wins/losses and video links. '
        'This remains an exploratory pilot on the same four mug instances, with supplied reference-derived points, '
        'privileged event timing and recorded continuation after the first skill.\n')


def prepare(args):
    parent = read(PARENT / 'plan.json')
    result = read(PARENT / 'summary.json')
    if result['status'] != 'completed' or result['finished_rollouts'] != 125:
        raise ValueError('The complete parent study is required')
    for path, expected in parent['source_sha256'].items():
        if sha(path) != expected:
            raise ValueError('Parent source changed: ' + path)
    trials = [{**trial, 'head_seed': None if trial['condition'] == 'oracle_pose' else 42}
              for trial in parent['trials']]
    for seed in (43, 44):
        trials.extend({'case_index': index, 'condition': variant, 'head_seed': seed}
                      for index in parent['evaluation_case_indices'] for variant in VARIANTS)
    args.out_dir.mkdir(parents=True, exist_ok=False)
    (args.out_dir / 'rollouts').mkdir()
    for name in ('observations', 'models'):
        (args.out_dir / name).symlink_to(PARENT / name, target_is_directory=True)
    shutil.copyfile(PARENT / 'frozen_actor.pt', args.out_dir / 'frozen_actor.pt')
    shutil.copyfile(PARENT / 'training_summary.json', args.out_dir / 'training_summary.json')
    reused = {}
    for directory in sorted((PARENT / 'rollouts').iterdir()):
        if not directory.is_dir():
            continue
        index = int(directory.name.split('_', 1)[0])
        record = read(directory / 'summary.json')
        expected = trials[index]
        if record['status'] != 'completed' or any(record[k] != expected[k] for k in ('case_index', 'condition')):
            raise ValueError('Invalid reusable execution')
        (args.out_dir / 'rollouts' / directory.name).symlink_to(directory, target_is_directory=True)
        reused[str(index)] = {'path': str(directory / 'summary.json'), 'sha256': sha(directory / 'summary.json')}
    if len(reused) != 125:
        raise ValueError('Expected exactly 125 reused executions')
    model_hashes = {}
    for variant in VARIANTS:
        for seed in parent['seeds']:
            checkpoint, summary = model_paths(PARENT, variant, seed)
            record = read(summary)
            if record['status'] != 'completed' or sha(checkpoint) != record['checkpoint_sha256']:
                raise ValueError('Invalid frozen head')
            model_hashes[str(checkpoint)] = record['checkpoint_sha256']
    files = [Path(__file__), ROOT / 'part2action/slurm/pose_geometry_seed_replication.sbatch']
    plan = {**parent, 'study': 'p2a_pose_geometry_training_seed_replication', 'parent': str(PARENT),
            'trials': trials, 'reused_rollout_count': 125, 'new_trial_indices': list(range(125, len(trials))),
            'reused_records': reused, 'model_sha256': model_hashes,
            'source_sha256': {**parent['source_sha256'], **{str(p): sha(p) for p in files}},
            'protocol': 'Same 25 starts (24 held-out mug demos plus calibration), four feature variants, '
                        'all three previously trained pose-head seeds. Actor and physics are fixed; '
                        'oracle controls and seed-42 trials are reused without recomputation.',
            'limits': parent['limits'] + [
                'This stage changes pose-head training seed only; it is not new independent object-generalization evidence.',
                'No best seed is selected. Report every seed and retain the known calibration failure.',
                'Part geometry and object geometry tied on full-task success in the seed-42 pilot; initial grasp was different.']}
    plan['limits'] = [line for line in plan['limits'] if 'execution uses predetermined seed 42 only' not in line]
    dump(args.out_dir / 'plan.json', plan)
    snapshot = args.out_dir / 'source_snapshot'
    snapshot.mkdir()
    for i, path in enumerate(plan['source_sha256']):
        source = Path(path)
        (snapshot / f'{i:02d}_{source.name}').write_bytes(source.read_bytes())
    dump(args.out_dir / 'status.json', {'status': 'prepared'})
    placeholder(args.out_dir, plan, 'prepared')
    print(json.dumps({'reused': 125, 'new': len(plan['new_trial_indices']), 'total': len(trials)}))


def report(args, plan):
    rows, errors = [], []
    for index, trial in enumerate(plan['trials']):
        case = plan['cases'][trial['case_index']]
        directory = args.out_dir / 'rollouts' / f'{index:03d}_{case["demo"]}_{trial["condition"]}'
        path = directory / 'summary.json'
        if not path.exists():
            errors.append({'index': index, **trial, 'status': 'missing'})
            continue
        record = read(path)
        if record['status'] != 'completed':
            errors.append({'index': index, **trial, 'status': record['status'], 'error': record.get('error', record.get('reason'))})
            continue
        if any(record[k] != trial[k] for k in ('case_index', 'condition')):
            errors.append({'index': index, 'status': 'record_identity_error'})
            continue
        if trial['condition'] != 'oracle_pose':
            checkpoint, _ = model_paths(PARENT, trial['condition'], trial['head_seed'])
            if record.get('pose_head_sha256') != plan['model_sha256'][str(checkpoint)]:
                errors.append({'index': index, 'status': 'wrong_head_checkpoint'})
                continue
        rows.append({'index': index, **trial, 'split': case['split'], 'object_id': case['object_id'],
                     'demo': case['demo'], 'part': case['part'],
                     'grasp': bool(record['boundary']['native_part_grasp']),
                     'task': bool(record['native_full_task_success']),
                     'reused': index < plan['reused_rollout_count'],
                     'video': str(directory.relative_to(args.out_dir) / 'execution.gif')})
    reuse_ok = all(Path(v['path']).exists() and sha(v['path']) == v['sha256']
                   for v in plan['reused_records'].values())
    groups, per_instance, paired = [], [], []
    for split in ('train', 'test'):
        conditions = [('oracle_pose', None)] + [(v, s) for s in plan['seeds'] for v in VARIANTS]
        for condition, seed in conditions:
            selected = [r for r in rows if r['split'] == split and r['condition'] == condition and r['head_seed'] == seed]
            groups.append({'split': split, 'condition': condition, 'head_seed': seed,
                           'completed': len(selected), 'instances': len({r['object_id'] for r in selected}),
                           'native_part_grasp': sum(r['grasp'] for r in selected),
                           'task_success': sum(r['task'] for r in selected)})
            for obj in sorted({r['object_id'] for r in selected}):
                subset = [r for r in selected if r['object_id'] == obj]
                per_instance.append({'split': split, 'condition': condition, 'head_seed': seed,
                                     'object_id': obj, 'completed': len(subset),
                                     'native_part_grasp': sum(r['grasp'] for r in subset),
                                     'task_success': sum(r['task'] for r in subset)})
    for seed in plan['seeds']:
        for baseline in ('point_state', 'object_geometry', 'part_geometry_semantics'):
            for metric in ('grasp', 'task'):
                wins, losses, both, neither = [], [], [], []
                for index in plan['evaluation_case_indices']:
                    if plan['cases'][index]['split'] != 'test':
                        continue
                    methods = {r['condition']: r for r in rows if r['case_index'] == index and r['head_seed'] == seed}
                    if 'part_geometry' not in methods or baseline not in methods:
                        continue
                    a, b = methods['part_geometry'][metric], methods[baseline][metric]
                    (both if a and b else wins if a else losses if b else neither).append(plan['cases'][index]['demo'])
                paired.append({'head_seed': seed, 'part_geometry_vs': baseline, 'metric': metric,
                               'part_only': len(wins), 'baseline_only': len(losses),
                               'both': len(both), 'neither': len(neither),
                               'part_only_demos': ' '.join(wins), 'baseline_only_demos': ' '.join(losses)})
    complete = len(rows) == len(plan['trials']) and not errors and reuse_ok
    summary = {'status': 'completed' if complete else 'blocked', 'finished_rollouts': len(rows) + len(errors) - sum(e['status'] == 'missing' for e in errors),
               'planned_rollouts': len(plan['trials']), 'groups': groups, 'per_instance': per_instance,
               'paired': paired, 'errors_or_blocks': errors, 'reused_records_unchanged': reuse_ok,
               'new_completed': sum(not r['reused'] for r in rows), 'reused_completed': sum(r['reused'] for r in rows),
               'limits': plan['limits']}
    dump(args.out_dir / 'summary.json', summary); dump(args.out_dir / 'status.json', summary)
    write_csv(args.out_dir / 'paired_seed_outcomes.csv', paired)
    write_csv(args.out_dir / 'per_instance_outcomes.csv', per_instance)
    write_csv(args.out_dir / 'executions.csv', rows)
    lines = ['# Part2Action geometry: training-seed replication', '', f'**Status: {summary["status"]}.**', '',
             plan['protocol'], '', f'{summary["new_completed"]}/{len(plan["new_trial_indices"])} new executions complete; '
             f'{summary["reused_completed"]}/{plan["reused_rollout_count"]} earlier executions reused. Reuse integrity: {reuse_ok}.', '',
             '| Split | Head seed | Features / pose | Completed | First-skill part grasp | Full task after recorded continuation |',
             '| --- | --- | --- | ---: | ---: | ---: |']
    for r in groups:
        lines.append(f'| {r["split"]} | {r["head_seed"] if r["head_seed"] is not None else "reference"} | '
                     f'{r["condition"]} | {r["completed"]} | {r["native_part_grasp"]} | {r["task_success"]} |')
    lines += ['', '## Scope', ''] + ['- ' + value for value in plan['limits']]
    lines += ['', '[Paired seed outcomes](paired_seed_outcomes.csv) · [Per-instance outcomes](per_instance_outcomes.csv)',
              '[Summary](summary.json) · [Plan](plan.json) · [Job IDs](submissions.json)', '', '## Videos', '']
    lines.extend(f'- seed {r["head_seed"]} / {r["demo"]} / {r["condition"]}: [video]({r["video"]})' for r in rows)
    (args.out_dir / 'README.md').write_text('\n'.join(lines) + '\n')


def submit(args, plan):
    jobs = {}
    for mode in ('evaluate', 'report'):
        command = ['sbatch', '--parsable', f'--export=ALL,MODE={mode},P2A_SEED_STUDY={args.out_dir}',
                   f'--output={args.out_dir}/{mode}_%A_%a.out', f'--error={args.out_dir}/{mode}_%A_%a.err']
        if mode == 'evaluate':
            command.append(f'--array=0-{len(plan["new_trial_indices"])-1}%4')
        else:
            command.append('--dependency=afterany:' + jobs['evaluate'])
        command.append(str(ROOT / 'part2action/slurm/pose_geometry_seed_replication.sbatch'))
        result = subprocess.run(command, check=True, capture_output=True, text=True)
        job = result.stdout.strip().split(';')[0]
        if not job.isdigit():
            raise RuntimeError('Unexpected Slurm response')
        jobs[mode] = job
        dump(args.out_dir / 'submissions.json', jobs)
    dump(args.out_dir / 'status.json', {'status': 'queued', 'jobs': jobs})
    placeholder(args.out_dir, plan, 'queued')
    print(json.dumps(jobs, indent=2))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mode', choices=('prepare', 'submit', 'evaluate', 'report'), required=True)
    parser.add_argument('--out-dir', type=Path, required=True)
    parser.add_argument('--index', type=int)
    args = parser.parse_args()
    if args.mode == 'prepare':
        prepare(args); return
    plan = read(args.out_dir / 'plan.json')
    for path, expected in plan['source_sha256'].items():
        if sha(path) != expected:
            raise RuntimeError('Frozen source changed: ' + path)
    if sha(args.out_dir / 'frozen_actor.pt') != plan['actor_sha256']:
        raise RuntimeError('Frozen actor changed')
    if args.mode == 'evaluate':
        index, per_trial = trial_plan(plan, args.index)
        case = plan['cases'][plan['trials'][index]['case_index']]
        if sha(case['case_file']) != case['case_sha256']:
            raise RuntimeError('Frozen case changed')
        trial = plan['trials'][index]
        checkpoint, _ = model_paths(PARENT, trial['condition'], trial['head_seed'])
        if sha(checkpoint) != plan['model_sha256'][str(checkpoint)]:
            raise RuntimeError('Frozen head checkpoint changed')
        args.index = index
        execute_trial(args, per_trial)
    elif args.mode == 'submit':
        submit(args, plan)
    else:
        report(args, plan)


if __name__ == '__main__':
    main()
