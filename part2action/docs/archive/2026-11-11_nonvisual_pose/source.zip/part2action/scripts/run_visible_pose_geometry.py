"""Point-free pose learning from visible depth; reuse immutable common engine.

Only depth-to-region conversion and comparison reporting are new. Training and
physical execution reuse run_pose_point_ablation unchanged, with the same
without_point model type. The completed full-geometry baseline is read-only.
"""
from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path
import shutil
import subprocess

import numpy as np

from data.pose_samples import PoseSampleDataset, load_pose_sample, save_pose_sample, validate_manifest
from data.visible_pose_geometry import visible_geometry, visible_pose_sample
import run_pose_point_ablation as common
from run_pose_point_ablation import ROOT, dump, model_paths, read, sha, trial_directory, write_csv

DEFAULT_CONFIG = ROOT / 'part2action/configs/pose_learning/visible_geometry_v1.json'


def placeholder(root, plan, status):
    (root / 'README.md').write_text(
        '# Part2Action: full versus visible geometry, without interaction points\n\n'
        f'**Status: {status}.**\n\n{plan["protocol"]}\n\n'
        '95 existing current RGB-D records are converted without replaying or generating demonstrations. '
        'Train three visible-geometry heads; execute 75 new trials. Reuse 75 point-free baseline trials '
        'and 25 oracle-pose controls read-only.\n\n'
        '[Configuration](config.json) · [Manifest](manifest.json) · [Jobs](submissions.json)\n\n'
        + '\n'.join('- ' + line for line in plan['limits']) + '\n')


def prepare(args):
    config = read(args.config)
    parent_root = Path(config['parent']).resolve()
    parent = read(parent_root / 'plan.json')
    if read(parent_root / 'summary.json')['status'] != 'completed':
        raise ValueError('Point ablation parent must be complete')
    common.verify_sources(parent_root, parent)
    for key in ('model', 'train'):
        if config[key] != parent['config'][key]:
            raise ValueError('This comparison must preserve parent ' + key + ' settings')
    for key in ('head_seeds', 'world_seed'):
        if config['evaluation'][key] != parent['config']['evaluation'][key]:
            raise ValueError('Parent execution settings differ')
    parent_manifest = read(parent_root / 'manifest.json')
    records = copy.deepcopy(parent_manifest['records'])
    for record in records:
        source = parent_root / record['file']
        receipt = read(parent_root / record['receipt'])
        if receipt['status'] != 'completed' or sha(source) != receipt['sample_sha256']:
            raise ValueError('Parent common capture changed')
        record.update(parent_file=str(source), parent_sha256=receipt['sample_sha256'])
    manifest = {**parent_manifest, 'records': records, 'source_kind': 'visible_depth_with_GT_proximity_region_labels',
                'input_policy': {'normal': 'observations only',
                                 'diagnostic': 'visible depth coordinates; object/part membership uses GT geometry',
                                 'interaction_point': 'absent'}}
    validate_manifest(manifest)
    training_trials = [{'variant': 'without_point', 'seed': s} for s in config['train']['seeds']]
    trials = [{'case_index': i, 'condition': 'without_point', 'head_seed': s}
              for s in config['evaluation']['head_seeds'] for i in parent['evaluation_case_indices']]
    baseline_records = []
    for i, trial in enumerate(parent['trials']):
        if trial['condition'] != 'without_point':
            continue
        case = parent['cases'][trial['case_index']]
        path = trial_directory(parent_root, i, trial, case) / 'summary.json'
        record = read(path)
        if record['status'] != 'completed' or any(record.get(k) != v for k, v in trial.items()):
            raise ValueError('Invalid full-geometry comparison trial')
        checkpoint, receipt_path = model_paths(parent_root, 'without_point', trial['head_seed'])
        if record['pose_head_sha256'] != sha(checkpoint) or record['actor_sha256'] != parent['actor_sha256']:
            raise ValueError('Baseline trial used a different controller/checkpoint')
        baseline_records.append({'path': str(path), 'sha256': sha(path), **trial})
    baseline_models = []
    for seed in config['train']['seeds']:
        checkpoint, receipt = model_paths(parent_root, 'without_point', seed)
        record = read(receipt)
        if record['status'] != 'completed' or sha(checkpoint) != record['checkpoint_sha256']:
            raise ValueError('Invalid baseline head')
        baseline_models.append({'seed': seed, 'path': str(receipt), 'sha256': sha(receipt),
                                'checkpoint': str(checkpoint), 'checkpoint_sha256': record['checkpoint_sha256']})
    if len(baseline_records) != len(trials):
        raise ValueError('Baseline and visible evaluations must have identical case/seed coverage')
    files = list(dict.fromkeys([str(Path(__file__).resolve()), str(args.config.resolve()),
        str(ROOT / 'part2action/data/visible_pose_geometry.py'),
        str(ROOT / 'part2action/slurm/visible_pose_geometry.sbatch'), *parent['source_sha256']]))
    plan = {'study': config['experiment'], 'parent': str(parent_root), 'config': config,
            'data_root': parent['data_root'], 'cases': parent['cases'], 'instance_split': parent['instance_split'],
            'evaluation_case_indices': parent['evaluation_case_indices'], 'training_trials': training_trials,
            'trials': trials, 'seeds': config['train']['seeds'], 'variants': ['without_point'],
            'baseline_records': baseline_records, 'baseline_models': baseline_models,
            'reference_controls': parent['reference_controls'], 'actor_sha256': parent['actor_sha256'],
            'source_sha256': {path: sha(path) for path in files},
            'protocol': 'Keep the point-free head, dataset/splits, model size, training recipe and learned controller fixed. '
                        'Replace full annotated shape coordinates with only current depth pixels assigned to '
                        'object/part regions by a fixed GT-surface proximity rule. All visibility conversion is '
                        'independent of future TCP pose, interaction point and event timing.',
            'limits': config['limits'], 'no_auto_expansion': True}
    args.out_dir.mkdir(parents=True, exist_ok=False)
    shutil.copyfile(parent_root / 'frozen_actor.pt', args.out_dir / 'frozen_actor.pt')
    dump(args.out_dir / 'manifest.json', manifest); plan['manifest_sha256'] = sha(args.out_dir / 'manifest.json')
    dump(args.out_dir / 'plan.json', plan); dump(args.out_dir / 'config.json', config)
    snapshot = args.out_dir / 'source_snapshot'; snapshot.mkdir()
    for i, path in enumerate(files):
        (snapshot / f'{i:02d}_{Path(path).name}').write_bytes(Path(path).read_bytes())
    dump(args.out_dir / 'status.json', {'status': 'prepared'})
    placeholder(args.out_dir, plan, 'prepared')
    print(json.dumps({'conversions': len(records), 'new_heads': len(training_trials),
                      'new_executions': len(trials), 'reused_baseline_executions': len(baseline_records)}))


def collect(args, plan):
    record = read(args.out_dir / 'manifest.json')['records'][args.index]
    out = args.out_dir / 'observations' / f'{args.index:03d}'
    out.mkdir(parents=True, exist_ok=False)
    try:
        if sha(record['parent_file']) != record['parent_sha256']:
            raise ValueError('Parent camera sample changed')
        sample = load_pose_sample(record['parent_file'])
        result = visible_geometry(sample, **plan['config']['geometry'])
        np.savez_compressed(out / 'visibility.npz', part_mask=result['part_mask'],
                            part_pixels=result['part_pixel_indices'], object_pixels=result['object_pixel_indices'])
        if not result['valid']:
            dump(out / 'summary.json', {'status': 'unavailable_geometry', 'case_index': args.index,
                                       'counts': result['counts'], 'reason': result['reason'],
                                       'no_GT_geometry_fallback': True})
            return
        converted = visible_pose_sample(sample, result)
        save_pose_sample(out / 'sample.npz', converted)
        dump(out / 'summary.json', {'status': 'completed', 'case_index': args.index,
                                   'sample_sha256': sha(out / 'sample.npz'), 'counts': result['counts'],
                                   'point_supplied': False, 'GT_membership_labels': True,
                                   'coordinate_source': 'current depth only'})
    except BaseException as error:
        dump(out / 'summary.json', {'status': 'runtime_error', 'case_index': args.index, 'error': repr(error)})
        raise


def _verified_baseline(plan):
    models, records, errors = [], [], []
    for row in plan['baseline_models']:
        if (sha(row['path']) != row['sha256'] or sha(row['checkpoint']) != row['checkpoint_sha256']):
            errors.append({'status': 'changed_baseline_model', 'seed': row['seed']})
        else:
            models.append(read(row['path']))
    for row in plan['baseline_records']:
        if sha(row['path']) != row['sha256']:
            errors.append({'status': 'changed_baseline_execution', 'path': row['path']})
        else:
            records.append(read(row['path']))
    return models, records, errors


def report(args, plan):
    baseline_models, baseline, errors = _verified_baseline(plan)
    models, new_records, observations = [], [], []
    for trial in plan['training_trials']:
        checkpoint, receipt = model_paths(args.out_dir, trial['variant'], trial['seed'])
        record = read(receipt) if receipt.exists() else {'status': 'missing', **trial}
        if record['status'] == 'completed' and (not checkpoint.exists() or sha(checkpoint) != record['checkpoint_sha256']):
            record = {**trial, 'status': 'changed_checkpoint'}
        models.append(record)
    matched = {}
    for seed in plan['seeds']:
        pair = [r for r in baseline_models + models if r['seed'] == seed and r['status'] == 'completed']
        matched[str(seed)] = len(pair) == 2 and all(pair[0][key] == pair[1][key] for key in
            ('initial_parameters_sha256', 'minibatches_sha256', 'updates', 'parameter_count', 'train_case_indices'))
    trained = all(r['status'] == 'completed' for r in models) and all(matched.values())
    dump(args.out_dir / 'training_summary.json', {'status': 'completed' if trained else 'blocked',
                                                 'models': models, 'matched_against_full_geometry': matched})
    by_seed = {r['seed']: r for r in models if r['status'] == 'completed'}
    for i, trial in enumerate(plan['trials']):
        case = plan['cases'][trial['case_index']]
        path = trial_directory(args.out_dir, i, trial, case) / 'summary.json'
        row = read(path) if path.exists() else {'status': 'missing'}
        model = by_seed.get(trial['head_seed'])
        if row['status'] != 'completed':
            errors.append({'index': i, **trial, **row}); continue
        if (model is None or row.get('pose_head_sha256') != model['checkpoint_sha256']
                or row.get('actor_sha256') != plan['actor_sha256']
                or any(row.get(k) != v for k, v in trial.items())):
            errors.append({'index': i, **trial, 'status': 'identity_or_checkpoint_mismatch'}); continue
        new_records.append(row)
    for i in range(len(plan['cases'])):
        path = args.out_dir / 'observations' / f'{i:03d}' / 'summary.json'
        observations.append(read(path) if path.exists() else {'status': 'missing', 'case_index': i})
    groups, paired, per_instance = [], [], []
    for split in ('train', 'test'):
        for seed in plan['seeds']:
            for condition, all_records in [('full_geometry', baseline), ('visible_geometry', new_records)]:
                rows = [r for r in all_records if r['split'] == split and r['head_seed'] == seed]
                groups.append({'split': split, 'head_seed': seed, 'condition': condition, 'completed': len(rows),
                               'grasp': sum(r['boundary']['native_part_grasp'] for r in rows),
                               'task': sum(r['native_full_task_success'] for r in rows)})
                for obj in sorted({r['object_id'] for r in rows}):
                    subset = [r for r in rows if r['object_id'] == obj]
                    per_instance.append({'split': split, 'head_seed': seed, 'condition': condition, 'object_id': obj,
                                         'completed': len(subset), 'grasp': sum(r['boundary']['native_part_grasp'] for r in subset),
                                         'task': sum(r['native_full_task_success'] for r in subset)})
    for seed in plan['seeds']:
        for metric in ('grasp', 'task'):
            counts = {'both': 0, 'full_only': 0, 'visible_only': 0, 'neither': 0}
            for index in plan['evaluation_case_indices']:
                if plan['cases'][index]['split'] != 'test':
                    continue
                a = next((r for r in baseline if r['case_index'] == index and r['head_seed'] == seed), None)
                b = next((r for r in new_records if r['case_index'] == index and r['head_seed'] == seed), None)
                if a is None or b is None:
                    continue
                def value(r):
                    return r['boundary']['native_part_grasp'] if metric == 'grasp' else r['native_full_task_success']
                x, y = value(a), value(b)
                counts['both' if x and y else 'full_only' if x else 'visible_only' if y else 'neither'] += 1
            paired.append({'head_seed': seed, 'metric': metric, **counts})
    coverage = [{'case_index': i, 'split': plan['cases'][i]['split'], 'demo': plan['cases'][i]['demo'],
                 'part': plan['cases'][i]['part'], 'status': r['status'],
                 'visible_part_points': r.get('counts', {}).get('part'),
                 'visible_object_points': r.get('counts', {}).get('object')}
                for i, r in enumerate(observations)]
    references = []
    for reference in plan['reference_controls']:
        if sha(reference['path']) != reference['sha256']:
            errors.append({'status': 'changed_oracle_control'}); continue
        r = read(reference['path']); references.append(r)
    collection_ok = all(r['status'] == 'completed' for r in observations)
    complete = trained and collection_ok and len(new_records) == len(plan['trials']) and not errors
    summary = {'status': 'completed' if complete else 'blocked', 'groups': groups, 'paired': paired,
               'per_instance': per_instance, 'observations': sum(r['status'] == 'completed' for r in observations),
               'planned_observations': len(observations), 'finished_rollouts': len(new_records) + sum(e.get('status') != 'missing' for e in errors if 'index' in e),
               'planned_rollouts': len(plan['trials']), 'training': models, 'baseline_training': baseline_models,
               'matched_training_audit': matched, 'visibility': coverage,
               'reused_baseline_executions': len(baseline), 'reused_oracle_controls': len(references),
               'collection_errors': [r for r in coverage if r['status'] != 'completed'],
               'errors_or_blocks': errors, 'limits': plan['limits']}
    dump(args.out_dir / 'summary.json', summary); dump(args.out_dir / 'status.json', summary)
    write_csv(args.out_dir / 'visibility_coverage.csv', coverage)
    write_csv(args.out_dir / 'paired_outcomes.csv', paired); write_csv(args.out_dir / 'per_instance_outcomes.csv', per_instance)
    lines = ['# Part2Action: full versus visible geometry, without interaction points', '',
             f'**Status: {summary["status"]}.**', '', plan['protocol'], '',
             f'{summary["observations"]}/95 common records converted; {len(new_records)}/75 new executions completed. '
             'Unavailable geometry, blocked jobs and missing records are not silently dropped or counted as physical failures.', '',
             '## Pose errors', '', '| Geometry | Seed | Test sources | Position | Rotation |', '| --- | ---: | ---: | ---: | ---: |']
    for condition, records in [('full_geometry', baseline_models), ('visible_geometry', models)]:
        for r in records:
            if r['status'] == 'completed':
                m = r['test']; lines.append(f'| {condition} | {r["seed"]} | {m["samples"]} | '
                                           f'{m["position_mean_mm"]:.2f} mm | {m["rotation_mean_deg"]:.2f} deg |')
    lines += ['', '## Physical execution', '', '| Split | Head seed | Geometry | Completed | Initial part grasp | Full task after recorded continuation |',
              '| --- | ---: | --- | ---: | ---: | ---: |']
    lines += [f'| {r["split"]} | {r["head_seed"]} | {r["condition"]} | {r["completed"]} | {r["grasp"]} | {r["task"]} |' for r in groups]
    lines += ['', '## Scope', ''] + ['- ' + line for line in plan['limits']]
    lines += ['', '[Visibility coverage](visibility_coverage.csv) · [Paired outcomes](paired_outcomes.csv)',
              '[Manifest](manifest.json) · [Configuration](config.json) · [Jobs](submissions.json)', '', '## Videos', '']
    for i, trial in enumerate(plan['trials']):
        case = plan['cases'][trial['case_index']]
        directory = trial_directory(args.out_dir, i, trial, case)
        if (directory / 'execution.gif').exists():
            lines.append(f'- {case["demo"]} / seed {trial["head_seed"]}: [video]({directory.relative_to(args.out_dir)}/execution.gif)')
    (args.out_dir / 'README.md').write_text('\n'.join(lines) + '\n')


def submit(args, plan):
    if (args.out_dir / 'submissions.json').exists():
        raise FileExistsError('Experiment already submitted')
    jobs = {}
    for mode, count in [('collect', len(plan['cases'])), ('train', len(plan['training_trials'])),
                        ('evaluate', len(plan['trials'])), ('report', None)]:
        command = ['sbatch', '--parsable', f'--export=ALL,MODE={mode},P2A_VISIBLE_STUDY={args.out_dir}',
                   f'--output={args.out_dir}/{mode}_%A_%a.out', f'--error={args.out_dir}/{mode}_%A_%a.err']
        if jobs:
            command.append('--dependency=afterany:' + list(jobs.values())[-1])
        if count:
            command.append(f'--array=0-{count - 1}%{plan["config"]["evaluation"]["array_concurrency"]}')
        command.append(str(ROOT / 'part2action/slurm/visible_pose_geometry.sbatch'))
        result = subprocess.run(command, check=True, text=True, capture_output=True)
        job = result.stdout.strip().split(';')[0]
        if not job.isdigit():
            raise RuntimeError('Unexpected scheduler response: ' + result.stdout)
        jobs[mode] = job; dump(args.out_dir / 'submissions.json', jobs)
    dump(args.out_dir / 'status.json', {'status': 'queued', 'jobs': jobs})
    placeholder(args.out_dir, plan, 'queued'); print(json.dumps(jobs, indent=2))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mode', choices=('prepare', 'submit', 'collect', 'train', 'evaluate', 'report'), required=True)
    parser.add_argument('--out-dir', required=True, type=Path)
    parser.add_argument('--config', type=Path, default=DEFAULT_CONFIG)
    parser.add_argument('--index', type=int)
    args = parser.parse_args(); args.out_dir = args.out_dir.resolve()
    if args.mode == 'prepare':
        prepare(args); return
    plan = read(args.out_dir / 'plan.json'); common.verify_sources(args.out_dir, plan)
    if args.mode == 'evaluate':
        case = plan['cases'][plan['trials'][args.index]['case_index']]
        if sha(case['case_file']) != case['case_sha256']:
            raise ValueError('Frozen execution reference changed')
    {'submit': submit, 'collect': collect, 'train': common.train,
     'evaluate': common.evaluate, 'report': report}[args.mode](args, plan)


if __name__ == '__main__':
    main()
