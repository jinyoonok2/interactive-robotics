"""Common pose records and a matched no-point versus oracle-point experiment.

New files/configs only. Existing Transformer and diagnostic implementations are
kept unchanged. Collection, actual training and simulation run through Slurm.
"""
from __future__ import annotations

import argparse
import copy
import csv
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import time

import numpy as np
from scipy.spatial.transform import Rotation

from data.pose_samples import PoseSample, PoseSampleDataset, SCHEMA_VERSION, save_pose_sample, validate_manifest
from diagnostics.pose_guided_approach import pose_error
from models.interaction_pose_head import rotation6d
from models.part_conditioned_pose import PartConditionedPoseHead, VARIANTS, sample_features
from models.pose_guided_actor import PoseGuidedActor
from run_point_to_pose import head_loss, head_metrics
from run_pose_guided_approach import ROOT, contacts, dump, render_frame, sha

DEFAULT_CONFIG = ROOT / 'part2action/configs/pose_learning/point_ablation_v1.json'


def read(path):
    return json.loads(Path(path).read_text())


def write_csv(path, rows):
    if rows:
        with Path(path).open('w') as handle:
            writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
            writer.writeheader(); writer.writerows(rows)


def model_paths(root, variant, seed):
    stem = root / 'models' / variant / f'seed{seed}'
    return stem.with_suffix('.pt'), stem.with_suffix('.json')


def trial_directory(root, index, trial, case):
    return root / 'rollouts' / f'{index:03d}_{case["demo"]}_{trial["condition"]}_seed{trial["head_seed"]}'


def placeholder(root, plan, status):
    (root / 'README.md').write_text(
        '# Part2Action common observations: interaction-point ablation\n\n'
        f'**Status: {status}.**\n\n{plan["protocol"]}\n\n'
        f'{len(plan["cases"])} common observations; {len(plan["training_trials"])} heads; '
        f'{len(plan["trials"])} new physical executions. Reference controls are reused read-only.\n\n'
        '[Manifest](manifest.json) · [Frozen configuration](config.json) · '
        '[Plan](plan.json) · [Jobs](submissions.json)\n\n'
        + '\n'.join('- ' + line for line in plan['limits']) + '\n')


def prepare(args):
    config_path = args.config.resolve()
    config = read(config_path)
    if (tuple(config['variants']) != VARIANTS or config['schema_version'] != SCHEMA_VERSION
            or config['observation_after_action_index'] != 0 or not config['capture_camera']
            or not config['evaluation']['retain_training_calibration']
            or not config['evaluation']['reuse_reference_controls']
            or config['evaluation']['world_seed'] != 42
            or not set(config['evaluation']['head_seeds']) <= set(config['train']['seeds'])):
        raise ValueError('Unsupported or inconsistent version-1 configuration')
    if config['model']['type'] != 'part_conditioned_pose_v1':
        raise ValueError('Unknown model implementation')
    parent_root = Path(config['parent']).resolve()
    parent = read(parent_root / 'plan.json')
    if read(parent_root / 'summary.json')['status'] != 'completed':
        raise ValueError('Parent diagnostic is incomplete')
    for path, expected in parent['source_sha256'].items():
        if sha(path) != expected:
            raise ValueError('Parent implementation changed: ' + path)
    if sha(parent_root / 'frozen_actor.pt') != parent['actor_sha256']:
        raise ValueError('Parent frozen controller changed')
    cases = copy.deepcopy(parent['cases'])
    records = []
    for i, case in enumerate(cases):
        source = parent_root / 'observations' / f'{i:03d}'
        receipt = read(source / 'summary.json')
        if receipt['status'] != 'completed' or sha(source / 'inputs.npz') != receipt['input_sha256']:
            raise ValueError('Invalid parent geometry observation')
        if sha(case['case_file']) != case['case_sha256']:
            raise ValueError('Invalid source reference')
        case['geometry_file'] = str(source / 'inputs.npz')
        case['geometry_sha256'] = receipt['input_sha256']
        records.append({'sample_id': f'{case["object"]}/{case["object_id"]}/{case["demo"]}/replay/after_action_0',
                        'instance_group': f'{case["object"]}/{case["object_id"]}', 'split': case['split'],
                        'case_index': i, 'file': f'observations/{i:03d}/sample.npz',
                        'receipt': f'observations/{i:03d}/summary.json'})
    manifest = {'schema_version': SCHEMA_VERSION, 'records': records,
                'source_kind': 'fresh_replay_camera_and_state_plus_frozen_reference_annotations',
                'observation_index': 1, 'next_action_index': 1,
                'timing': 'actual scene after original action 0, before neural action 1',
                'input_policy': {'normal': 'observations only',
                                 'both_diagnostic_variants': ['target_part_cloud_world_m', 'object_cloud_world_m'],
                                 'with_oracle_point_only': ['reference_interaction_point_world_m']}}
    validate_manifest(manifest)
    reference_controls = []
    for index in parent['evaluation_case_indices']:
        case = cases[index]
        matches = list((parent_root / 'rollouts').glob(f'*_{case["demo"]}_oracle_pose/summary.json'))
        if len(matches) != 1:
            raise ValueError('Missing or ambiguous reference control')
        record = read(matches[0])
        if (record['status'] != 'completed' or record['case_index'] != index
                or record.get('actor_sha256') != parent['actor_sha256']):
            raise ValueError('Invalid matched oracle control')
        reference_controls.append({'case_index': index, 'path': str(matches[0]), 'sha256': sha(matches[0])})
    files = list(dict.fromkeys([str(Path(__file__).resolve()), str(config_path),
        str(ROOT / 'part2action/data/pose_samples.py'), str(ROOT / 'part2action/models/part_conditioned_pose.py'),
        str(ROOT / 'part2action/slurm/pose_point_ablation.sbatch'),
        str(ROOT / 'part2action/diagnostics/interaction_records.py'), *parent['source_sha256']]))
    plan = {'study': config['experiment'], 'config': config, 'parent': str(parent_root),
            'data_root': parent['data_root'], 'cases': cases, 'instance_split': parent['instance_split'],
            'seeds': config['train']['seeds'], 'variants': list(VARIANTS),
            'evaluation_case_indices': parent['evaluation_case_indices'],
            'training_trials': [{'variant': v, 'seed': s} for s in config['train']['seeds'] for v in VARIANTS],
            'trials': [{'case_index': i, 'condition': v, 'head_seed': s}
                       for s in config['evaluation']['head_seeds'] for i in parent['evaluation_case_indices'] for v in VARIANTS],
            'reference_controls': reference_controls, 'actor_sha256': parent['actor_sha256'],
            'source_sha256': {path: sha(path) for path in files},
            'protocol': 'Shared current observations and labels, same part/object geometry and robot state. '
                        'Only the extra three oracle-point input channels differ. Same 52D MLP, centroid-relative '
                        'linear pose decoder, initialization, minibatches, loss, training budget and frozen learned actor. '
                        'No point is used to crop geometry or set the output origin in either condition.',
            'limits': config['limits'], 'no_auto_expansion': True}
    # Validate every source before creating a fresh output; never reuse a run directory.
    args.out_dir.mkdir(parents=True, exist_ok=False)
    shutil.copyfile(parent_root / 'frozen_actor.pt', args.out_dir / 'frozen_actor.pt')
    dump(args.out_dir / 'manifest.json', manifest)
    plan['manifest_sha256'] = sha(args.out_dir / 'manifest.json')
    dump(args.out_dir / 'plan.json', plan)
    dump(args.out_dir / 'config.json', config)
    snapshot = args.out_dir / 'source_snapshot'; snapshot.mkdir()
    for i, path in enumerate(files):
        (snapshot / f'{i:02d}_{Path(path).name}').write_bytes(Path(path).read_bytes())
    dump(args.out_dir / 'status.json', {'status': 'prepared'})
    placeholder(args.out_dir, plan, 'prepared')
    print(json.dumps({'observations': len(cases), 'heads': len(plan['training_trials']),
                      'new_executions': len(plan['trials']), 'reused_controls': len(reference_controls)}))


def collect(args, plan):
    from diagnostics.execution_trace import physical_state
    from diagnostics.interaction_records import observe
    from generate_logged_references import make_env
    case = plan['cases'][args.index]
    record = read(args.out_dir / 'manifest.json')['records'][args.index]
    out = args.out_dir / 'observations' / f'{args.index:03d}'
    out.mkdir(parents=True, exist_ok=False)
    env = None
    try:
        with np.load(case['geometry_file'], allow_pickle=False) as values:
            context = {key: values[key].copy() for key in ('tcp', 'opening', 'part_cloud', 'object_cloud', 'point', 'goal')}
        with np.load(case['case_file'], allow_pickle=False) as values:
            actions = values['source_actions'].copy()
            reference_object = values['reference_object'][0].copy()
            np.testing.assert_array_equal(values['goal'], context['goal'])
        env = make_env(Path(plan['data_root']), case, plan['config']['evaluation']['world_seed'], native_task_context=True)
        env.step(actions[0].copy())
        before = physical_state(env)
        np.testing.assert_allclose(before['tcp_xyzw_xyz'], context['tcp'], rtol=0, atol=1e-6)
        np.testing.assert_allclose(before['object_xyz'], reference_object, rtol=0, atol=1e-6)
        np.testing.assert_allclose(before['finger_m'], float(context['opening']), rtol=0, atol=1e-6)
        time_before = env.world.sim_time
        camera = observe(env, env.config)
        after = physical_state(env)
        if env.world.sim_time != time_before or before != after:
            raise RuntimeError('Camera capture changed the physical scene')
        observations = {key: camera[key] for key in ('rgb', 'depth_m', 'camera_intrinsic', 'world_to_camera_opengl')}
        observations.update(scene_pcd_camera_m=camera['pcd_camera_m'], scene_pcd_world_m=camera['pcd_world_m'],
                            tcp_pose_xyzw_xyz=np.asarray(before['tcp_xyzw_xyz']),
                            gripper_opening_m=np.asarray([before['finger_m']]),
                            task_instruction=case['episode']['task_instruction'])
        chunk = np.zeros((8, 7), dtype=actions.dtype)
        valid = min(8, len(actions) - 1); chunk[:valid] = actions[1:1 + valid]
        labels = {'interaction_pose_xyzw_xyz': context['goal'],
                  'action_chunk_world_xyz_euler_opening': chunk, 'action_valid': np.arange(8) < valid}
        privileged = {'target_part_cloud_world_m': context['part_cloud'], 'object_cloud_world_m': context['object_cloud'],
                      'reference_interaction_point_world_m': context['point'],
                      'reference_closure_index': np.asarray(case['window']['close']),
                      'reference_skill_end_index': np.asarray(case['window']['end']),
                      'source_actions': actions, 'reference_object_after_prefix': reference_object}
        provenance = {key: record[key] for key in ('sample_id', 'instance_group', 'split')}
        provenance.update(source_kind='fresh_replay', demo=case['demo'], object_id=case['object_id'],
                          episode_id=case['episode_id'], source_hdf5=str(Path(plan['data_root']) / 'demos' / (case['object'] + '.hdf5')),
                          observation_index=1, next_action_index=1, timing='after original action 0, before action 1',
                          tcp_frame='world', scene_pcd_frame='world_and_camera', units='meters',
                          camera_renderer='CPU TinyRenderer; native camera optics; deterministic unsegmented depth sampling',
                          geometry_source='annotated asset clouds transformed by simulator GT pose',
                          point_source='part surface nearest future successful reference TCP; diagnostic oracle',
                          geometry_sha256=case['geometry_sha256'], reference_sha256=case['case_sha256'])
        sample = PoseSample(observations, labels, privileged, provenance)
        save_pose_sample(out / 'sample.npz', sample)
        # Cheap isolation audit before accepting a collected sample.
        normal = sample.model_inputs(require=('rgb', 'scene_pcd_world_m'))
        if set(normal) & (set(labels) | set(privileged)):
            raise RuntimeError('GT entered normal model inputs')
        a, origin_a = sample_features(sample, 'without_point')
        b, origin_b = sample_features(sample, 'with_oracle_point')
        np.testing.assert_array_equal(a[:49], b[:49]); np.testing.assert_array_equal(origin_a, origin_b)
        dump(out / 'summary.json', {'status': 'completed', 'case_index': args.index,
                                  'sample_sha256': sha(out / 'sample.npz'), 'camera_read_only': True,
                                  'shared_features_equal': True, 'normal_input_keys': sorted(normal),
                                  'label_keys': sorted(labels), 'privileged_keys': sorted(privileged)})
    except BaseException as error:
        dump(out / 'summary.json', {'status': 'runtime_error', 'case_index': args.index, 'error': repr(error)})
        raise
    finally:
        if env is not None:
            env.close()


def training_arrays(root, variant):
    dataset = PoseSampleDataset(root / 'manifest.json')
    features, origins, goals = [], [], []
    for sample in dataset:
        x, origin = sample_features(sample, variant)
        features.append(x); origins.append(origin)
        goals.append(sample.labels['interaction_pose_xyzw_xyz'])
    return np.asarray(features), np.asarray(origins), np.asarray(goals)


def train(args, plan):
    import torch
    torch.set_num_threads(2)
    trial = plan['training_trials'][args.index]
    path, summary_path = model_paths(args.out_dir, trial['variant'], trial['seed'])
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() or summary_path.exists():
        raise FileExistsError('Refusing to overwrite a trained model')
    started = time.monotonic()
    try:
        features, origins, goals = training_arrays(args.out_dir, trial['variant'])
        x, origin, position = [torch.tensor(v, dtype=torch.float32) for v in (features, origins, goals[:, 4:])]
        matrices = Rotation.from_quat(goals[:, :4]).as_matrix()
        matrix = torch.tensor(matrices, dtype=torch.float32)
        target6 = torch.tensor(rotation6d(matrices), dtype=torch.float32)
        values = (x, origin, position, matrix, target6)
        indices = {split: torch.tensor([i for i, c in enumerate(plan['cases']) if c['split'] == split])
                   for split in ('train', 'development', 'test')}
        config = plan['config']['train']
        torch.manual_seed(trial['seed'])
        model = PartConditionedPoseHead(plan['config']['model']['hidden'], plan['config']['model']['position_scale_m'])
        initial = hashlib.sha256(b''.join(v.detach().numpy().tobytes() for v in model.state_dict().values())).hexdigest()
        rng = torch.Generator().manual_seed(trial['seed']); batches = hashlib.sha256()
        optimizer = torch.optim.AdamW(model.parameters(), lr=config['lr'], weight_decay=config['weight_decay'])
        schedule = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, config['updates'], eta_min=config['minimum_lr'])
        best, history = float('inf'), []
        for update in range(config['updates'] + 1):
            if update % config['diagnostic_every'] == 0 or update == config['updates']:
                model.eval()
                metrics = head_metrics(model, *[v[indices['development']] for v in values])
                history.append({'update': update, **metrics})
                if metrics['loss'] < best:
                    best = metrics['loss']
                    torch.save({'state_dict': model.state_dict(), 'model_type': 'part_conditioned_pose_v1',
                                'hidden': model.hidden, 'position_scale_m': model.position_scale_m,
                                **trial, 'update': update, 'manifest_sha256': sha(args.out_dir / 'manifest.json')}, path)
                dump(path.with_suffix('.progress.json'), {**trial, 'update': update, 'updates': config['updates']})
            if update == config['updates']:
                break
            model.train()
            batch = indices['train'][torch.randint(len(indices['train']), (config['batch_size'],), generator=rng)]
            batches.update(batch.numpy().tobytes())
            optimizer.zero_grad(set_to_none=True)
            loss = head_loss(model(x[batch], origin[batch]), position[batch], matrix[batch], target6[batch])
            loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(), 5.)
            optimizer.step(); schedule.step()
        checkpoint = torch.load(path, map_location='cpu', weights_only=False)
        model.load_state_dict(checkpoint['state_dict']); model.eval()
        with torch.no_grad():
            prediction = model(x, origin)
        predicted = np.c_[Rotation.from_matrix(prediction['rotation'].numpy()).as_quat(), prediction['position'].numpy()]
        rows = [{'case_index': i, 'split': c['split'], 'object_id': c['object_id'], 'demo': c['demo'],
                 **pose_error(predicted[i], goals[i])} for i, c in enumerate(plan['cases'])]
        write_csv(path.with_suffix('.predictions.csv'), rows); write_csv(path.with_suffix('.history.csv'), history)
        dump(summary_path, {'status': 'completed', **trial, 'checkpoint_sha256': sha(path),
                            'selected_update': checkpoint['update'], 'initial_parameters_sha256': initial,
                            'minibatches_sha256': batches.hexdigest(), 'updates': config['updates'],
                            'parameter_count': sum(p.numel() for p in model.parameters()),
                            'manifest_sha256': sha(args.out_dir / 'manifest.json'),
                            'train_case_indices': indices['train'].tolist(), 'elapsed_seconds': time.monotonic() - started,
                            **{split: head_metrics(model, *[v[indices[split]] for v in values]) for split in indices}})
    except BaseException as error:
        dump(summary_path, {'status': 'blocked', **trial, 'error': repr(error)})
        raise


def evaluate(args, plan):
    import imageio.v2 as imageio
    import torch
    from diagnostics.execution_trace import physical_state
    from generate_logged_references import make_env, native_grasp
    trial = plan['trials'][args.index]; case = plan['cases'][trial['case_index']]
    out = trial_directory(args.out_dir, args.index, trial, case)
    out.mkdir(parents=True, exist_ok=False); env = None
    try:
        model_path, receipt_path = model_paths(args.out_dir, trial['condition'], trial['head_seed'])
        if not receipt_path.exists() or read(receipt_path)['status'] != 'completed':
            dump(out / 'summary.json', {'status': 'blocked', **trial, 'reason': 'Pose-head training missing or failed'})
            return
        receipt = read(receipt_path)
        if sha(model_path) != receipt['checkpoint_sha256']:
            raise ValueError('Pose checkpoint changed')
        checkpoint = torch.load(model_path, map_location='cpu', weights_only=False)
        if (checkpoint['variant'] != trial['condition'] or checkpoint['seed'] != trial['head_seed']
                or checkpoint['manifest_sha256'] != sha(args.out_dir / 'manifest.json')):
            raise ValueError('Wrong pose-head checkpoint or dataset')
        head = PartConditionedPoseHead(checkpoint['hidden'], checkpoint['position_scale_m'])
        head.load_state_dict(checkpoint['state_dict']); head.eval()
        sample = PoseSampleDataset(args.out_dir / 'manifest.json')[trial['case_index']]
        features, origin = sample_features(sample, trial['condition'])
        goal = head.predict(features, origin)
        # Execution-only privileges never enter the pose head.
        context = sample.privileged
        source_actions = context['source_actions']
        oracle = sample.labels['interaction_pose_xyzw_xyz']
        close, end = int(context['reference_closure_index']), int(context['reference_skill_end_index'])
        actor_checkpoint = torch.load(args.out_dir / 'frozen_actor.pt', map_location='cpu', weights_only=False)
        actor = PoseGuidedActor(actor_checkpoint['pose_enabled'], actor_checkpoint['hidden'])
        actor.load_state_dict(actor_checkpoint['state_dict']); actor.eval()
        dump(out / 'inferred_pose.json', {'goal_xyzw_xyz': goal.tolist(), 'origin': origin.tolist(),
                                         'oracle_xyzw_xyz': oracle.tolist(), 'error': pose_error(goal, oracle),
                                         'point_input_enabled': trial['condition'] == 'with_oracle_point'})
        env = make_env(Path(plan['data_root']), case, plan['config']['evaluation']['world_seed'], native_task_context=True)
        config = env.config
        view = env.world.p.computeViewMatrixFromYawPitchRoll(cameraTargetPosition=list(config.cam_static_target),
            distance=config.cam_static_dist, yaw=config.cam_static_yaw, pitch=config.cam_static_pitch,
            roll=0, upAxisIndex=config.up_axis_index)
        projection = env.world.p.computeProjectionMatrixFOV(fov=60, aspect=1, nearVal=config.cam_near, farVal=config.cam_far)
        rows, frames, executed, states, before_tcp = [], [], [], [], []
        boundary = None
        for i, source in enumerate(source_actions):
            state = physical_state(env); before_tcp.append(state['tcp_xyzw_xyz'])
            if i == 1:
                np.testing.assert_allclose(state['tcp_xyzw_xyz'], sample.observations['tcp_pose_xyzw_xyz'], rtol=0, atol=1e-6)
                np.testing.assert_allclose(state['object_xyz'], context['reference_object_after_prefix'], rtol=0, atol=1e-6)
            neural = 1 <= i < end
            action = actor.predict(state['tcp_xyzw_xyz'], state['finger_m'], goal, i, close, end) if neural else source.copy()
            _, _, done, _ = env.step(action.copy())
            after = physical_state(env); states.append(after); executed.append(action)
            rows.append({'index': i, 'neural_action': neural, 'native_task_success': bool(done)})
            if i == end - 1:
                boundary = {'native_part_grasp': native_grasp(env), 'contacts': contacts(env),
                            'target_pose_error': pose_error(after['tcp_xyzw_xyz'], goal)}
            if i >= 1 and i % 2 == 0:
                frames.append(render_frame(env, view, projection,
                    f'POINT ABLATION | {trial["condition"]} | seed {trial["head_seed"]} | {case["demo"]}\nStep {i} | success {bool(done)}'))
        executed = np.asarray(executed)
        if not np.array_equal(executed[0], source_actions[0]) or not np.array_equal(executed[end:], source_actions[end:]):
            raise RuntimeError('Recorded prefix or continuation changed')
        np.savez_compressed(out / 'trajectories.npz', before_tcp=np.asarray(before_tcp), applied_actions=executed,
                            source_actions=source_actions, tcp=np.asarray([s['tcp_xyzw_xyz'] for s in states]),
                            object_xyz=np.asarray([s['object_xyz'] for s in states]),
                            finger_m=np.asarray([s['finger_m'] for s in states]), inferred_goal=goal, oracle_goal=oracle)
        write_csv(out / 'per_step.csv', rows); imageio.mimsave(out / 'execution.gif', frames, duration=.1, loop=0)
        dump(out / 'summary.json', {'status': 'completed', **trial, 'split': case['split'],
                                    'object_id': case['object_id'], 'demo': case['demo'],
                                    'boundary': boundary, 'native_full_task_success': any(r['native_task_success'] for r in rows),
                                    'pose_prediction_error': pose_error(goal, oracle), 'pose_head_sha256': sha(model_path),
                                    'actor_sha256': plan['actor_sha256']})
    except BaseException as error:
        dump(out / 'summary.json', {'status': 'runtime_error', **trial, 'error': repr(error)})
        raise
    finally:
        if env is not None:
            env.close()


def report(args, plan):
    training, errors, rows = [], [], []
    for trial in plan['training_trials']:
        path, receipt_path = model_paths(args.out_dir, trial['variant'], trial['seed'])
        record = read(receipt_path) if receipt_path.exists() else {'status': 'missing', **trial}
        if record['status'] == 'completed' and (not path.exists() or sha(path) != record['checkpoint_sha256']):
            record = {**trial, 'status': 'changed_checkpoint'}
        training.append(record)
    matched = {}
    for seed in plan['seeds']:
        records = [r for r in training if r['seed'] == seed and r['status'] == 'completed']
        matched[str(seed)] = len(records) == 2 and all(len({r[k] for r in records}) == 1 for k in
            ('initial_parameters_sha256', 'minibatches_sha256', 'updates', 'parameter_count', 'manifest_sha256'))
    trained = all(r['status'] == 'completed' for r in training) and all(matched.values())
    dump(args.out_dir / 'training_summary.json', {'status': 'completed' if trained else 'blocked',
                                                'models': training, 'matched_training_audit': matched})
    by_model = {(r['variant'], r['seed']): r for r in training if r['status'] == 'completed'}
    for i, trial in enumerate(plan['trials']):
        case = plan['cases'][trial['case_index']]
        directory = trial_directory(args.out_dir, i, trial, case); path = directory / 'summary.json'
        record = read(path) if path.exists() else {'status': 'missing'}
        model = by_model.get((trial['condition'], trial['head_seed']))
        if record['status'] != 'completed':
            errors.append({'index': i, **trial, **record}); continue
        if (any(record.get(k) != v for k, v in trial.items()) or model is None
                or record.get('pose_head_sha256') != model['checkpoint_sha256']
                or record.get('actor_sha256') != plan['actor_sha256']):
            errors.append({'index': i, **trial, 'status': 'checkpoint_or_identity_mismatch'}); continue
        rows.append({'index': i, **trial, 'split': case['split'], 'demo': case['demo'], 'object_id': case['object_id'],
                     'grasp': bool(record['boundary']['native_part_grasp']), 'task': bool(record['native_full_task_success']),
                     'video': str(directory.relative_to(args.out_dir) / 'execution.gif')})
    references = []
    for reference in plan['reference_controls']:
        path = Path(reference['path'])
        if not path.exists() or sha(path) != reference['sha256']:
            errors.append({'status': 'changed_reference_control', **reference}); continue
        record = read(path); case = plan['cases'][reference['case_index']]
        references.append({'case_index': reference['case_index'], 'split': case['split'], 'demo': case['demo'],
                           'grasp': bool(record['boundary']['native_part_grasp']), 'task': bool(record['native_full_task_success'])})
    groups, paired, per_instance = [], [], []
    for split in ('train', 'test'):
        for seed in plan['config']['evaluation']['head_seeds']:
            for variant in VARIANTS:
                selected = [r for r in rows if r['split'] == split and r['head_seed'] == seed and r['condition'] == variant]
                groups.append({'split': split, 'head_seed': seed, 'condition': variant, 'completed': len(selected),
                               'grasp': sum(r['grasp'] for r in selected), 'task': sum(r['task'] for r in selected)})
                for obj in sorted({r['object_id'] for r in selected}):
                    subset = [r for r in selected if r['object_id'] == obj]
                    per_instance.append({'split': split, 'head_seed': seed, 'condition': variant, 'object_id': obj,
                                         'completed': len(subset), 'grasp': sum(r['grasp'] for r in subset),
                                         'task': sum(r['task'] for r in subset)})
    for seed in plan['config']['evaluation']['head_seeds']:
        for metric in ('grasp', 'task'):
            both, neither, no_point_only, point_only = [], [], [], []
            for index in plan['evaluation_case_indices']:
                if plan['cases'][index]['split'] != 'test':
                    continue
                methods = {r['condition']: r for r in rows if r['case_index'] == index and r['head_seed'] == seed}
                if set(methods) != set(VARIANTS):
                    continue
                a, b = methods['without_point'][metric], methods['with_oracle_point'][metric]
                (both if a and b else no_point_only if a else point_only if b else neither).append(plan['cases'][index]['demo'])
            paired.append({'head_seed': seed, 'metric': metric, 'no_point_only': len(no_point_only),
                           'point_only': len(point_only), 'both': len(both), 'neither': len(neither),
                           'no_point_only_demos': ' '.join(no_point_only), 'point_only_demos': ' '.join(point_only)})
    observations = []
    for i in range(len(plan['cases'])):
        path = args.out_dir / 'observations' / f'{i:03d}' / 'summary.json'
        observations.append(read(path) if path.exists() else {'status': 'missing', 'case_index': i})
    collection_ok = all(r['status'] == 'completed' for r in observations)
    complete = trained and collection_ok and not errors and len(rows) == len(plan['trials'])
    summary = {'status': 'completed' if complete else 'blocked', 'groups': groups, 'per_instance': per_instance,
               'paired': paired, 'reference_controls': references, 'training': training,
               'matched_training_audit': matched, 'finished_rollouts': len(rows) + sum(e['status'] != 'missing' for e in errors if 'index' in e),
               'planned_rollouts': len(plan['trials']), 'valid_completed': len(rows),
               'observations': sum(r['status'] == 'completed' for r in observations), 'planned_observations': len(observations),
               'collection_errors': [r for r in observations if r['status'] != 'completed'],
               'errors_or_blocks': errors, 'limits': plan['limits']}
    dump(args.out_dir / 'summary.json', summary); dump(args.out_dir / 'status.json', summary)
    write_csv(args.out_dir / 'executions.csv', rows); write_csv(args.out_dir / 'paired_outcomes.csv', paired)
    write_csv(args.out_dir / 'per_instance_outcomes.csv', per_instance)
    lines = ['# Part2Action common observations: interaction-point ablation', '', f'**Status: {summary["status"]}.**', '',
             plan['protocol'], '', f'{len(rows)}/{len(plan["trials"])} valid new executions. '
             'Missing, blocked and runtime-error trials are unknown, not physical failures.', '',
             '## Offline pose prediction', '', '| Variant | Seed | Test samples | Position error | Rotation error |',
             '| --- | ---: | ---: | ---: | ---: |']
    for r in training:
        if r['status'] == 'completed':
            m = r['test']; lines.append(f'| {r["variant"]} | {r["seed"]} | {m["samples"]} | '
                                        f'{m["position_mean_mm"]:.2f} mm | {m["rotation_mean_deg"]:.2f} deg |')
    lines += ['', '## Matched physical execution', '', '| Split | Head seed | Variant | Completed | Initial part grasp | Full task after replayed continuation |',
              '| --- | ---: | --- | ---: | ---: | ---: |']
    lines += [f'| {r["split"]} | {r["head_seed"]} | {r["condition"]} | {r["completed"]} | {r["grasp"]} | {r["task"]} |' for r in groups]
    for split in ('train', 'test'):
        selected = [r for r in references if r['split'] == split]
        lines.append(f'| {split} | reference | oracle pose, reused | {len(selected)} | '
                     f'{sum(r["grasp"] for r in selected)} | {sum(r["task"] for r in selected)} |')
    lines += ['', '## Scope', ''] + ['- ' + line for line in plan['limits']]
    lines += ['', '[Manifest](manifest.json) · [Configuration](config.json) · [Plan](plan.json) · [Jobs](submissions.json)',
              '[Paired outcomes](paired_outcomes.csv) · [Per-instance results](per_instance_outcomes.csv)', '', '## Videos', '']
    lines += [f'- {r["demo"]} / seed {r["head_seed"]} / {r["condition"]}: [video]({r["video"]})' for r in rows]
    if any((args.out_dir / 'models').glob('*/*.history.csv')):
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        fig, axes = plt.subplots(1, 2, figsize=(10, 4))
        for trial in plan['training_trials']:
            model, _ = model_paths(args.out_dir, trial['variant'], trial['seed'])
            path = model.with_suffix('.history.csv')
            if not path.exists():
                continue
            with path.open() as handle:
                history = list(csv.DictReader(handle))
            for ax, metric in zip(axes, ('position_mean_mm', 'rotation_mean_deg')):
                ax.plot([int(r['update']) for r in history], [float(r[metric]) for r in history],
                        label=f'{trial["variant"]}/{trial["seed"]}')
        axes[0].set(xlabel='Updates', ylabel='Development position error (mm)')
        axes[1].set(xlabel='Updates', ylabel='Development rotation error (deg)'); axes[1].legend(fontsize=6)
        fig.tight_layout(); fig.savefig(args.out_dir / 'learning_curves.png', dpi=150); plt.close(fig)
        lines += ['', '![Learning curves](learning_curves.png)']
    (args.out_dir / 'README.md').write_text('\n'.join(lines) + '\n')


def submit(args, plan):
    if (args.out_dir / 'submissions.json').exists():
        raise FileExistsError('This experiment already has a submission ledger')
    collection_indices = []
    for index in range(len(plan['cases'])):
        directory = args.out_dir / 'observations' / f'{index:03d}'
        receipt_path = directory / 'summary.json'
        if receipt_path.exists():
            record = read(receipt_path)
            if record['status'] != 'completed' or sha(directory / 'sample.npz') != record['sample_sha256']:
                raise ValueError('Existing capture failed or changed; do not overwrite it')
        elif directory.exists():
            raise ValueError('An observation directory is incomplete or still running')
        else:
            collection_indices.append(index)
    jobs = {}
    stages = [('collect', len(plan['cases'])), ('train', len(plan['training_trials'])),
              ('evaluate', len(plan['trials'])), ('report', None)]
    for mode, count in stages:
        if mode == 'collect' and not collection_indices:
            continue
        command = ['sbatch', '--parsable', f'--export=ALL,MODE={mode},P2A_POINT_STUDY={args.out_dir}',
                   f'--output={args.out_dir}/{mode}_%A_%a.out', f'--error={args.out_dir}/{mode}_%A_%a.err']
        if jobs:
            command.append('--dependency=afterany:' + list(jobs.values())[-1])
        if count:
            indices = ','.join(map(str, collection_indices)) if mode == 'collect' else f'0-{count - 1}'
            command.append(f'--array={indices}%{plan["config"]["evaluation"]["array_concurrency"]}')
        command.append(str(ROOT / 'part2action/slurm/pose_point_ablation.sbatch'))
        result = subprocess.run(command, check=True, capture_output=True, text=True)
        job = result.stdout.strip().split(';')[0]
        if not job.isdigit():
            raise RuntimeError('Unexpected scheduler response: ' + result.stdout)
        jobs[mode] = job; dump(args.out_dir / 'submissions.json', jobs)
    dump(args.out_dir / 'status.json', {'status': 'queued', 'jobs': jobs})
    placeholder(args.out_dir, plan, 'queued'); print(json.dumps(jobs, indent=2))


def verify_sources(root, plan):
    for path, expected in plan['source_sha256'].items():
        if sha(path) != expected:
            raise RuntimeError('Frozen source changed: ' + path)
    if sha(root / 'frozen_actor.pt') != plan['actor_sha256']:
        raise RuntimeError('Frozen actor changed')
    if read(root / 'config.json') != plan['config']:
        raise RuntimeError('Frozen configuration changed')
    if sha(root / 'manifest.json') != plan['manifest_sha256']:
        raise RuntimeError('Frozen sample manifest changed')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mode', choices=('prepare', 'submit', 'collect', 'train', 'evaluate', 'report'), required=True)
    parser.add_argument('--config', type=Path, default=DEFAULT_CONFIG)
    parser.add_argument('--out-dir', type=Path, required=True)
    parser.add_argument('--index', type=int)
    args = parser.parse_args(); args.out_dir = args.out_dir.resolve()
    if args.mode == 'prepare':
        prepare(args); return
    plan = read(args.out_dir / 'plan.json'); verify_sources(args.out_dir, plan)
    if args.mode in ('collect', 'evaluate'):
        index = args.index if args.mode == 'collect' else plan['trials'][args.index]['case_index']
        case = plan['cases'][index]
        if sha(case['case_file']) != case['case_sha256'] or sha(case['geometry_file']) != case['geometry_sha256']:
            raise RuntimeError('Frozen reference/geometry changed')
    {'submit': submit, 'collect': collect, 'train': train, 'evaluate': evaluate, 'report': report}[args.mode](args, plan)


if __name__ == '__main__':
    main()
