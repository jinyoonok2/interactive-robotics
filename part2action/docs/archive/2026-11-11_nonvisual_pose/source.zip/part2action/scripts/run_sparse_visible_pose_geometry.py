"""Visible geometry v2: preserve sparse Train examples without GT fallback.

The version-1 converter exposed one Train handle with only two visible pixels.
This version changes only the cloud formatting contract: balanced repetition of
existing points to the unchanged head's minimum input-row count. Actual pixel
counts are retained. All original data/splits/model/training remain fixed.
"""
from __future__ import annotations

import argparse
from pathlib import Path
import subprocess

import numpy as np

from data.pose_samples import load_pose_sample, save_pose_sample
from data.sparse_visible_pose_geometry import sparse_visible_geometry
from data.visible_pose_geometry import visible_pose_sample
import run_pose_point_ablation as common
import run_visible_pose_geometry as base
from run_pose_point_ablation import ROOT, dump, read, sha

DEFAULT_CONFIG = ROOT / 'part2action/configs/pose_learning/visible_geometry_v2.json'


def prepare(args):
    base.prepare(args)
    plan = read(args.out_dir / 'plan.json')
    added = [Path(__file__).resolve(), ROOT / 'part2action/data/sparse_visible_pose_geometry.py',
             ROOT / 'part2action/slurm/sparse_visible_pose_geometry.sbatch']
    offset = len(plan['source_sha256'])
    for i, path in enumerate(added):
        plan['source_sha256'][str(path)] = sha(path)
        (args.out_dir / 'source_snapshot' / f'{offset + i:02d}_{path.name}').write_bytes(path.read_bytes())
    plan['protocol'] += (' Version 2 accepts at least two actual visible points, repeats observed rows '
                         'equally to satisfy the unchanged statistics head, and records both actual '
                         'and stored counts. This formatting decision follows a Train-only visibility '
                         'failure; mask tolerance and Test selection are unchanged.')
    dump(args.out_dir / 'plan.json', plan)
    base.placeholder(args.out_dir, plan, 'prepared')


def collect_all(args, plan):
    records = read(args.out_dir / 'manifest.json')['records']
    for index, record in enumerate(records):
        out = args.out_dir / 'observations' / f'{index:03d}'
        out.mkdir(parents=True, exist_ok=False)
        try:
            if sha(record['parent_file']) != record['parent_sha256']:
                raise ValueError('Parent sample changed')
            sample = load_pose_sample(record['parent_file'])
            result = sparse_visible_geometry(sample, **plan['config']['geometry'])
            np.savez_compressed(out / 'visibility.npz', part_mask=result['part_mask'],
                                part_pixels=result['part_pixel_indices'], object_pixels=result['object_pixel_indices'])
            if not result['valid']:
                dump(out / 'summary.json', {'status': 'unavailable_geometry', 'case_index': index,
                                           'counts': result['counts'], 'reason': result['reason'],
                                           'no_GT_geometry_fallback': True})
                continue
            converted = visible_pose_sample(sample, result)
            converted.provenance['stored_geometry_point_counts'] = result['stored_point_counts']
            save_pose_sample(out / 'sample.npz', converted)
            dump(out / 'summary.json', {'status': 'completed', 'case_index': index,
                                       'sample_sha256': sha(out / 'sample.npz'), 'counts': result['counts'],
                                       'stored_point_counts': result['stored_point_counts'],
                                       'point_supplied': False, 'GT_membership_labels': True,
                                       'coordinate_source': 'depth only; repetition adds no information'})
        except BaseException as error:
            dump(out / 'summary.json', {'status': 'runtime_error', 'case_index': index, 'error': repr(error)})
        print('converted', index, record['sample_id'], flush=True)


def submit(args, plan):
    if (args.out_dir / 'submissions.json').exists():
        raise FileExistsError('Experiment already submitted')
    jobs = {}
    for mode, count in [('collect', None), ('train', len(plan['training_trials'])),
                        ('evaluate', len(plan['trials'])), ('report', None)]:
        command = ['sbatch', '--parsable', f'--export=ALL,MODE={mode},P2A_VISIBLE_STUDY={args.out_dir}',
                   f'--output={args.out_dir}/{mode}_%A_%a.out', f'--error={args.out_dir}/{mode}_%A_%a.err']
        if jobs:
            command.append('--dependency=afterany:' + list(jobs.values())[-1])
        if count:
            command.append(f'--array=0-{count - 1}%{plan["config"]["evaluation"]["array_concurrency"]}')
        command.append(str(ROOT / 'part2action/slurm/sparse_visible_pose_geometry.sbatch'))
        response = subprocess.run(command, check=True, capture_output=True, text=True)
        job = response.stdout.strip().split(';')[0]
        if not job.isdigit():
            raise RuntimeError('Unexpected Slurm response: ' + response.stdout)
        jobs[mode] = job; dump(args.out_dir / 'submissions.json', jobs)
    dump(args.out_dir / 'status.json', {'status': 'queued', 'jobs': jobs})
    base.placeholder(args.out_dir, plan, 'queued')
    print(jobs)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mode', choices=('prepare', 'submit', 'collect', 'train', 'evaluate', 'report'), required=True)
    parser.add_argument('--out-dir', type=Path, required=True)
    parser.add_argument('--config', type=Path, default=DEFAULT_CONFIG)
    parser.add_argument('--index', type=int)
    args = parser.parse_args(); args.out_dir = args.out_dir.resolve()
    if args.mode == 'prepare':
        prepare(args); return
    plan = read(args.out_dir / 'plan.json'); common.verify_sources(args.out_dir, plan)
    if args.mode == 'evaluate':
        case = plan['cases'][plan['trials'][args.index]['case_index']]
        if sha(case['case_file']) != case['case_sha256']:
            raise ValueError('Frozen source reference changed')
    {'submit': submit, 'collect': collect_all, 'train': common.train,
     'evaluate': common.evaluate, 'report': base.report}[args.mode](args, plan)


if __name__ == '__main__':
    main()
